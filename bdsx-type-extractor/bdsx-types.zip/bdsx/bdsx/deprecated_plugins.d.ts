export declare const deprecatedPlugins: [string, string][];
