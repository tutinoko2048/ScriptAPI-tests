export declare function installErrorHandler(): void;
