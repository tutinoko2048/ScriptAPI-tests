export declare function installMinecraftAddons(): Promise<void>;
