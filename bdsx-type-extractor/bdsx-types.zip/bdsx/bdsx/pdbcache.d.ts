export declare namespace pdbcache {
    function readKeys(): IterableIterator<string>;
    /**
     * @return -1 if not found
     */
    function search(key: string): number;
}
