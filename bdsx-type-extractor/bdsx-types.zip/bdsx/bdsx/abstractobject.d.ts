/**
 * @param message error message when accessing
 */
export declare function createAbstractObject(message: string): any;
