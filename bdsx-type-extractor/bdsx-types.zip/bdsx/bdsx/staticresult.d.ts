/**
 * static the function returning for optimizing
 */
export declare function staticResult<CLS, NAME extends keyof CLS>(cls: {
    prototype: CLS;
}, fnname: NAME, fn: CLS[NAME]): void;
