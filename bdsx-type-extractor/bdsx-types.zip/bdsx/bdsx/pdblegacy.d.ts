import { NativePointer } from "./core";
/**
 * @deprecated
 */
export declare namespace pdblegacy {
    const coreCachePath: string;
    function close(): void;
    /**
     * get symbols from cache.
     * if symbols don't exist in cache. it reads pdb.
     * @returns 'out' the first parameter.
     */
    function getList<OLD extends Record<string, any>, KEY extends string, KEYS extends readonly [...KEY[]]>(cacheFilePath: string, out: OLD, names: KEYS, quiet?: boolean, undecorateFlags?: number): {
        [key in KEYS[number]]: NativePointer;
    } & OLD;
    function search(callback: (name: string, address: NativePointer) => boolean): void;
    function search(filter: string | null, callback: (name: string, address: NativePointer) => boolean): void;
    function search<KEYS extends string[]>(names: KEYS, callback: (name: KEYS[number], address: NativePointer, index: number) => boolean): void;
    function getAll(onprogress?: (count: number) => void): Record<string, NativePointer>;
    interface SymbolInfo {
        address: NativePointer;
        name: string;
    }
    /**
     * get all symbols.
     * @param read calbacked per 100ms, stop the looping if it returns false
     */
    function getAllEx(read: (data: SymbolInfo[]) => boolean | void): void;
}
