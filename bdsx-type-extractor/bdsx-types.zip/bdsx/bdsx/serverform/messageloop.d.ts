import { NativeModule } from "../dll";
export declare namespace messageLoop {
    function ref(): void;
    function unref(): void;
    const user32: NativeModule;
}
