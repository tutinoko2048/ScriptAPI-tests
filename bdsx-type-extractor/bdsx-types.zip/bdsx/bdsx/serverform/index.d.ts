import { VoidPointer } from "../core";
export declare class ServerForm {
    private readonly handle;
    private alive;
    private readonly buttonCbs;
    constructor(title: string, width: number, height: number);
    button(name: string, x: number, y: number, width: number, height: number, cb: () => void): void;
    onMessage(msg: number, wParam: VoidPointer, lParam: VoidPointer): void;
    close(): void;
}
