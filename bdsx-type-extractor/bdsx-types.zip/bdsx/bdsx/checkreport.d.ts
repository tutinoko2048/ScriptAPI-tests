/**
 * @deprecated unusing
 */
export declare function checkAndReport(name: string, oversion: string, nversion: string): void;
