import { SoftEnumUpdateType } from "./bds/command";
import { CommandMappedValue } from "./commandparser";
import { StaticPointer, VoidPointer } from "./core";
import { NativeClass } from "./nativeclass";
import { bin64_t, CxxString, int32_t, int64_as_float_t, NativeType, Type } from "./nativetype";
export declare class EnumResult extends NativeClass {
    intValue: int32_t;
    bin64Value: bin64_t;
    int64Value: int64_as_float_t;
    stringValue: CxxString;
    token: CxxString;
    [NativeType.ctor](): void;
    [NativeType.dtor](): void;
}
declare abstract class CommandEnumBase<BaseType, NewType> extends CommandMappedValue<BaseType, NewType> {
    readonly nameUtf8: StaticPointer;
    constructor(type: Type<BaseType>, symbol?: string, name?: string);
    getParser(): VoidPointer;
}
export declare abstract class CommandEnum<V> extends CommandEnumBase<EnumResult, V> {
    constructor(symbol: string, name?: string);
}
/**
 * built-in enum wrapper
 * one instance per one enum
 */
export declare class CommandRawEnum extends CommandEnum<string | number> {
    readonly name: string;
    private static readonly all;
    private enumIndex;
    private idRegistered;
    private parserType;
    isBuiltInEnum: boolean;
    private constructor();
    private _update;
    addValues(values: string[]): void;
    getValues(): string[];
    getValueCount(): number;
    mapValue(value: EnumResult): string | number;
    static getInstance(name: string): CommandRawEnum;
}
declare class CommandMappedEnum<V extends string | number | symbol> extends CommandEnum<V> {
    readonly mapper: Map<string, V>;
    private raw;
    protected _init(): void;
    mapValue(value: EnumResult): V;
}
export declare class CommandStringEnum<T extends string[]> extends CommandMappedEnum<T[number]> {
    readonly values: T;
    constructor(name: string, ...values: T);
}
export declare class CommandIndexEnum<T extends number | string> extends CommandMappedEnum<T> {
    readonly enum: Record<string, T>;
    constructor(name: string, enumType: Record<string, T>);
}
export declare class CommandSoftEnum extends CommandEnumBase<CxxString, string> {
    private static readonly all;
    private enumIndex;
    private constructor();
    protected updateValues(mode: SoftEnumUpdateType, values: string[]): void;
    getParser(): VoidPointer;
    mapValue(value: string): string;
    addValues(...values: string[]): void;
    addValues(values: string[]): void;
    removeValues(...values: string[]): void;
    removeValues(values: string[]): void;
    setValues(...values: string[]): void;
    setValues(values: string[]): void;
    getValues(): string[];
    getValueCount(): number;
    static getInstance(name: string): CommandSoftEnum;
}
export {};
