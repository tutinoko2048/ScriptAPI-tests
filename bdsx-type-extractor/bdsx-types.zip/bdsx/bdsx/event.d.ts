import { Color } from "colors";
import type { CommandContext } from "./bds/command";
import type { NetworkIdentifier } from "./bds/networkidentifier";
import { MinecraftPacketIds } from "./bds/packetids";
import { CANCEL } from "./common";
import type { BlockAttackEvent, BlockDestroyEvent, BlockDestructionStartEvent, BlockInteractedWithEvent, BlockPlaceEvent, ButtonPressEvent, CampfireTryDouseFire, CampfireTryLightFire, ChestOpenEvent, ChestPairEvent, FallOnBlockEvent, FarmlandDecayEvent, LightningHitBlockEvent, PistonCheckEvent, PistonMoveEvent, ProjectileHitBlockEvent, SculkSensorActivateEvent, SculkShriekEvent } from "./event_impl/blockevent";
import type { EntityCarriedItemChangedEvent, EntityConsumeTotemEvent, EntityCreatedEvent, EntityDieEvent, EntityHeathChangeEvent, EntityHurtEvent, EntityKnockbackEvent, EntitySneakEvent, EntityStartRidingEvent, EntityStartSwimmingEvent, EntityStopRidingEvent, ItemUseEvent, ItemUseOnBlockEvent, PlayerAttackEvent, PlayerCritEvent, PlayerDimensionChangeEvent, PlayerDropItemEvent, PlayerInteractEvent, PlayerInventoryChangeEvent, PlayerJoinEvent, PlayerJumpEvent, PlayerLeftEvent, PlayerLevelUpEvent, PlayerPickupItemEvent, PlayerRespawnEvent, PlayerSleepInBedEvent, PlayerUseItemEvent, ProjectileHitEvent, ProjectileShootEvent, SplashPotionHitEvent } from "./event_impl/entityevent";
import type { LevelExplodeEvent, LevelSaveEvent, LevelTickEvent, LevelWeatherChangeEvent } from "./event_impl/levelevent";
import type { ObjectiveCreateEvent, QueryRegenerateEvent, ScoreAddEvent, ScoreRemoveEvent, ScoreResetEvent, ScoreSetEvent } from "./event_impl/miscevent";
import { Event } from "./eventtarget";
import type { nethook } from "./nethook";
export declare namespace events {
    /** Cancellable */
    const blockDestroy: Event<(event: BlockDestroyEvent) => void | CANCEL>;
    /** Not cancellable */
    const blockDestructionStart: Event<(event: BlockDestructionStartEvent) => void>;
    /** Cancellable */
    const blockPlace: Event<(event: BlockPlaceEvent) => void | CANCEL>;
    /** Cancellable
     * Triggers when a piston checks a block. Cancelling this event will prevent blocks from being pushed by the piston.
     * This event will fire constantly if the piston is activated even if the event is cancelled.
     */
    const pistonCheck: Event<(event: PistonCheckEvent) => void | CANCEL>;
    /** Not cancellable */
    const pistonMove: Event<(event: PistonMoveEvent) => void>;
    /** Cancellable */
    const farmlandDecay: Event<(event: FarmlandDecayEvent) => void | CANCEL>;
    /** Cancellable but requires additional stimulation */
    const campfireLight: Event<(event: CampfireTryLightFire) => void | CANCEL>;
    /** Cancellable but requires additional stimulation */
    const campfireDouse: Event<(event: CampfireTryDouseFire) => void | CANCEL>;
    /** Cancellable but the client will have the motion and sound*/
    const buttonPress: Event<(event: ButtonPressEvent) => void | CANCEL>;
    /** Cancellable.
     * Triggered when a player opens a chest. Cancelling this event will prevent the player from opening the chest.
     * To note : This event works for all chest types (normal chests, trapped chests, ender chests).
     */
    const chestOpen: Event<(event: ChestOpenEvent) => void | CANCEL>;
    /** Cancellable.
     * Triggered when 2 chests are paired to form a double chest. Cancelling this event will prevent the chests from pairing.
     * To note : This event works for all chest types that can be doubled (normal chests, trapped chests).
     */
    const chestPair: Event<(event: ChestPairEvent) => void | CANCEL>;
    /** Cancellable but only in a few cases (e.g. interacting with the blocks such as anvil, grindstone, enchanting table, etc.*/
    const blockInteractedWith: Event<(event: BlockInteractedWithEvent) => void | CANCEL>;
    /** Not cancellable */
    const projectileHitBlock: Event<(event: ProjectileHitBlockEvent) => void>;
    /** Not cancellable */
    const lightningHitBlock: Event<(event: LightningHitBlockEvent) => void>;
    /** Not cancellable */
    const fallOnBlock: Event<(event: FallOnBlockEvent) => void>;
    /** Cancellable but only when the player is not in creative mode */
    const attackBlock: Event<(event: BlockAttackEvent) => void | CANCEL>;
    /** Cancellable */
    const sculkShriek: Event<(event: SculkShriekEvent) => void | CANCEL>;
    /** Cancellable */
    const sculkSensorActivate: Event<(event: SculkSensorActivateEvent) => void | CANCEL>;
    /** Cancellable */
    const entityHurt: Event<(event: EntityHurtEvent) => void | CANCEL>;
    /** Not cancellable */
    const entityHealthChange: Event<(event: EntityHeathChangeEvent) => void>;
    /**
     * Not cancellable.
     * it can be occurred multiple times even it already died.
     */
    const entityDie: Event<(event: EntityDieEvent) => void>;
    /** Not cancellable */
    const entitySneak: Event<(event: EntitySneakEvent) => void>;
    /** Cancellable */
    const entityStartSwimming: Event<(event: EntityStartSwimmingEvent) => void | CANCEL>;
    /** Cancellable */
    const entityStartRiding: Event<(event: EntityStartRidingEvent) => void | CANCEL>;
    /** Cancellable but the client is still exiting though it will automatically ride again after rejoin */
    const entityStopRiding: Event<(event: EntityStopRidingEvent) => void | CANCEL>;
    /**
     * Not cancellable
     * **NOT IMPLEMENTED**
     */
    const entityCarriedItemChanged: Event<(event: EntityCarriedItemChangedEvent) => void>;
    /** Cancellable */
    const playerAttack: Event<(event: PlayerAttackEvent) => void | CANCEL>;
    /** Cancellable */
    const playerInteract: Event<(event: PlayerInteractEvent) => void | CANCEL>;
    /** Cancellable */
    const playerDropItem: Event<(event: PlayerDropItemEvent) => void | CANCEL>;
    /** Not cancellable */
    const playerInventoryChange: Event<(event: PlayerInventoryChangeEvent) => void | CANCEL>;
    /** Not cancellable */
    const playerRespawn: Event<(event: PlayerRespawnEvent) => void | CANCEL>;
    /** Cancellable */
    const playerLevelUp: Event<(event: PlayerLevelUpEvent) => void | CANCEL>;
    /** Not cancellable */
    const entityCreated: Event<(event: EntityCreatedEvent) => void>;
    /** Not cancellable */
    const playerJoin: Event<(event: PlayerJoinEvent) => void>;
    /** Not cancellable */
    const playerLeft: Event<(event: PlayerLeftEvent) => void>;
    /** Cancellable */
    const playerPickupItem: Event<(event: PlayerPickupItemEvent) => void | CANCEL>;
    /** Not cancellable */
    const playerCrit: Event<(event: PlayerCritEvent) => void>;
    /** Not cancellable.
     * Triggered when a player finishes consuming an item.
     * (e.g : food, potion, etc...)
     */
    const playerUseItem: Event<(event: PlayerUseItemEvent) => void>;
    /** Cancellable.
     * Triggered when a player uses an item. Cancelling this event will prevent the item from being used.
     * (e.g : splash potion won't be thrown, food won't be consumed, etc...)
     * To note : this event is triggered with every item, even if they are not consumable.
     *
     * @remarks use `itemUseOnBlock` to cancel the usage of an item on a block (e.g : flint and steel)
     */
    const itemUse: Event<(event: ItemUseEvent) => void | CANCEL>;
    /** Cancellable.
     * Triggered when a player uses an item on a block. Cancelling this event will prevent the item from being used
     * (e.g : flint and steel won't ignite block, seeds won't be planted, buckets won't be filled or poured, etc...)
     * To note : this event is triggered with every item, even if they are not usable on blocks.
     */
    const itemUseOnBlock: Event<(event: ItemUseOnBlockEvent) => void | CANCEL>;
    /** Cancellable */
    const splashPotionHit: Event<(event: SplashPotionHitEvent) => void | CANCEL>;
    /** Not cancellable */
    const projectileShoot: Event<(event: ProjectileShootEvent) => void>;
    /** Not cancellable */
    const projectileHit: Event<(event: ProjectileHitEvent) => void>;
    /** Cancellable
     * Triggered when a player sleeps in a bed.
     * Cancelling this event will prevent the player from sleeping.
     */
    const playerSleepInBed: Event<(event: PlayerSleepInBedEvent) => void | CANCEL>;
    /** Not cancellable */
    const playerJump: Event<(event: PlayerJumpEvent) => void>;
    /** Not cancellable */
    const entityConsumeTotem: Event<(event: EntityConsumeTotemEvent) => void>;
    /** Cancellable
     * Triggered when a player changes dimension.
     * Cancelling this event will prevent the player from changing dimension (e.g : entering a nether portal).
     */
    const playerDimensionChange: Event<(event: PlayerDimensionChangeEvent) => void | CANCEL>;
    /** Cancellable.
     * Triggered when an entity has knockback applied to them (e.g : being hit by another entity).
     * Cancelling this event will prevent the knockback from being applied.
     */
    const entityKnockback: Event<(event: EntityKnockbackEvent) => void | CANCEL>;
    /** Cancellable */
    const levelExplode: Event<(event: LevelExplodeEvent) => void | CANCEL>;
    /** Not cancellable */
    const levelTick: Event<(event: LevelTickEvent) => void>;
    /** Cancellable but you won't be able to stop the server */
    const levelSave: Event<(event: LevelSaveEvent) => void | CANCEL>;
    /** Cancellable */
    const levelWeatherChange: Event<(event: LevelWeatherChangeEvent) => void | CANCEL>;
    /**
     * before launched. after execute the main thread of BDS.
     * BDS will be loaded on the separated thread. this event will be executed concurrently with the BDS loading
     * Usual scripts are no need to use this event. it's for plugin scripts that are loaded before BDS.
     */
    const serverLoading: Event<() => void>;
    /**
     * after BDS launched
     * Usual scripts are no need to use this event. it's for plugin scripts that are loaded before BDS.
     * or `bedrockServer.afterOpen().then(callback)` is usable for both situation.
     */
    const serverOpen: Event<() => void>;
    /**
     * on internal update. but it's not tick.
     * @deprecated useless and incomprehensible
     */
    const serverUpdate: Event<() => void>;
    /**
     * before serverStop, Minecraft is alive yet
     * LoopbackPacketSender is alive yet
     */
    const serverLeave: Event<() => void>;
    /**
     * before system.shutdown, Minecraft is alive yet
     * LoopbackPacketSender is destroyed
     * some commands are failed on this event. use `events.serverLeave` instead.
     */
    const serverStop: Event<() => void>;
    /**
     * after BDS closed
     */
    const serverClose: Event<() => void>;
    /**
     * server console outputs
     */
    const serverLog: Event<(log: string, color: Color) => void | CANCEL>;
    enum PacketEventType {
        Raw = 0,
        Before = 1,
        After = 2,
        Send = 3,
        SendRaw = 4
    }
    function packetEvent(type: PacketEventType, packetId: MinecraftPacketIds): Event<(...args: any[]) => void | CANCEL> | null;
    /**
     * before 'before' and 'after'
     * earliest event for the packet receiving.
     * It will bring raw packet buffers before parsing
     * It can be canceled the packet if you return 'CANCEL'
     */
    function packetRaw(id: MinecraftPacketIds): Event<nethook.RawListener>;
    /**
     * after 'raw', before 'after'
     * the event that before processing but after parsed from raw.
     * It can be canceled the packet if you return 'CANCEL'
     */
    function packetBefore<ID extends MinecraftPacketIds>(id: ID): Event<nethook.PacketListener<ID>>;
    /**
     * after 'raw' and 'before'
     * the event that after processing. some fields are assigned after the processing
     */
    function packetAfter<ID extends MinecraftPacketIds>(id: ID): Event<nethook.PacketListener<ID>>;
    /**
     * before serializing.
     * it can modify class fields.
     */
    function packetSend<ID extends MinecraftPacketIds>(id: ID): Event<nethook.PacketListener<ID>>;
    /**
     * after serializing. before sending.
     * it can access serialized buffer.
     */
    function packetSendRaw(id: number): Event<nethook.SendRawListener>;
    /** Not cancellable */
    const queryRegenerate: Event<(event: QueryRegenerateEvent) => void>;
    /** Cancellable */
    const scoreReset: Event<(event: ScoreResetEvent) => void | CANCEL>;
    /** Cancellable */
    const scoreSet: Event<(event: ScoreSetEvent) => void | CANCEL>;
    /** Cancellable */
    const scoreAdd: Event<(event: ScoreAddEvent) => void | CANCEL>;
    /** Cancellable */
    const scoreRemove: Event<(event: ScoreRemoveEvent) => void | CANCEL>;
    /** Cancellable */
    const objectiveCreate: Event<(event: ObjectiveCreateEvent) => void | CANCEL>;
    /**
     * global error listeners
     * if returns 'CANCEL', then default error printing is disabled
     */
    const error: Event<(error: any) => void | typeof CANCEL>;
    function errorFire(err: unknown): void;
    /**
     * command console outputs
     */
    const commandOutput: Event<(log: string) => void | CANCEL>;
    /**
     * command input
     * Commands will be canceled if you return a error code.
     * 0 means success for error codes but others are unknown.
     */
    const command: Event<(command: string, originName: string, ctx: CommandContext) => void | number>;
    /**
     * network identifier disconnected
     */
    const networkDisconnected: Event<(ni: NetworkIdentifier) => void>;
}
