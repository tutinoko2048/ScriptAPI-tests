export declare namespace key {
    function getGithubToken(): Promise<string | undefined>;
}
