/**
 * print warning once even it multiple
 */
export declare function bdsxWarningOnce(message: string): void;
export declare function bdsxEqualsAssert(actual: unknown, expected: unknown, message: string): void;
