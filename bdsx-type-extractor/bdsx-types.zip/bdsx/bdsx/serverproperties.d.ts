type ServerPropertiesKeys = "server-name" | "gamemode" | "force-gamemode" | "difficulty" | "allow-cheats" | "max-players" | "online-mode" | "white-list" | "server-port" | "server-portv6" | "view-distance" | "tick-distance" | "player-idle-timeout" | "max-threads" | "level-name" | "level-seed" | "default-player-permission-level" | "texturepack-required" | "content-log-file-enabled" | "compression-threshold" | "server-authoritative-movement" | "player-movement-score-threshold" | "player-movement-distance-threshold" | "player-movement-duration-threshold-in-ms" | "correct-player-movement" | "server-authoritative-block-breaking";
declare class Property {
    key: string;
    value: string;
    content: string;
    constructor(key: string, value: string, content: string);
}
export declare namespace spropsUtil {
    function read(content: string): IterableIterator<Property>;
    function merge(oldProps: string, newProps: string): string;
}
export declare const serverProperties: {
    [key in ServerPropertiesKeys]: string;
} & {
    [key: string]: string;
};
export {};
