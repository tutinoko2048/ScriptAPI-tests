export declare namespace wineCompatible {
    /**
     * it uses /bin/sh if it's on Wine.
     * use child_process.execSync on Windows.
     * @param cwd default is the project root.
     */
    function execSync(commandLine: string, cwd?: string): void;
    /**
     * bdsx cannot detect broken symlinks on Wine.
     * use shell for deleting them.
     * use fs methods on Windows.
     */
    function removeRecursiveSync(path: string): void;
}
