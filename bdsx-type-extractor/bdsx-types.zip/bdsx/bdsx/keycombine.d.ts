declare class CombinedKey {
}
export declare function combineObjectKey(obj1: Record<any, any>, obj2: Record<any, any>): CombinedKey;
export {};
