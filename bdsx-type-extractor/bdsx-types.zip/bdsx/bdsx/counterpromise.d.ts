export declare class CounterPromise {
    private resolve;
    private counter;
    private prom;
    increase(): void;
    decrease(): void;
    /**
     * wait till the counter is zero.
     */
    wait(): Promise<void>;
}
