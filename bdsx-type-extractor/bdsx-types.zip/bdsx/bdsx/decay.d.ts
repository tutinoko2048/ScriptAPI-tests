import { VoidPointer } from "./core";
declare const decayed: unique symbol;
declare module "./core" {
    interface VoidPointer {
        [decayed]: VoidPointer;
    }
}
/**
 * make it unusable.
 */
export declare function decay(obj: VoidPointer): void;
export declare namespace decay {
    function isDecayed(obj: VoidPointer): boolean;
}
export {};
