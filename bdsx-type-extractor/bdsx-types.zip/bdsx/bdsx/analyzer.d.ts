import { VoidPointer } from "./core";
export declare namespace analyzer {
    function loadMap(): void;
    interface AddressInfo {
        symbol?: string;
        address: string;
        address2?: string;
        ascii?: string;
    }
    function getAddressInfo(addr: VoidPointer): AddressInfo;
    function analyze(ptr: VoidPointer, count?: number): void;
}
