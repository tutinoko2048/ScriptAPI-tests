import { NativeClass } from "./nativeclass";
export declare class ThisGetter<DEST> {
    private readonly dest;
    private items;
    constructor(dest: DEST);
    register<T extends NativeClass>(type: new () => T, symbol: string, key: keyof DEST): void;
    finish(): void;
}
