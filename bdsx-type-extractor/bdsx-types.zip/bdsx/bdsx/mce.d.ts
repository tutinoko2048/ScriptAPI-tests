import { StaticPointer, VoidPointer } from "./core";
import { AbstractClass, NativeClass, NativeStruct } from "./nativeclass";
import { bin64_t, float32_t, NativeType, uint16_t, uint32_t, uint64_as_float_t } from "./nativetype";
export declare namespace mce {
    const UUID: NativeType<string> & {
        v1(uuid: UUID): uint32_t;
        v2(uuid: UUID): uint16_t;
        v3(uuid: UUID): uint16_t;
        v4(uuid: UUID): bin64_t;
        generate(): UUID;
        toString(uuid: UUID): string;
    };
    type UUID = string;
    const UUIDWrapper: import("./pointer").WrapperType<string>;
    class Color extends NativeStruct {
        r: float32_t;
        g: float32_t;
        b: float32_t;
        a: float32_t;
    }
    class Blob extends AbstractClass {
        deleter: VoidPointer;
        bytes: StaticPointer;
        size: uint64_as_float_t;
        [NativeType.ctor](): void;
        [NativeType.dtor](): void;
        toArray(): number[];
        setFromArray(bytes: number[]): void;
        toBuffer(): Uint8Array;
        setFromBuffer(bytes: Uint8Array): void;
    }
    enum ImageFormat {
        Unknown = 0,
        RGB8Unorm = 1,
        RGBA8Unorm = 2
    }
    enum ImageUsage {
        Unknown = 0,
        sRGB = 1,
        Data = 2
    }
    class Image extends NativeClass {
        imageFormat: ImageFormat;
        width: uint32_t;
        height: uint32_t;
        usage: ImageUsage;
        blob: mce.Blob;
    }
}
