import { Actor, ActorDamageSource, DimensionId, Mob } from "../bds/actor";
import { BlockPos, Vec3 } from "../bds/blockpos";
import { HitResult } from "../bds/components";
import { HandSlot, ItemStack, ItemStackBase } from "../bds/inventory";
import { CompletedUsingItemPacket } from "../bds/packets";
import { Player, ServerPlayer } from "../bds/player";
export declare class EntityHurtEvent {
    entity: Mob;
    damage: number;
    damageSource: ActorDamageSource;
    knock: boolean;
    ignite: boolean;
    constructor(entity: Mob, damage: number, damageSource: ActorDamageSource, knock: boolean, ignite: boolean);
}
export declare class EntityHeathChangeEvent {
    entity: Actor;
    readonly oldHealth: number;
    readonly newHealth: number;
    constructor(entity: Actor, oldHealth: number, newHealth: number);
}
export declare class EntityDieEvent {
    entity: Mob;
    damageSource: ActorDamageSource;
    constructor(entity: Mob, damageSource: ActorDamageSource);
}
export declare class EntityStartSwimmingEvent {
    entity: Actor;
    constructor(entity: Actor);
}
export declare class EntityStartRidingEvent {
    entity: Actor;
    ride: Actor;
    constructor(entity: Actor, ride: Actor);
}
export declare class EntityStopRidingEvent {
    entity: Actor;
    exitFromRider: boolean;
    actorIsBeingDestroyed: boolean;
    switchingRides: boolean;
    constructor(entity: Actor, exitFromRider: boolean, actorIsBeingDestroyed: boolean, switchingRides: boolean);
}
export declare class EntitySneakEvent {
    entity: Actor;
    isSneaking: boolean;
    constructor(entity: Actor, isSneaking: boolean);
}
export declare class EntityCreatedEvent {
    entity: Actor;
    constructor(entity: Actor);
}
export declare class PlayerAttackEvent {
    player: Player;
    victim: Actor;
    constructor(player: Player, victim: Actor);
}
export declare class PlayerInteractEvent {
    player: Player;
    victim: Actor;
    interactPos: Vec3;
    constructor(player: Player, victim: Actor, interactPos: Vec3);
}
export declare class PlayerDropItemEvent {
    player: Player;
    itemStack: ItemStack;
    inContainer: boolean;
    hotbarSlot?: number | undefined;
    constructor(player: Player, itemStack: ItemStack, inContainer: boolean, hotbarSlot?: number | undefined);
}
export declare class PlayerInventoryChangeEvent {
    player: Player;
    readonly oldItemStack: ItemStack;
    readonly newItemStack: ItemStack;
    readonly slot: number;
    constructor(player: Player, oldItemStack: ItemStack, newItemStack: ItemStack, slot: number);
}
export declare class PlayerRespawnEvent {
    player: Player;
    constructor(player: Player);
}
export declare class PlayerLevelUpEvent {
    player: Player;
    /** Amount of levels upgraded */
    levels: number;
    constructor(player: Player, 
    /** Amount of levels upgraded */
    levels: number);
}
export declare class PlayerJoinEvent {
    readonly player: ServerPlayer;
    readonly isSimulated: boolean;
    constructor(player: ServerPlayer, isSimulated: boolean);
}
export declare class PlayerLeftEvent {
    player: ServerPlayer;
    skipMessage: boolean;
    constructor(player: ServerPlayer, skipMessage: boolean);
}
export declare class PlayerPickupItemEvent {
    player: Player;
    /**
     * itemActor is not ItemActor always.
     * it can be the arrow or trident.
     */
    itemActor: Actor;
    constructor(player: Player, 
    /**
     * itemActor is not ItemActor always.
     * it can be the arrow or trident.
     */
    itemActor: Actor);
}
export declare class PlayerCritEvent {
    player: Player;
    victim: Actor;
    constructor(player: Player, victim: Actor);
}
export declare class PlayerUseItemEvent {
    player: Player;
    useMethod: CompletedUsingItemPacket.Actions;
    consumeItem: boolean;
    itemStack: ItemStack;
    constructor(player: Player, useMethod: CompletedUsingItemPacket.Actions, consumeItem: boolean, itemStack: ItemStack);
}
export declare class ItemUseEvent {
    itemStack: ItemStack;
    player: Player;
    constructor(itemStack: ItemStack, player: Player);
}
export declare class ItemUseOnBlockEvent {
    itemStack: ItemStack;
    actor: Actor;
    x: number;
    y: number;
    z: number;
    face: number;
    clickX: number;
    clickY: number;
    clickZ: number;
    constructor(itemStack: ItemStack, actor: Actor, x: number, y: number, z: number, face: number, clickX: number, clickY: number, clickZ: number);
}
export declare class PlayerJumpEvent {
    player: Player;
    constructor(player: Player);
}
export declare class SplashPotionHitEvent {
    entity: Actor;
    potionEffect: number;
    constructor(entity: Actor, potionEffect: number);
}
export declare class ProjectileShootEvent {
    projectile: Actor;
    shooter: Actor;
    constructor(projectile: Actor, shooter: Actor);
}
export declare class PlayerSleepInBedEvent {
    player: Player;
    pos: BlockPos;
    constructor(player: Player, pos: BlockPos);
}
export declare class EntityConsumeTotemEvent {
    entity: Actor;
    totem: ItemStack;
    constructor(entity: Actor, totem: ItemStack);
}
export declare class PlayerDimensionChangeEvent {
    player: ServerPlayer;
    dimension: DimensionId;
    /** @deprecated deleted parameter */
    useNetherPortal: boolean;
    constructor(player: ServerPlayer, dimension: DimensionId, 
    /** @deprecated deleted parameter */
    useNetherPortal: boolean);
}
export declare class ProjectileHitEvent {
    projectile: Actor;
    victim: Actor | null;
    result: HitResult;
    constructor(projectile: Actor, victim: Actor | null, result: HitResult);
}
export declare class EntityCarriedItemChangedEvent {
    entity: Actor;
    oldItemStack: ItemStackBase;
    newItemStack: ItemStackBase;
    handSlot: HandSlot;
    constructor(entity: Actor, oldItemStack: ItemStackBase, newItemStack: ItemStackBase, handSlot: HandSlot);
}
export declare class EntityKnockbackEvent {
    target: Mob;
    source: Actor | null;
    damage: number;
    xd: number;
    zd: number;
    power: number;
    height: number;
    heightCap: number;
    constructor(target: Mob, source: Actor | null, damage: number, xd: number, zd: number, power: number, height: number, heightCap: number);
}
