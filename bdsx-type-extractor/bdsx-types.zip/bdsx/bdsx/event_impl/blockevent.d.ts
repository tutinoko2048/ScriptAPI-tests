import { Actor } from "../bds/actor";
import { Block, BlockSource, ButtonBlock, ChestBlock, ChestBlockActor, PistonAction as PistonActorInBlockModule } from "../bds/block";
import { BlockPos } from "../bds/blockpos";
import { ItemStack } from "../bds/inventory";
import { Player, ServerPlayer } from "../bds/player";
export declare class BlockDestroyEvent {
    player: ServerPlayer;
    blockPos: BlockPos;
    blockSource: BlockSource;
    itemStack: ItemStack;
    /**
     * controls whether the server sends a deny effect, and is always 0 in all cases with the destroyer being a player
     * @deprecated not implemented
     */
    generateParticle: boolean;
    constructor(player: ServerPlayer, blockPos: BlockPos, blockSource: BlockSource, itemStack: ItemStack, 
    /**
     * controls whether the server sends a deny effect, and is always 0 in all cases with the destroyer being a player
     * @deprecated not implemented
     */
    generateParticle: boolean);
}
export declare class BlockDestructionStartEvent {
    player: ServerPlayer;
    blockPos: BlockPos;
    constructor(player: ServerPlayer, blockPos: BlockPos);
}
export declare class BlockPlaceEvent {
    player: ServerPlayer;
    block: Block;
    blockSource: BlockSource;
    blockPos: BlockPos;
    constructor(player: ServerPlayer, block: Block, blockSource: BlockSource, blockPos: BlockPos);
}
export declare class PistonCheckEvent {
    blockPos: BlockPos;
    blockSource: BlockSource;
    action: PistonActorInBlockModule;
    affectedBlocks: BlockPos[];
    facingDirection: BlockPos;
    constructor(blockPos: BlockPos, blockSource: BlockSource, action: PistonActorInBlockModule, affectedBlocks: BlockPos[], facingDirection: BlockPos);
}
/** @deprecated import it from bdsx/bds/block.ts */
export declare const PistonAction: typeof PistonActorInBlockModule;
/** @deprecated import it from bdsx/bds/block.ts */
export type PistonAction = PistonActorInBlockModule;
export declare class PistonMoveEvent {
    blockPos: BlockPos;
    blockSource: BlockSource;
    action: PistonActorInBlockModule;
    affectedBlocks: BlockPos[];
    facingDirection: BlockPos;
    constructor(blockPos: BlockPos, blockSource: BlockSource, action: PistonActorInBlockModule, affectedBlocks: BlockPos[], facingDirection: BlockPos);
}
export declare class FarmlandDecayEvent {
    block: Block;
    blockPos: BlockPos;
    blockSource: BlockSource;
    culprit: Actor;
    constructor(block: Block, blockPos: BlockPos, blockSource: BlockSource, culprit: Actor);
}
export declare class CampfireTryLightFire {
    blockPos: BlockPos;
    blockSource: BlockSource;
    actor: Actor;
    constructor(blockPos: BlockPos, blockSource: BlockSource, actor: Actor);
}
export declare class CampfireTryDouseFire {
    blockPos: BlockPos;
    blockSource: BlockSource;
    actor: Actor;
    constructor(blockPos: BlockPos, blockSource: BlockSource, actor: Actor);
}
export declare class ButtonPressEvent {
    buttonBlock: ButtonBlock;
    player: Player;
    blockPos: BlockPos;
    playerOrientation: number;
    constructor(buttonBlock: ButtonBlock, player: Player, blockPos: BlockPos, playerOrientation: number);
}
export declare class ChestOpenEvent {
    chestBlock: ChestBlock;
    player: Player;
    blockPos: BlockPos;
    face: number;
    constructor(chestBlock: ChestBlock, player: Player, blockPos: BlockPos, face: number);
}
export declare class ChestPairEvent {
    readonly chest: ChestBlockActor;
    readonly chest2: ChestBlockActor;
    readonly lead: boolean;
    /**
     * @param lead - Whether the chest is the lead chest.
     */
    constructor(chest: ChestBlockActor, chest2: ChestBlockActor, lead: boolean);
}
export declare class BlockInteractedWithEvent {
    player: Player;
    blockPos: BlockPos;
    constructor(player: Player, blockPos: BlockPos);
}
export declare class ProjectileHitBlockEvent {
    block: Block;
    region: BlockSource;
    blockPos: BlockPos;
    projectile: Actor;
    constructor(block: Block, region: BlockSource, blockPos: BlockPos, projectile: Actor);
}
export declare class LightningHitBlockEvent {
    block: Block;
    region: BlockSource;
    blockPos: BlockPos;
    constructor(block: Block, region: BlockSource, blockPos: BlockPos);
}
export declare class FallOnBlockEvent {
    block: Block;
    region: BlockSource;
    blockPos: BlockPos;
    entity: Actor;
    height: number;
    constructor(block: Block, region: BlockSource, blockPos: BlockPos, entity: Actor, height: number);
}
export declare class BlockAttackEvent {
    block: Block;
    player: Player | null;
    blockPos: BlockPos;
    constructor(block: Block, player: Player | null, blockPos: BlockPos);
}
export declare class SculkShriekEvent {
    region: BlockSource;
    blockPos: BlockPos;
    entity: Actor | null;
    constructor(region: BlockSource, blockPos: BlockPos, entity: Actor | null);
}
export declare class SculkSensorActivateEvent {
    region: BlockSource;
    pos: BlockPos;
    entity: Actor | null;
    constructor(region: BlockSource, pos: BlockPos, entity: Actor | null);
}
