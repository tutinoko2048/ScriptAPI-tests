import { Objective, ObjectiveCriteria, ScoreboardIdentityRef } from "../bds/scoreboard";
export declare class QueryRegenerateEvent {
    motd: string;
    levelname: string;
    currentPlayers: number;
    maxPlayers: number;
    isJoinableThroughServerScreen: boolean;
    constructor(motd: string, levelname: string, currentPlayers: number, maxPlayers: number, isJoinableThroughServerScreen: boolean);
}
export declare class ScoreResetEvent {
    identityRef: ScoreboardIdentityRef;
    objective: Objective;
    constructor(identityRef: ScoreboardIdentityRef, objective: Objective);
}
export declare class ScoreSetEvent {
    identityRef: ScoreboardIdentityRef;
    objective: Objective;
    /** The score to be set */
    score: number;
    constructor(identityRef: ScoreboardIdentityRef, objective: Objective, 
    /** The score to be set */
    score: number);
}
export declare class ScoreAddEvent extends ScoreSetEvent {
    identityRef: ScoreboardIdentityRef;
    objective: Objective;
    /** The score to be added */
    score: number;
    constructor(identityRef: ScoreboardIdentityRef, objective: Objective, 
    /** The score to be added */
    score: number);
}
export declare class ScoreRemoveEvent extends ScoreSetEvent {
    identityRef: ScoreboardIdentityRef;
    objective: Objective;
    /** The score to be removed */
    score: number;
    constructor(identityRef: ScoreboardIdentityRef, objective: Objective, 
    /** The score to be removed */
    score: number);
}
export declare class ObjectiveCreateEvent {
    name: string;
    displayName: string;
    criteria: ObjectiveCriteria;
    constructor(name: string, displayName: string, criteria: ObjectiveCriteria);
}
