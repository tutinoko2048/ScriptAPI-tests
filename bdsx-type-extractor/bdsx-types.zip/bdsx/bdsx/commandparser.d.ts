import { CommandSymbols } from "./bds/cmdsymbolloader";
import { StaticPointer, VoidPointer } from "./core";
import { CommandParameterNativeType, Type as DataType, Type } from "./nativetype";
/**
 * The command parameter type with the type converter
 */
export declare abstract class CommandMappedValue<BaseType, NewType = BaseType> extends CommandParameterNativeType<BaseType> {
    readonly nameUtf8?: StaticPointer;
    constructor(type: Type<BaseType>, symbol?: string, name?: string);
    abstract mapValue(value: BaseType): NewType;
    getParser?(): VoidPointer;
}
export declare namespace commandParser {
    enum Type {
        Unknown = 0,
        Int = 1,
        String = 2
    }
    function get<T>(type: DataType<T>): VoidPointer;
    function has<T>(type: DataType<T>): boolean;
    function load(symbols: CommandSymbols): void;
    function set(type: DataType<any>, parserFnPointer: VoidPointer): void;
    /**
     * @deprecated no need to use
     */
    function setEnumParser(parserFnPointer: VoidPointer): void;
    function getType(parser: VoidPointer): Type;
}
