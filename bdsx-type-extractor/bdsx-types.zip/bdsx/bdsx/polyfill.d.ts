declare global {
    interface Blob {
        __dummy?: void;
    }
    interface SymbolConstructor {
        readonly dispose: unique symbol;
        readonly asyncDispose: unique symbol;
    }
    interface Disposable {
        [Symbol.dispose](): void;
    }
}
export {};
