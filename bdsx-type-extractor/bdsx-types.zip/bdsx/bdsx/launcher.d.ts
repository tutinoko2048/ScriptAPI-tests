import { Bedrock } from "./bds/bedrock";
import { CommandOutputSender, CommandPermissionLevel, CommandRegistry, MinecraftCommands } from "./bds/command";
import { Dimension } from "./bds/dimension";
import { GameRules } from "./bds/gamerules";
import { ServerLevel } from "./bds/level";
import * as nimodule from "./bds/networkidentifier";
import { RakNet } from "./bds/raknet";
import { RakNetConnector } from "./bds/raknetinstance";
import * as bd_server from "./bds/server";
import { StructureManager } from "./bds/structure";
import type { CommandResult, CommandResultType } from "./commandresult";
declare module "colors" {
    const brightRed: Color;
    const brightGreen: Color;
    const brightYellow: Color;
    const brightBlue: Color;
    const brightMagenta: Color;
    const brightCyan: Color;
    const brightWhite: Color;
}
export declare namespace bedrockServer {
    let sessionId: string;
    let serverInstance: bd_server.ServerInstance;
    let networkHandler: nimodule.NetworkSystem;
    let networkSystem: nimodule.NetworkSystem;
    let minecraft: bd_server.Minecraft;
    let level: ServerLevel;
    let serverNetworkHandler: nimodule.ServerNetworkHandler;
    let dedicatedServer: bd_server.DedicatedServer;
    let minecraftCommands: MinecraftCommands;
    let commandRegistry: CommandRegistry;
    let gameRules: GameRules;
    /**
     * @alias bedrockServer.connector
     */
    let raknetInstance: RakNetConnector;
    let connector: RakNetConnector;
    let rakPeer: RakNet.RakPeer;
    let commandOutputSender: CommandOutputSender;
    let nonOwnerPointerServerNetworkHandler: Bedrock.NonOwnerPointer<nimodule.ServerNetworkHandler>;
    let structureManager: StructureManager;
    function withLoading(): Promise<void>;
    function afterOpen(): Promise<void>;
    /**
     * @remark It does not check BDS is loaded fully. It only checks the launch is called.
     * @deprecated Not intuitive & Useless.
     */
    function isLaunched(): boolean;
    function isClosed(): boolean;
    /**
     * stop the BDS
     * It will stop next tick
     */
    function stop(): void;
    function forceKill(exitCode: number): never;
    function launch(): Promise<void>;
    /**
     * pass to stdin
     */
    function executeCommandOnConsole(command: string): void;
    function executeCommand(command: `testfor ${string}`, mute?: CommandResultType, permissionLevel?: CommandPermissionLevel, dimension?: Dimension | null): CommandResult<CommandResult.TestFor>;
    function executeCommand(command: `testforblock ${string}`, mute?: CommandResultType, permissionLevel?: CommandPermissionLevel, dimension?: Dimension | null): CommandResult<CommandResult.TestForBlock>;
    function executeCommand(command: `testforblocks ${string}`, mute?: CommandResultType, permissionLevel?: CommandPermissionLevel, dimension?: Dimension | null): CommandResult<CommandResult.TestForBlocks>;
    function executeCommand(command: "list", mute?: CommandResultType, permissionLevel?: CommandPermissionLevel, dimension?: Dimension | null): CommandResult<CommandResult.List>;
    /**
     * it does the same thing with executeCommandOnConsole
     * but call the internal function directly
     * @param mute suppress outputs if true, returns data if null
     */
    function executeCommand(command: string, mute?: CommandResultType, permissionLevel?: CommandPermissionLevel | null, dimension?: Dimension | null): CommandResult<CommandResult.Any>;
    abstract class DefaultStdInHandler {
        protected online: (line: string) => void;
        protected readonly onclose: () => void;
        protected constructor();
        abstract close(): void;
        static install(): DefaultStdInHandler;
    }
    /**
     * this handler has bugs on Linux+Wine
     */
    class NodeStdInHandler extends DefaultStdInHandler {
        private readonly rl;
        constructor();
        close(): void;
        static install(): NodeStdInHandler;
    }
    class NativeStdInHandler extends DefaultStdInHandler {
        private readonly getline;
        constructor();
        close(): void;
        static install(): NativeStdInHandler;
    }
}
