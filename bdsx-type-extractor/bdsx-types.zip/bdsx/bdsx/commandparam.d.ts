import type { Type } from "./nativetype";
export declare namespace CommandParameterType {
    /**
     * fake symbol for the type checking
     */
    const symbol: unique symbol;
}
export interface CommandParameterType<T> extends Type<T> {
    [CommandParameterType.symbol]: true;
}
