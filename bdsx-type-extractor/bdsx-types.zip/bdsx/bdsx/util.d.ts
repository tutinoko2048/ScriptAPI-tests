export declare function memdiff(dst: (number | null)[] | Uint8Array, src: (number | null)[] | Uint8Array): number[];
export declare function memdiff_contains(larger: number[] | undefined | null, smaller: number[]): boolean;
export declare function memcheck(code: Uint8Array, originalCode: number[], skip?: number[]): number[] | null;
export declare function hexn(value: number, hexcount: number): string;
export declare function hex(values: (number | null)[] | Uint8Array | number, nextLinePer?: number): string;
export declare function unhex(hex: string): Uint8Array;
export declare const _tickCallback: () => void;
/**
 * @param lineIndex first line is zero
 */
export declare function indexOfLine(context: string, lineIndex: number, p?: number): number;
/**
 * removeLine("a \n b \n c", 1, 2) === "a \n c"
 * @param lineFrom first line is zero
 * @param lineTo first line is one
 */
export declare function removeLine(context: string, lineFrom: number, lineTo: number): string;
/**
 * @param lineIndex first line is zero
 */
export declare function getLineAt(context: string, lineIndex: number): string;
export declare function isBaseOf<BASE extends {
    new (...args: any[]): any;
}>(t: unknown, base: BASE): t is BASE;
/**
 * @deprecated Use `util.inspect(v)` instead.
 */
export declare function anyToString(v: unknown): string;
export declare function str2set(str: string): Set<number>;
export declare function arrayEquals(arr1: ArrayLike<any>, arr2: ArrayLike<any>, count?: number): boolean;
export declare function assertDeepEquals(a: unknown, b: unknown): void;
export declare function makeSignature(sig: string): number;
export declare function checkPowOf2(n: number): void;
export declare function numberWithFillZero(n: number, width: number, radix?: number): string;
export declare function filterToIdentifierableString(name: string): string;
export declare function printOnProgress(message: string): void;
export declare function getEnumKeys<T extends Record<string, number | string>>(enumType: T): (keyof T)[];
export type DeferPromise<T> = Promise<T> & {
    resolve: (value?: T | PromiseLike<T>) => void;
    reject: (reason?: any) => void;
};
export declare namespace DeferPromise {
    function make<T>(): DeferPromise<T>;
}
export declare function addSlashes(str: string): string;
export declare function stripSlashes(str: string): string;
export declare function hashString(v: string): number;
export declare function timeout(timeout: number): Promise<void>;
export declare const ESCAPE = "\u00A7";
export declare const TextFormat: {
    readonly BLACK: string;
    readonly DARK_BLUE: string;
    readonly DARK_GREEN: string;
    readonly DARK_AQUA: string;
    readonly DARK_RED: string;
    readonly DARK_PURPLE: string;
    readonly GOLD: string;
    readonly GRAY: string;
    readonly DARK_GRAY: string;
    readonly BLUE: string;
    readonly GREEN: string;
    readonly AQUA: string;
    readonly RED: string;
    readonly LIGHT_PURPLE: string;
    readonly YELLOW: string;
    readonly WHITE: string;
    readonly RESET: string;
    readonly OBFUSCATED: string;
    readonly BOLD: string;
    readonly STRIKETHROUGH: string;
    readonly UNDERLINE: string;
    readonly ITALIC: string;
    readonly THIN: string;
};
