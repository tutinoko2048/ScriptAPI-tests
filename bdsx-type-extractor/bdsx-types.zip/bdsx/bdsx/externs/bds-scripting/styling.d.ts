export declare namespace styling {
    function toCamelStyle(content: string, seperator: string | RegExp, firstUpper?: boolean): string;
    function apiObjectNameToInterfaceName(id: string): string | null;
    function toFieldName(name: string): string;
}
