import { HTMLElement, Node, NodeType } from "node-html-parser";
export declare class HtmlRule {
    readonly filter: htmlutil.Filter;
    constructor(filter: htmlutil.Filter);
    readonly finally: (() => Promise<void> | void)[];
}
export declare namespace htmlutil {
    type Filter = {
        tag?: string;
        id?: string;
        class?: string;
        type?: NodeType;
    } | number | string | ((node: HTMLElement) => any) | Filter[];
    function childrenFilter(node: Node, opts: Filter): IterableIterator<HTMLElement>;
    function get(node: Node, opt: Filter): Node | null;
    function follow(node: Node, ...opts: Filter[]): Node | null;
    function check(node: Node, opt: Filter, index?: number): boolean;
    function checks(node: Node, opt: Filter, ...opts: Filter[]): Node | null;
    function tableToObject(table: HTMLElement): HtmlSearcher.TableRow[];
    function wgetText(url: string): Promise<string>;
    function wgetElement(url: string, ...followFilter: Filter[]): Promise<Node | null>;
}
export declare class HtmlSearcher {
    base: Node;
    private index;
    private readonly rules;
    private readonly queue;
    constructor(base: Node);
    current(): HTMLElement;
    nextIf(filter: htmlutil.Filter): HTMLElement | null;
    next(): HTMLElement;
    search(filter: htmlutil.Filter): HTMLElement;
    searchTableAsObject(): HtmlSearcher.TableRow[];
    searchHead(): string | null;
    inside(target: HTMLElement, fn: () => Promise<void> | void): Promise<void>;
    onexit(final: () => Promise<void> | void): void;
    enter(target: HTMLElement): void;
    leave(): void;
    static readonly EOF: {};
}
export declare namespace HtmlSearcher {
    interface TableRow {
        [key: string]: {
            text: string;
            table?: TableRow[];
        };
    }
}
