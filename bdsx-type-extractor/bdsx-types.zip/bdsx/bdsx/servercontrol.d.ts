export namespace serverControl {
    function stop(): void;
}
