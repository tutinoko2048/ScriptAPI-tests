export declare class ScriptWriter {
    script: string;
    private tabstr;
    tab(n: number): void;
    writeln(line: string): void;
}
