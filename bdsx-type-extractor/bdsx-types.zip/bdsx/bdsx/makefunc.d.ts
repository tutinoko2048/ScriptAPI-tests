/// <reference types="node" />
/// <reference types="node" />
import * as util from "util";
import { asm } from "./assembler";
import "./codealloc";
import { Bufferable, Encoding } from "./common";
import { chakraUtil, NativePointer, StaticPointer, VoidPointer } from "./core";
export type ParamType = makefunc.Paramable;
type InstanceTypeOnly<T> = T extends {
    prototype: infer V;
} ? V : never;
type TypeFrom_js2np<T extends ParamType> = InstanceTypeOnly<T> | null | undefined;
type TypeFrom_np2js<T extends ParamType> = InstanceTypeOnly<T>;
export type TypesFromParamIds_js2np<T extends ParamType[]> = {
    [key in keyof T]: T[key] extends null ? void : T[key] extends ParamType ? TypeFrom_js2np<T[key]> : T[key];
};
export type TypesFromParamIds_np2js<T extends ParamType[]> = {
    [key in keyof T]: T[key] extends null ? void : T[key] extends ParamType ? TypeFrom_np2js<T[key]> : T[key];
};
export interface MakeFuncOptions<THIS extends {
    new (): VoidPointer | void;
}> {
    /**
     * *Pointer, 'this' parameter passes as first parameter.
     */
    this?: THIS;
    /**
     * it allocates at the first parameter with the returning class and returns it.
     * if this is defined, it allocates at the second parameter.
     */
    structureReturn?: boolean;
    /**
     * Option for native debugging
     */
    nativeDebugBreak?: boolean;
    /**
     * Option for JS debugging
     */
    jsDebugBreak?: boolean;
    /**
     * for makefunc.np
     * jump to onError when JsCallFunction is failed (js exception, wrong thread, etc)
     */
    onError?: VoidPointer | null;
    /**
     * allow calling this function from somewhere other than the game thread.
     * it will ignore the onError parameter.
     *
     * technically it's possible to block the worker till the end of JS processing.
     */
    crossThread?: boolean;
    /**
     * code chunk name, default: js function name
     */
    name?: string;
    /**
     * it's only called once.
     * it will reduce references for memory optimization.
     * but BDSX may crash if it's called twice.
     */
    onlyOnce?: boolean;
}
type GetThisFromOpts<OPTS extends MakeFuncOptions<any> | null> = OPTS extends MakeFuncOptions<infer THIS> ? THIS extends {
    new (): VoidPointer;
} ? InstanceType<THIS> : void : void;
export type FunctionFromTypes_np<OPTS extends MakeFuncOptions<any> | null, PARAMS extends ParamType[], RETURN extends ParamType> = (this: GetThisFromOpts<OPTS>, ...args: TypesFromParamIds_np2js<PARAMS>) => TypeFrom_js2np<RETURN>;
export type FunctionFromTypes_js<PTR extends VoidPointer | readonly [number, number?], OPTS extends MakeFuncOptions<any> | null, PARAMS extends ParamType[], RETURN extends ParamType> = ((this: GetThisFromOpts<OPTS>, ...args: TypesFromParamIds_js2np<PARAMS>) => TypeFrom_np2js<RETURN>) & {
    pointer: PTR;
};
export type FunctionFromTypes_js_without_pointer<OPTS extends MakeFuncOptions<any> | null, PARAMS extends ParamType[], RETURN extends ParamType> = (this: GetThisFromOpts<OPTS>, ...args: TypesFromParamIds_js2np<PARAMS>) => TypeFrom_np2js<RETURN>;
export declare namespace makefunc {
    const temporalKeeper: any[];
    /**
     * get the value from the pointer.
     */
    const getter: unique symbol;
    /**
     * set the value to the pointer.
     */
    const setter: unique symbol;
    /**
     * set the value from the register.
     * Passed directly to registers via temporary stack memory.
     */
    const setToParam: unique symbol;
    /**
     * get the value from the register
     * Passed directly from registers via temporary stack memory.
     */
    const getFromParam: unique symbol;
    /**
     * it's a floating point.
     * need to be passed as xmm registers
     */
    const useXmmRegister: unique symbol;
    /**
     * the parameter will be passed as a pointer that points to stack space.
     * it cannot be returned on makefunc.np
     *
     * flag for the native type
     */
    const paramHasSpace: unique symbol;
    /**
     * constructor
     */
    const ctor: unique symbol;
    /**
     * destructor
     */
    const dtor: unique symbol;
    /**
     * move constructor
     */
    const ctor_move: unique symbol;
    /**
     * size of the type
     */
    const size: unique symbol;
    /**
     * alignment of the type
     */
    const align: unique symbol;
    /**
     * this class is not stored in the stack on function calls.
     * it is just assigned to the register directly.
     *
     * flag for the class
     */
    const registerDirect: unique symbol;
    interface Paramable {
        symbol: string;
        name: string;
        [getter](ptr: StaticPointer, offset?: number): any;
        [setter](ptr: StaticPointer, value: any, offset?: number): void;
        [getFromParam](stackptr: StaticPointer, offset?: number): any;
        [setToParam](stackptr: StaticPointer, param: any, offset?: number): void;
        [useXmmRegister]: boolean;
        [paramHasSpace]: boolean;
        [ctor](ptr: StaticPointer): void;
        [ctor_move](to: StaticPointer, from: StaticPointer): void;
        [dtor](ptr: StaticPointer): void;
        [size]: number;
        [align]: number;
        [registerDirect]?: boolean;
        isTypeOf(v: unknown): boolean;
        /**
         * allow downcasting
         */
        isTypeOfWeak(v: unknown): boolean;
    }
    interface ParamableT<T> extends Paramable {
        prototype: T;
        [getFromParam](stackptr: StaticPointer, offset?: number): T | null;
        [setToParam](stackptr: StaticPointer, param: T extends VoidPointer ? T | null : T, offset?: number): void;
        [useXmmRegister]: boolean;
        isTypeOf<V>(this: {
            prototype: V;
        }, v: unknown): v is V;
        isTypeOfWeak(v: unknown): boolean;
    }
    class ParamableT<T> {
        readonly name: string;
        constructor(name: string, _getFromParam: (stackptr: StaticPointer, offset?: number) => T | null, _setToParam: (stackptr: StaticPointer, param: T extends VoidPointer ? T | null : T, offset?: number) => void, isTypeOf: (v: unknown) => boolean, isTypeOfWeak?: (v: unknown) => boolean);
    }
    /**
     * allocate temporal memory for using in NativeType
     * it will removed at native returning
     */
    function tempAlloc(size: number): StaticPointer;
    /**
     * allocate temporal memory for using in NativeType
     * it will removed at native returning
     */
    function tempValue(type: Paramable, value: unknown): StaticPointer;
    /**
     * allocate temporal string for using in NativeType
     * it will removed at native returning
     */
    function tempString(str: string, encoding?: Encoding): StaticPointer;
    function npRaw(func: (stackptr: NativePointer) => void, onError: VoidPointer, opts?: {
        name?: string;
        nativeDebugBreak?: boolean;
    } | null): VoidPointer;
    /**
     * make the JS function as a native function.
     *
     * wrapper codes are not deleted permanently.
     * do not use it dynamically.
     */
    function np<RETURN extends ParamType, OPTS extends MakeFuncOptions<any> | null, PARAMS extends ParamType[]>(jsfunction: FunctionFromTypes_np<OPTS, PARAMS, RETURN>, returnType: RETURN, opts?: OPTS, ...params: PARAMS): VoidPointer;
    /**
     * make the native function as a JS function.
     *
     * @param returnType *_t or *Pointer
     * @param params *_t or *Pointer
     */
    function js<PTR extends VoidPointer | readonly [number, number?], OPTS extends MakeFuncOptions<any> | null, RETURN extends ParamType, PARAMS extends ParamType[]>(functionPointer: PTR, returnType: RETURN, opts?: OPTS, ...params: PARAMS): FunctionFromTypes_js<PTR, OPTS, PARAMS, RETURN>;
    export import asJsValueRef = chakraUtil.asJsValueRef;
    const Ansi: ParamableT<string>;
    const Utf8: ParamableT<string>;
    const Utf16: ParamableT<string>;
    const Buffer: ParamableT<Bufferable | VoidPointer>;
    const JsValueRef: ParamableT<any>;
}
export interface MakeFuncOptionsWithName<THIS extends {
    new (): VoidPointer | void;
}> extends MakeFuncOptions<THIS> {
    /**
     * name of the native stack trace
     */
    name?: string;
}
declare module "./assembler" {
    interface X64Assembler {
        /**
         * asm.alloc + makefunc.js
         * allocates it on the executable memory. and make it as a JS function.
         */
        make<OPTS extends MakeFuncOptionsWithName<any> | null, RETURN extends ParamType, PARAMS extends ParamType[]>(returnType: RETURN, opts?: OPTS, ...params: PARAMS): FunctionFromTypes_js<StaticPointer, OPTS, PARAMS, RETURN>;
    }
    namespace asm {
        function const_str(str: string, encoding?: BufferEncoding): Buffer;
    }
}
declare module "./core" {
    interface VoidPointerConstructor extends makefunc.Paramable {
        isTypeOf<T>(this: {
            new (): T;
        }, v: unknown): v is T;
    }
    interface VoidPointer {
        [asm.splitTwo32Bits](): [number, number];
        [util.inspect.custom](depth: number, options: Record<string, any>): unknown;
    }
}
declare global {
    interface Uint8Array {
        [asm.splitTwo32Bits](): [number, number];
    }
}
export {};
