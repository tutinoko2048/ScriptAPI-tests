import { NativePointer } from "../core";
import { Type } from "../nativetype";
export declare class CommandSymbols {
    private readonly counterSymbols;
    private readonly parserSymbols;
    private readonly parserTypes;
    private readonly counterBases;
    private readonly typeForIds;
    private _getTypeIdSymbols;
    addCounterSymbol(base: Type<any>): void;
    addTypeIdFnSymbols(base: Type<any>, typesWithFunction: Type<any>[]): void;
    addTypeIdPtrSymbols(base: Type<any>, typesWithValuePtr: Type<any>[]): void;
    addParserSymbols(types: Type<any>[]): void;
    iterateTypeIdFns(base: Type<any>): IterableIterator<[Type<any>, NativePointer]>;
    iterateTypeIdPtrs(base: Type<any>): IterableIterator<[Type<any>, NativePointer]>;
    iterateCounters(): IterableIterator<[Type<any>, NativePointer]>;
    iterateParsers(): IterableIterator<[Type<any>, NativePointer]>;
}
