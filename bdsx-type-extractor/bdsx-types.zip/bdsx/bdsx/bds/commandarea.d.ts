import { AbstractClass, NativeClass } from "../nativeclass";
import { NativeType } from "../nativetype";
import { BlockSource } from "./block";
import { BlockPos } from "./blockpos";
import { Dimension } from "./dimension";
export declare class CommandArea extends AbstractClass {
    [NativeType.dtor](): void;
    dispose(): void;
    getDimensionBlockSource(): BlockSource;
    /**@deprecated use getDimensionBlockSource method */
    get blockSource(): BlockSource;
}
export declare class CommandAreaFactory extends NativeClass {
    dimension: Dimension;
    static create(dimension: Dimension): CommandAreaFactory;
    /**
     * @return CommandArea need to be disposed
     */
    findArea(pos1: BlockPos, pos2: BlockPos, b: boolean, b2: boolean, b3: boolean): CommandArea | null;
}
