import { NativeClass, NativeClassType } from "../nativeclass";
import { NativeType } from "../nativetype";
declare class PtrBase<T extends NativeClass> extends NativeClass {
    p: T | null;
    useRef: number;
    weakRef: number;
    [NativeType.ctor](): void;
    addRef(): void;
    addRefWeak(): void;
    release(): void;
    releaseWeak(): void;
    static make<T extends NativeClass>(type: new () => T): NativeClassType<PtrBase<T>>;
}
export declare class SharedPtr<T extends NativeClass> extends NativeClass {
    ref: PtrBase<T> | null;
    [NativeType.dtor](): void;
    value(): T | null;
    addRef(): void;
    dispose(): void;
    static make<T extends NativeClass>(cls: new () => T): NativeClassType<SharedPtr<T>>;
}
export declare class WeakPtr<T extends NativeClass> extends NativeClass {
    ref: PtrBase<T> | null;
    [NativeType.dtor](): void;
    value(): T | null;
    addRef(): void;
    dispose(): void;
    static make<T extends NativeClass>(cls: new () => T): NativeClassType<WeakPtr<T>>;
}
export {};
