import { StaticPointer, VoidPointer } from "../core";
import { CxxVector } from "../cxxvector";
import { AbstractClass } from "../nativeclass";
import { bool_t, int32_t, void_t } from "../nativetype";
import type { Actor, ActorDefinitionIdentifier, ActorUniqueID, ItemActor, Mob } from "./actor";
import { Vec3 } from "./blockpos";
import { JsonValue } from "./connreq";
import type { ItemStack } from "./inventory";
import { CompoundTag } from "./nbt";
/**
 * defines physics properties of an entity, including if it is affected by gravity or if it collides with objects.
 */
export declare class PhysicsComponent extends AbstractClass {
    setHasCollision(actor: Actor, bool: boolean): void;
    setAffectedByGravity(actorData: SyncedActorDataComponent, bool: boolean): void;
}
export declare class SyncedActorDataComponent extends AbstractClass {
}
/**
 * allows the entity to be a thrown entity.
 */
export declare class ProjectileComponent extends AbstractClass {
    static identifier: string;
    shoot(projectile: Actor, shooter: Actor): void;
    setOwnerId(uniqueId: ActorUniqueID): void;
}
export declare class OnHitSubcomponent extends AbstractClass {
    vftable: VoidPointer;
    readfromJSON(json: JsonValue): void_t;
    writetoJSON(json: JsonValue): void_t;
    protected _getName(): StaticPointer;
    getName(): string;
}
export declare class SplashPotionEffectSubcomponent extends OnHitSubcomponent {
    potionEffect: int32_t;
}
export declare class HitResult extends AbstractClass {
    getEntity(): Actor | null;
}
/**
 * defines what events to initiate when the entity is damaged by specific entities or items.
 */
export declare class DamageSensorComponent extends AbstractClass {
    isFatal(): boolean;
    getDamageModifier(): number;
}
/**
 * maybe used for command block minecart.
 */
export declare class CommandBlockComponent extends AbstractClass {
    addAdditionalSaveData(tag: CompoundTag): void;
    getTicking(): boolean;
    setTicking(bool: boolean): void;
    resetCurrentTicking(): void;
}
/**
 * allows the entity to be named (e.g. using a name tag).
 */
export declare class NameableComponent extends AbstractClass {
    nameEntity(actor: Actor, name: string): void;
}
/**
 * minecraft:navigation.climb, minecraft:navigation.float, minecraft:navigation.fly, minecraft:navigation.generic, minecraft:navigation.hover, minecraft:navigation.swim, and minecraft:navigation.walk belong.
 */
export declare class NavigationComponent extends AbstractClass {
    protected _createPath(component: NavigationComponent, actor: Actor, target: Actor | Vec3): Path;
    createPath(actor: Actor, target: Actor): Path;
    createPath(actor: Actor, target: Vec3): Path;
    setPath(path: Path): void;
    stop(mob: Mob): void;
    getMaxDistance(actor: Actor): number;
    getSpeed(): number;
    getAvoidSun(): boolean;
    getCanFloat(): boolean;
    getCanPathOverLava(): boolean;
    getLastStuckCheckPosition(): Vec3;
    isDone(): boolean;
    isStuck(int: number): boolean;
    setAvoidWater(bool: boolean): void;
    setAvoidSun(bool: boolean): void;
    setCanFloat(bool: boolean): void;
    setSpeed(speed: number): void;
}
export declare class Path extends AbstractClass {
}
/**
 * Allows the NPC to use the POI
 */
export declare class NpcComponent extends AbstractClass {
}
/**
 * determines whether the entity can be ridden.
 */
export declare class RideableComponent extends AbstractClass {
    areSeatsFull(ride: Actor): boolean;
    canAddPassenger(ride: Actor, rider: Actor): boolean;
    pullInEntity(ride: Actor, rider: Actor): boolean;
}
/**
 * Defines this entity's inventory properties.
 */
export declare class ContainerComponent extends AbstractClass {
    addItem(item: ItemActor): boolean;
    addItem(item: ItemStack, count?: number, data?: number): boolean;
    protected _addItem(item: ItemStack | ItemActor, count?: number, data?: number): boolean;
    getEmptySlotsCount(): number;
    getSlots(): CxxVector<ItemStack>;
}
/**
 * defines what can push an entity between other entities and pistons.
 */
export declare class PushableComponent extends AbstractClass {
    push(actor: Actor, pos: Vec3): void;
    push(actor: Actor, actor2: Actor, bool: boolean): void;
    protected _push(actor: Actor, arg2: Vec3 | Actor, arg3?: bool_t): void;
}
/**
 * defines the entity's ranged attack behavior.
 */
export declare class ShooterComponent extends AbstractClass {
    shootProjectile(projectile: Actor, defi: ActorDefinitionIdentifier, power: number): void;
}
/**
 * defines the Conditional Spatial Update Bandwidth Optimizations of this entity.
 */
export declare class ConditionalBandwidthOptimizationComponent extends AbstractClass {
}
