import { VoidPointer } from "../core";
import { CxxVector } from "../cxxvector";
import { AbstractClass, NativeClass, NativeStruct } from "../nativeclass";
import { bin64_t, bool_t, CxxString, CxxStringWith8Bytes, int16_t, int32_t, NativeType, uint32_t, uint8_t } from "../nativetype";
import { Actor, ActorRuntimeID } from "./actor";
import { Block, BlockLegacy } from "./block";
import { BlockPos, Vec3 } from "./blockpos";
import { CommandName } from "./commandname";
import type { ItemEnchants } from "./enchants";
import { HashedString } from "./hashedstring";
import type { ItemComponent } from "./item_component";
import type { BlockPalette } from "./level";
import { CompoundTag, NBT } from "./nbt";
import type { ServerPlayer } from "./player";
/**
 * Values from 1 to 100 are for a player's container counter.
 */
export declare enum ContainerId {
    Inventory = 0,
    /** Used as the minimum value of a player's container counter. */
    First = 1,
    /** Used as the maximum value of a player's container counter. */
    Last = 100,
    /** Used in InventoryContentPacket */
    Offhand = 119,
    /** Used in InventoryContentPacket */
    Armor = 120,
    /** Used in InventoryContentPacket */
    Creative = 121,
    /**
     * @deprecated
     */
    Hotbar = 122,
    /**
     * @deprecated
     */
    FixedInventory = 123,
    /** Used in InventoryContentPacket */
    UI = 124,
    None = 255
}
export declare enum ContainerType {
    Container = 0,
    Workbench = 1,
    Furnace = 2,
    Enchantment = 3,
    BrewingStand = 4,
    Anvil = 5,
    Dispenser = 6,
    Dropper = 7,
    Hopper = 8,
    Cauldron = 9,
    MinecartChest = 10,
    MinecartHopper = 11,
    Horse = 12,
    Beacon = 13,
    StructureEditor = 14,
    Trade = 15,
    CommandBlock = 16,
    Jukebox = 17,
    Armor = 18,
    Hand = 19,
    CompoundCreator = 20,
    ElementConstructor = 21,
    MaterialReducer = 22,
    LabTable = 23,
    Loom = 24,
    Lectern = 25,
    Grindstone = 26,
    BlastFurnace = 27,
    Smoker = 28,
    Stonecutter = 29,
    Cartography = 30,
    None = 247,
    Inventory = 255
}
export declare enum ArmorSlot {
    Head = 0,
    /** IDA said this is called Torso */
    Torso = 1,
    Chest = 1,
    Legs = 2,
    Feet = 3
}
export declare enum CreativeItemCategory {
    All = 0,
    Construction = 1,
    Nature = 2,
    Equipment = 3,
    Items = 4,
    Commands = 5,
    /**
     * @deprecated
     * follow official name
     */
    Uncategorized = 6,
    None = 6
}
export declare enum HandSlot {
    Mainhand = 0,
    Offhand = 1
}
export declare class Item extends NativeClass {
    /**
     * Returns whether the item is allowed to be used in the offhand slot
     */
    allowOffhand(): boolean;
    getCommandName(): string;
    /** @deprecated Use `this.getCommandNames2()` instead */
    getCommandNames(): CxxVector<CxxStringWith8Bytes>;
    getCommandNames2(): CxxVector<CommandName>;
    /**
     * Returns the category of the item in creative inventory
     */
    getCreativeCategory(): CreativeItemCategory;
    getArmorValue(): number;
    getToughnessValue(): int32_t;
    isDamageable(): boolean;
    isFood(): boolean;
    isArmor(): boolean;
    isMusicDisk(): boolean;
    /**
     * Changes whether the item is allowed to be used in the offhand slot
     *
     * @remarks Will not affect client but allows /replaceitem
     */
    setAllowOffhand(value: boolean): void;
    getSerializedName(): CxxString;
    getCooldownType(): HashedString;
    canDestroyInCreative(): boolean;
}
/**
 * @deprecated rough. don't use it yet.
 */
export declare class ArmorItem extends Item {
}
export declare class ComponentItem extends Item {
    getComponent(identifier: string): ItemComponent;
    protected _getComponent(identifier: HashedString): ItemComponent;
    buildNetworkTag(): CompoundTag;
    initializeFromNetwork(tag: CompoundTag): void;
}
export declare class ItemStackBase extends NativeClass {
    vftable: VoidPointer;
    item: Item;
    userData: CompoundTag;
    block: Block;
    aux: int16_t;
    amount: uint8_t;
    valid: bool_t;
    pickupTime: bin64_t;
    showPickup: bool_t;
    canPlaceOn: CxxVector<BlockLegacy>;
    canDestroy: CxxVector<BlockLegacy>;
    protected _getItem(): Item;
    protected _setCustomLore(name: CxxVector<string>): void;
    /**
     * just `ItemStackBase::add` in BDS.
     * but it conflicts to {@link VoidPointer.prototype.add}
     */
    addAmount(amount: number): void;
    remove(amount: number): void;
    getArmorValue(): number;
    setAuxValue(value: number): void;
    getAuxValue(): number;
    isValidAuxValue(aux: int32_t): boolean;
    getMaxStackSize(): number;
    toString(): string;
    toDebugString(): string;
    isBlock(): boolean;
    isNull(): boolean;
    setNull(unknown?: string): void;
    getAmount(): number;
    setAmount(amount: number): void;
    getId(): number;
    getItem(): Item | null;
    getName(): string;
    getRawNameId(): string;
    hasCustomName(): boolean;
    getCustomName(): string;
    setCustomName(name: string): void;
    getUserData(): CompoundTag;
    /**
     * Returns the item's enchantability
     *
     * @see https://minecraft.wiki/w/Enchanting_mechanics
     */
    getEnchantValue(): number;
    isEnchanted(): boolean;
    setCustomLore(lores: string[] | string): void;
    getCustomLore(): string[];
    /**
     * @remarks The value is applied only to Damageable items
     */
    setDamageValue(value: number): void;
    setItem(id: number): boolean;
    startCoolDown(player: ServerPlayer): void;
    sameItem(item: ItemStack): boolean;
    sameItemAndAux(item: ItemStack): boolean;
    isStackedByData(): boolean;
    isStackable(): boolean;
    isPotionItem(): boolean;
    isPattern(): boolean;
    isMusicDiscItem(): boolean;
    isLiquidClipItem(): boolean;
    isHorseArmorItem(): boolean;
    isGlint(): boolean;
    isFullStack(): boolean;
    isFireResistant(): boolean;
    isExplodable(): boolean;
    isDamaged(): boolean;
    isDamageableItem(): boolean;
    isArmorItem(): boolean;
    isWearableItem(): boolean;
    getMaxDamage(): number;
    /**
     * Only custom items return ComponentItem
     */
    getComponentItem(): ComponentItem | null;
    getDamageValue(): number;
    getAttackDamage(): number;
    save(): Record<string, any>;
    load(tag: CompoundTag | NBT.Compound): void;
    allocateAndSave(): CompoundTag;
    constructItemEnchantsFromUserData(): ItemEnchants;
    saveEnchantsToUserData(itemEnchants: ItemEnchants): void;
    getCategoryName(): string;
    canDestroySpecial(block: Block): boolean;
    /**
     * Hurts the item's durability.
     * Breaks the item if its durability reaches 0 or less.
     * @param count delta damage
     * @param owner owner of the item, if not null, server will send inventory.
     * @returns returns whether hurt successfully or not
     */
    hurtAndBreak(count: number, owner?: Actor | null): boolean;
}
export declare class ItemStack extends ItemStackBase {
    static readonly EMPTY_ITEM: ItemStack;
    /**
     * @param itemName Formats like 'minecraft:apple' and 'apple' are both accepted, even if the name does not exist, it still returns an ItemStack
     */
    static constructWith(itemName: ItemId, amount?: number, data?: number): ItemStack;
    static constructWith(itemName: string, amount?: number, data?: number): ItemStack;
    /** @deprecated use constructWith */
    static create(itemName: string, amount?: number, data?: number): ItemStack;
    static fromDescriptor(descriptor: NetworkItemStackDescriptor, palette: BlockPalette, unknown: boolean): ItemStack;
    static fromTag(tag: CompoundTag | NBT.Compound): ItemStack;
    clone(): ItemStack;
    /**
     * @deprecated use clone()
     */
    clone(itemStack: ItemStack): void;
    /**
     * @deprecated use clone()
     */
    cloneItem(): ItemStack;
    getDestroySpeed(block: Block): number;
}
export declare class Container extends AbstractClass {
    vftable: VoidPointer;
    addItem(item: ItemStack): void;
    addItemToFirstEmptySlot(item: ItemStack): boolean;
    getSlots(): CxxVector<ItemStack>;
    getItem(slot: number): ItemStack;
    getItemCount(compare: ItemStack): int32_t;
    getContainerType(): ContainerType;
    hasRoomForItem(item: ItemStack): boolean;
    isEmpty(): boolean;
    removeAllItems(): void;
    removeItem(slot: number, count: number): void;
    setCustomName(name: string): void;
}
export declare class FillingContainer extends Container {
    /**
     * It doesn't care item's amount
     */
    canAdd(itemStack: ItemStack): boolean;
}
export declare class SimpleContainer extends Container {
}
export declare class Inventory extends FillingContainer {
    /**
     * Remove the items in the slot
     * @remarks Requires `player.sendInventory()` to update the slot
     * */
    dropSlot(slot: number, onlyClearContainer: boolean, dropAll: boolean, randomly: boolean): void;
}
export declare class EnderChestContainer extends FillingContainer {
}
export declare class PlayerUIContainer extends SimpleContainer {
}
export declare enum PlayerUISlot {
    CursorSelected = 0,
    AnvilInput = 1,
    AnvilMaterial = 2,
    StoneCutterInput = 3,
    Trade2Ingredient1 = 4,
    Trade2Ingredient2 = 5,
    TradeIngredient1 = 6,
    TradeIngredient2 = 7,
    MaterialReducerInput = 8,
    LoomInput = 9,
    LoomDye = 10,
    LoomMaterial = 11,
    CartographyInput = 12,
    CartographyAdditional = 13,
    EnchantingInput = 14,
    EnchantingMaterial = 15,
    GrindstoneInput = 16,
    GrindstoneAdditional = 17,
    CompoundCreatorInput1 = 18,
    CompoundCreatorInput2 = 19,
    CompoundCreatorInput3 = 20,
    CompoundCreatorInput4 = 21,
    CompoundCreatorInput5 = 22,
    CompoundCreatorInput6 = 23,
    CompoundCreatorInput7 = 24,
    CompoundCreatorInput8 = 25,
    CompoundCreatorInput9 = 26,
    BeaconPayment = 27,
    Crafting2x2Input1 = 28,
    Crafting2x2Input2 = 29,
    Crafting2x2Input3 = 30,
    Crafting2x2Input4 = 31,
    Crafting3x3Input1 = 32,
    Crafting3x3Input2 = 33,
    Crafting3x3Input3 = 34,
    Crafting3x3Input4 = 35,
    Crafting3x3Input5 = 36,
    Crafting3x3Input6 = 37,
    Crafting3x3Input7 = 38,
    Crafting3x3Input8 = 39,
    Crafting3x3Input9 = 40,
    MaterialReducerOutput1 = 41,
    MaterialReducerOutput2 = 42,
    MaterialReducerOutput3 = 43,
    MaterialReducerOutput4 = 44,
    MaterialReducerOutput5 = 45,
    MaterialReducerOutput6 = 46,
    MaterialReducerOutput7 = 47,
    MaterialReducerOutput8 = 48,
    MaterialReducerOutput9 = 49,
    CreatedItemOutput = 50,
    SmithingTableInput = 51,
    SmithingTableMaterial = 52
}
export declare class PlayerInventory extends AbstractClass {
    container: Inventory;
    getContainer(): Inventory;
    addItem(itemStack: ItemStack, linkEmptySlot: boolean): boolean;
    clearSlot(slot: number, containerId: ContainerId): void;
    getContainerSize(containerId: ContainerId): number;
    getFirstEmptySlot(): number;
    getHotbarSize(): number;
    getItem(slot: number, containerId: ContainerId): ItemStack;
    getSelectedItem(): ItemStack;
    getSelectedSlot(): number;
    getSlotWithItem(itemStack: ItemStack, checkAux: boolean, checkData: boolean): number;
    /**
     * @deprecated Use container.getSlots();
     */
    getSlots(): CxxVector<ItemStack>;
    selectSlot(slot: number, containerId: ContainerId): void;
    setItem(slot: number, itemStack: ItemStack, containerId: ContainerId, linkEmptySlot: boolean): void;
    setSelectedItem(itemStack: ItemStack): void;
    swapSlots(primarySlot: number, secondarySlot: number): void;
    /**
     * Removes the items from inventory.
     * @param item item for resource to remove
     * @param requireExactAux if true, will only remove the item if it has the exact same aux value
     * @param requireExactData if true, will only remove the item if it has the exact same data value
     * @param maxCount max number of items to remove
     * @returns number of items not removed
     */
    removeResource(item: ItemStack, requireExactAux?: boolean, requireExactData?: boolean, maxCount?: int32_t): int32_t;
    /**
     * It doesn't care item's amount
     */
    canAdd(itemStack: ItemStack): boolean;
}
export declare enum InventorySourceType {
    InvalidInventory = -1,
    ContainerInventory = 0,
    GlobalInventory = 1,
    WorldInteraction = 2,
    CreativeInventory = 3,
    UntrackedInteractionUI = 100,
    NonImplementedFeatureTODO = 99999
}
export declare enum InventorySourceFlags {
    NoFlag = 0,
    WorldInteractionRandom = 1
}
export declare class InventorySource extends NativeStruct {
    type: InventorySourceType;
    containerId: ContainerId;
    flags: InventorySourceFlags;
    static create(containerId: ContainerId, type?: InventorySourceType): InventorySource;
}
export declare class ItemDescriptor extends AbstractClass {
}
export declare class ItemStackNetIdVariant extends AbstractClass {
}
export declare class NetworkItemStackDescriptor extends AbstractClass {
    readonly descriptor: ItemDescriptor;
    readonly id: ItemStackNetIdVariant;
    /** @deprecated There seems to be no string inside NetworkItemStackDescriptor anymore */
    _unknown: CxxString;
    static constructWith(itemStack: ItemStack): NetworkItemStackDescriptor;
    /**
     * Calls move constructor of NetworkItemStackDescriptor for `this`
     */
    [NativeType.ctor_move](temp: NetworkItemStackDescriptor): void;
}
export declare class InventoryAction extends AbstractClass {
    source: InventorySource;
    slot: uint32_t;
    fromDesc: NetworkItemStackDescriptor;
    toDesc: NetworkItemStackDescriptor;
    from: ItemStack;
    to: ItemStack;
}
export declare class InventoryTransactionItemGroup extends AbstractClass {
    itemId: int32_t;
    itemAux: int32_t;
    tag: CompoundTag;
    count: int32_t;
    overflow: bool_t;
    /** When the item is dropped this is air, it should be the item when it is picked up */
    getItemStack(): ItemStack;
}
export declare class InventoryTransaction extends AbstractClass {
    content: CxxVector<InventoryTransactionItemGroup>;
    /** The packet will be cancelled if this is added wrongly */
    addItemToContent(item: ItemStack, count: number): void;
    getActions(source: InventorySource): InventoryAction[];
    protected _getActions(source: InventorySource): CxxVector<InventoryAction>;
}
export declare class ComplexInventoryTransaction extends AbstractClass {
    vftable: VoidPointer;
    type: ComplexInventoryTransaction.Type;
    data: InventoryTransaction;
    isItemUseTransaction(): this is ItemUseInventoryTransaction;
    isItemUseOnEntityTransaction(): this is ItemUseOnActorInventoryTransaction;
    isItemReleaseTransaction(): this is ItemReleaseInventoryTransaction;
}
export declare namespace ComplexInventoryTransaction {
    enum Type {
        NormalTransaction = 0,
        InventoryMismatch = 1,
        ItemUseTransaction = 2,
        ItemUseOnEntityTransaction = 3,
        ItemReleaseTransaction = 4
    }
}
export declare class ItemUseInventoryTransaction extends ComplexInventoryTransaction {
    actionType: ItemUseInventoryTransaction.ActionType;
    readonly pos: BlockPos;
    targetBlockId: uint32_t;
    face: int32_t;
    slot: int32_t;
    readonly descriptor: NetworkItemStackDescriptor;
    readonly fromPos: Vec3;
    /**
     * relative clicked coordinate from the block.
     * range: 0 <= x <= 1
     */
    readonly clickPos: Vec3;
}
export declare namespace ItemUseInventoryTransaction {
    enum ActionType {
        Place = 0,
        Use = 1,
        Destroy = 2
    }
}
export declare class ItemUseOnActorInventoryTransaction extends ComplexInventoryTransaction {
    runtimeId: ActorRuntimeID;
    actionType: ItemUseOnActorInventoryTransaction.ActionType;
    slot: int32_t;
    descriptor: NetworkItemStackDescriptor;
    readonly fromPos: Vec3;
    readonly hitPos: Vec3;
}
export declare namespace ItemUseOnActorInventoryTransaction {
    enum ActionType {
        Interact = 0,
        Attack = 1,
        ItemInteract = 2
    }
}
export declare class ItemReleaseInventoryTransaction extends ComplexInventoryTransaction {
    actionType: ItemReleaseInventoryTransaction.ActionType;
    slot: int32_t;
    descriptor: NetworkItemStackDescriptor;
    readonly fromPos: Vec3;
}
export declare namespace ItemReleaseInventoryTransaction {
    enum ActionType {
        Release = 0,
        Use = 1
    }
}
