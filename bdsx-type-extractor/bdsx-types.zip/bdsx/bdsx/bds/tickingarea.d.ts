import { CxxVector } from "../cxxvector";
import { NativeClass } from "../nativeclass";
import { CxxSharedPtr } from "../sharedpointer";
import { ChunkPos } from "./blockpos";
import { LevelChunk } from "./chunk";
export declare class ITickingAreaView extends NativeClass {
    getAvailableChunk(pos: ChunkPos): CxxSharedPtr<LevelChunk>;
}
export declare class ITickingArea extends NativeClass {
    isRemoved(): boolean;
    getView(): ITickingAreaView;
}
export declare class TickingAreaList extends NativeClass {
    getAreas(): CxxVector<CxxSharedPtr<ITickingArea>>;
}
