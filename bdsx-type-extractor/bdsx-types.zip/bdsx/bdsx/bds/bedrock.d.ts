import { AbstractClass, NativeClass, NativeClassType } from "../nativeclass";
import { Wrapper } from "../pointer";
import { CxxSharedPtr } from "../sharedpointer";
export declare namespace Bedrock {
    type NonOwnerPointerType<T extends NativeClass> = NativeClassType<NonOwnerPointer<T>>;
    class NonOwnerPointer<T extends NativeClass> extends NativeClass {
        /**
         * @deprecated CAUTION, it's not working properly
         */
        sharedptr: CxxSharedPtr<Wrapper<T>>;
        /**
         * @deprecated CAUTION, it's not working properly
         */
        get(): T | null;
        assign(value: NonOwnerPointer<T>): void;
        dispose(): void;
        static make<T extends NativeClass>(v: new () => T): NonOwnerPointerType<T>;
    }
    /**
     * stub implement of Bedrock::Result<void, std::error_code>
     */
    class VoidErrorCodeResult extends AbstractClass {
    }
}
