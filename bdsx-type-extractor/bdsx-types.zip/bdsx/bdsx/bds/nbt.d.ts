/// <reference types="node" />
import * as util from "util";
import { TypedArrayBuffer } from "../common";
import { StaticPointer, VoidPointer } from "../core";
import { CxxMap } from "../cxxmap";
import { CxxVector } from "../cxxvector";
import { AbstractClass, NativeClass } from "../nativeclass";
import { bin64_t, CxxString, float32_t, float64_t, int16_t, int32_t, int64_as_float_t, NativeType, uint8_t, void_t } from "../nativetype";
import { Wrapper } from "../pointer";
interface NBTStringifyable {
    stringify(indent?: number | string): string;
    writeTo(writer: NBTWriter): void;
}
export declare class TagMemoryChunk extends NativeClass {
    /** Total count of elements */
    elements: int64_as_float_t;
    /** Total size in bytes */
    size: int64_as_float_t;
    buffer: StaticPointer | null;
    [NativeType.ctor](): void;
    [NativeType.dtor](): void;
    [NativeType.ctor_copy](v: TagMemoryChunk): void;
    getComponentSize(): number;
    getAs<T extends TypedArrayBuffer>(type: new (count?: number) => T): T;
    set(buffer: TypedArrayBuffer): void;
}
export declare class Tag extends NativeClass implements NBTStringifyable {
    vftable: VoidPointer;
    toString(): string;
    getId(): Tag.Type;
    equals(tag: Tag): boolean;
    value(): any;
    dispose(): void;
    allocateClone(): this;
    stringify(indent?: number | string): string;
    writeTo(writer: NBTWriter): void;
    [util.inspect.custom](depth: number, options: Record<string, any>): unknown;
}
export declare namespace Tag {
    enum Type {
        End = 0,
        Byte = 1,
        Short = 2,
        Int = 3,
        Int64 = 4,
        Float = 5,
        Double = 6,
        ByteArray = 7,
        String = 8,
        List = 9,
        Compound = 10,
        IntArray = 11
    }
}
export declare const TagPointer: import("../pointer").WrapperType<Tag>;
export type TagPointer = Wrapper<Tag>;
export declare class EndTag extends Tag {
    value(): null;
}
export declare class ByteTag extends Tag {
    data: uint8_t;
    value(): NBT.Byte;
    constructWith(data: uint8_t): void_t;
    stringify(indent?: number | string): string;
    writeTo(writer: NBTWriter): void;
    static constructWith(data: uint8_t): ByteTag;
    /**
     * @return should be deleted with tag.delete()
     */
    static allocateWith(data: uint8_t): ByteTag;
}
export declare class ShortTag extends Tag {
    data: int16_t;
    value(): NBT.Short;
    constructWith(data: int16_t): void;
    stringify(indent?: number | string): string;
    writeTo(writer: NBTWriter): void;
    static constructWith(data: int16_t): ShortTag;
    /**
     * @return should be deleted with tag.delete()
     */
    static allocateWith(data: int16_t): ShortTag;
}
export declare class IntTag extends Tag {
    data: int32_t;
    value(): NBT.Int;
    constructWith(data: int32_t): void;
    stringify(indent?: number | string): string;
    writeTo(writer: NBTWriter): void;
    static constructWith(data: int32_t): IntTag;
    /**
     * @return should be deleted with IntTag.delete(x)
     */
    static allocateWith(data: int32_t): IntTag;
}
export declare class Int64Tag extends Tag {
    data: bin64_t;
    get dataAsString(): string;
    set dataAsString(data: string);
    value(): NBT.Int64;
    constructWith(data: bin64_t): void;
    constructWithString(data: string): void;
    stringify(indent?: number | string): string;
    writeTo(writer: NBTWriter): void;
    static constructWith(data: bin64_t): Int64Tag;
    static constructWithString(data: string): Int64Tag;
    static allocateWith(data: bin64_t): Int64Tag;
    static allocateWithString(data: string): Int64Tag;
    [util.inspect.custom](depth: number, options: Record<string, any>): unknown;
}
export declare class FloatTag extends Tag {
    data: float32_t;
    value(): NBT.Float;
    constructWith(data: float32_t): void;
    stringify(indent?: number | string): string;
    writeTo(writer: NBTWriter): void;
    static constructWith(data: float32_t): FloatTag;
    static allocateWith(data: float32_t): FloatTag;
}
export declare class DoubleTag extends Tag {
    data: float64_t;
    value(): NBT.Double;
    constructWith(data: float64_t): void;
    stringify(indent?: number | string): string;
    writeTo(writer: NBTWriter): void;
    static constructWith(data: float64_t): DoubleTag;
    static allocateWith(data: float64_t): DoubleTag;
}
export declare class ByteArrayTag extends Tag {
    data: TagMemoryChunk;
    value(): Uint8Array;
    constructWith(data: Uint8Array): void;
    set(array: TypedArrayBuffer | number[]): void;
    get(idx: number): uint8_t;
    size(): number;
    toUint8Array(): Uint8Array;
    writeTo(writer: NBTWriter): void;
    static constructWith(data: Uint8Array): ByteArrayTag;
    static allocateWith(data: TypedArrayBuffer | number[]): ByteArrayTag;
    [util.inspect.custom](depth: number, options: Record<string, any>): unknown;
}
export declare class StringTag extends Tag {
    data: CxxString;
    value(): string;
    constructWith(data: CxxString): void;
    stringify(indent?: number | string): string;
    writeTo(writer: NBTWriter): void;
    static constructWith(data: string): StringTag;
    static allocateWith(data: string): StringTag;
}
export declare class ListTag<T extends Tag = Tag> extends Tag {
    data: CxxVector<T>;
    type: Tag.Type;
    value(): any[];
    [NativeType.ctor_copy](list: ListTag<T>): void;
    get<_T extends Tag = T>(idx: number): _T;
    set(idx: number, tag: T): void;
    push(tag: Tag): void;
    /**
     * @param tag it should be allocated by `Tag.allocate()`. it will be destructed inside of the function
     */
    pushAllocated(tag: Tag): void;
    /**
     * @return should be deleted by tag.delete()
     */
    pop(): T | null;
    size(): number;
    constructWith(data: T[]): void;
    writeTo(writer: NBTWriter): void;
    static constructWith<T extends Tag = Tag>(data?: T[]): ListTag<T>;
    static allocateWith<T extends Tag = Tag>(data?: T[]): ListTag<T>;
    [util.inspect.custom](depth: number, options: Record<string, any>): unknown;
}
export declare class CompoundTagVariant extends AbstractClass {
    get(): Tag;
    set(tag: Tag): void;
    emplace(tag: Tag): void;
}
export declare class CompoundTag extends Tag {
    data: CxxMap<CxxString, CompoundTagVariant>;
    value(): Record<string, any>;
    size(): number;
    constructWith(data: Record<string, Tag>): void;
    get<T extends Tag>(key: string): T | null;
    /**
     * @param tag it should be allocated by `Tag.allocate()`. it will be destructed inside of the function
     */
    setAllocated(key: string, tag: Tag): void;
    set(key: string, tag: Tag): void;
    has(key: string): boolean;
    delete(key: string): boolean;
    clear(): void;
    writeTo(writer: NBTWriter): void;
    static allocateWith(data: Record<string, Tag>): CompoundTag;
    [NativeType.ctor_copy](from: CompoundTag): void;
    [NativeType.ctor_move](from: CompoundTag): void;
    [util.inspect.custom](depth: number, options: Record<string, any>): unknown;
}
export declare class IntArrayTag extends Tag {
    data: TagMemoryChunk;
    [NativeType.ctor](): void;
    value(): Int32Array;
    constructWith(data: Int32Array): void;
    set(array: Int32Array | number[]): void;
    get(idx: number): int32_t;
    size(): number;
    toInt32Array(): Int32Array;
    writeTo(writer: NBTWriter): void;
    static allocateWith(data: Int32Array | number[]): IntArrayTag;
    [util.inspect.custom](depth: number, options: Record<string, any>): unknown;
    static readonly vftable: import("../core").NativePointer;
}
export type NBT = Int32Array | Uint8Array | NBT.Compound | NBT[] | NBT.Primitive | NBT.Numeric | number | string | Tag | boolean | null;
export declare namespace NBT {
    type Mixed = NBT | Tag | MixedCompound;
    interface MixedCompound {
        [key: string]: Mixed;
    }
    interface Compound {
        [key: string]: NBT;
    }
    abstract class Primitive implements NBTStringifyable {
        abstract allocate(): Tag;
        stringify(indent?: number | string): string;
        writeTo(writer: NBTWriter): void;
    }
    abstract class Numeric extends Primitive {
        protected _value: number;
        constructor(_value: number);
        abstract get value(): number;
        abstract set value(n: number);
        toExponential(fractionDigits?: number | undefined): string;
        toFixed(fractionDigits?: number | undefined): string;
        toLocaleString(locales?: string | string[] | undefined, options?: Intl.NumberFormatOptions | undefined): string;
        toPrecision(precision?: number): string;
        toString(radix?: number): string;
        valueOf(): number;
    }
    class Byte extends Numeric {
        constructor(n: number);
        get value(): number;
        set value(n: number);
        allocate(): ByteTag;
        stringify(indent?: number | string): string;
        writeTo(writer: NBTWriter): void;
        [util.inspect.custom](depth: number, options: Record<string, any>): string;
    }
    class Short extends Numeric {
        constructor(n: number);
        get value(): number;
        set value(n: number);
        allocate(): ShortTag;
        stringify(indent?: number | string): string;
        writeTo(writer: NBTWriter): void;
        [util.inspect.custom](depth: number, options: Record<string, any>): string;
    }
    class Int extends Numeric {
        constructor(n: number);
        get value(): number;
        set value(n: number);
        allocate(): IntTag;
        stringify(indent?: number | string): string;
        writeTo(writer: NBTWriter): void;
        [util.inspect.custom](depth: number, options: Record<string, any>): string;
    }
    class Int64 extends Primitive {
        private _value;
        constructor(n: bin64_t);
        get value(): bin64_t;
        set value(n: bin64_t);
        allocate(): Int64Tag;
        stringify(indent?: number | string): string;
        writeTo(writer: NBTWriter): void;
        [util.inspect.custom](depth: number, options: Record<string, any>): string;
    }
    class Float extends Numeric {
        constructor(n: number);
        get value(): number;
        set value(n: number);
        allocate(): FloatTag;
        stringify(indent?: number | string): string;
        writeTo(writer: NBTWriter): void;
        [util.inspect.custom](depth: number, options: Record<string, any>): string;
    }
    class Double extends Numeric {
        set value(n: number);
        get value(): number;
        allocate(): DoubleTag;
        writeTo(writer: NBTWriter): void;
        [util.inspect.custom](depth: number, options: Record<string, any>): string;
    }
    function byte(n: number): Byte;
    function short(n: number): Short;
    function int(n: number): Int;
    function int64(n: bin64_t | number): Int64;
    function float(n: number): Float;
    function double(n: number): Double;
    function byteArray(values: number[]): Uint8Array;
    function intArray(values: number[]): Int32Array;
    function end(): null;
    function isCompound(nbt: NBT): nbt is Compound;
    /**
     * it will allocate the native NBT from the JS NBT.
     * boolean -> ByteTag
     * number -> IntTag
     * null -> end
     */
    function allocate(nbt: Mixed): Tag;
    /** Converts a Stringified Named Binary Tag (SNBT) string into a Named Binary Tag (NBT) tag. */
    function parse(text: string): NBT;
    /** Converts a Named Binary Tag (NBT) tag to a Stringified Named Binary Tag (SNBT) string. */
    function stringify(tag: Tag | NBT, indent?: number): string;
}
declare class NBTWriter {
    data: string;
    byteArray(array: Uint8Array): void;
    intArray(array: Int32Array): void;
    list(array: Iterable<NBT | Tag>): void;
    compound(map: Iterable<[string, NBT | Tag | CompoundTagVariant]>): void;
    any(nbt: NBT | Tag | CompoundTagVariant): void;
}
export {};
