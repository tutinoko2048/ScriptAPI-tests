import { AbstractClass } from "../nativeclass";
import { NetworkSystem } from "./networkidentifier";
export declare class LoopbackPacketSender extends AbstractClass {
    networkSystem: NetworkSystem;
}
