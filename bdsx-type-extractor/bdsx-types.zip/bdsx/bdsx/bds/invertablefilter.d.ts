import { VoidPointer } from "../core";
import { NativeClass, NativeClassType } from "../nativeclass";
import { Type } from "../nativetype";
export interface InvertableFilterType<T> extends NativeClassType<InvertableFilter<T>> {
    new (address?: VoidPointer | boolean): InvertableFilter<T>;
    readonly type: Type<any>;
}
export declare abstract class InvertableFilter<T> extends NativeClass {
    value: T;
    inverted: boolean;
    readonly type: Type<any>;
    static readonly type: Type<any>;
    abstract setValue(value: T): void;
    static make<T>(type: Type<T>): InvertableFilterType<T>;
}
