import type { CommandResult, CommandResultType } from "../commandresult";
import { StaticPointer, VoidPointer } from "../core";
import { CxxVector } from "../cxxvector";
import { AbstractClass, NativeClass, NativeStruct, nativeClassUtil } from "../nativeclass";
import { CxxString, bin64_t, bool_t, float32_t, int32_t, int64_as_float_t } from "../nativetype";
import { AttributeId, AttributeInstance, BaseAttributeMap } from "./attribute";
import { Block, BlockSource } from "./block";
import { BlockPos, Vec2, Vec3 } from "./blockpos";
import type { CommandPermissionLevel } from "./command";
import type { CommandBlockComponent, ConditionalBandwidthOptimizationComponent, ContainerComponent, DamageSensorComponent, NameableComponent, NavigationComponent, NpcComponent, PhysicsComponent, ProjectileComponent, PushableComponent, RideableComponent, ShooterComponent } from "./components";
import { CxxOptional } from "./cxxoptional";
import type { Dimension } from "./dimension";
import { MobEffect, MobEffectIds, MobEffectInstance } from "./effects";
import { HashedString } from "./hashedstring";
import type { ArmorSlot, ItemStack, SimpleContainer } from "./inventory";
import type { Level } from "./level";
import { CompoundTag, NBT } from "./nbt";
import type { NetworkIdentifier } from "./networkidentifier";
import { Packet } from "./packet";
import type { Player, ServerPlayer, SimulatedPlayer } from "./player";
export declare const ActorUniqueID: import("../nativetype").NativeType<string> & {
    INVALID_ID: string;
};
export type ActorUniqueID = bin64_t;
export declare enum DimensionId {
    Overworld = 0,
    Nether = 1,
    TheEnd = 2,
    Undefined = 3
}
export declare class ActorRuntimeID extends VoidPointer {
}
export declare enum ActorType {
    Item = 64,
    PrimedTnt = 65,
    FallingBlock = 66,
    MovingBlock = 67,
    Experience = 69,
    EyeOfEnder = 70,
    EnderCrystal = 71,
    FireworksRocket = 72,
    FishingHook = 77,
    Chalkboard = 78,
    Painting = 83,
    LeashKnot = 88,
    BoatRideable = 90,
    LightningBolt = 93,
    AreaEffectCloud = 94,
    Balloon = 107,
    Shield = 117,
    Lectern = 119,
    TypeMask = 255,
    Mob = 256,
    Npc = 307,
    Agent = 312,
    ArmorStand = 317,
    TripodCamera = 318,
    Player = 319,
    Bee = 378,
    Piglin = 379,
    PiglinBrute = 383,
    Allay = 390,
    PathfinderMob = 768,
    IronGolem = 788,
    SnowGolem = 789,
    WanderingTrader = 886,
    Monster = 2816,
    Creeper = 2849,
    Slime = 2853,
    EnderMan = 2854,
    Ghast = 2857,
    LavaSlime = 2858,
    Blaze = 2859,
    Witch = 2861,
    Guardian = 2865,
    ElderGuardian = 2866,
    Dragon = 2869,
    Shulker = 2870,
    Vindicator = 2873,
    IllagerBeast = 2875,
    EvocationIllager = 2920,
    Vex = 2921,
    Pillager = 2930,
    ElderGuardianGhost = 2936,
    Warden = 2947,
    Animal = 4864,
    Chicken = 4874,
    Cow = 4875,
    Pig = 4876,
    Sheep = 4877,
    MushroomCow = 4880,
    Rabbit = 4882,
    PolarBear = 4892,
    Llama = 4893,
    Turtle = 4938,
    Panda = 4977,
    Fox = 4985,
    Hoglin = 4988,
    Strider = 4989,
    Goat = 4992,
    Axolotl = 4994,
    Frog = 4996,
    Sniffer = 5003,
    WaterAnimal = 8960,
    Squid = 8977,
    Dolphin = 8991,
    Pufferfish = 9068,
    Salmon = 9069,
    Tropicalfish = 9071,
    Fish = 9072,
    GlowSquid = 9089,
    Tadpole = 9093,
    TameableAnimal = 21248,
    Wolf = 21262,
    Ocelot = 21270,
    Parrot = 21278,
    Cat = 21323,
    Ambient = 33024,
    Bat = 33043,
    UndeadMob = 68352,
    PigZombie = 68388,
    WitherBoss = 68404,
    Phantom = 68410,
    Zoglin = 68478,
    ZombieMonster = 199424,
    Zombie = 199456,
    ZombieVillager = 199468,
    Husk = 199471,
    Drowned = 199534,
    ZombieVillagerV2 = 199540,
    Arthropod = 264960,
    Spider = 264995,
    Silverfish = 264999,
    CaveSpider = 265000,
    Endermite = 265015,
    Minecart = 524288,
    MinecartRideable = 524372,
    MinecartHopper = 524384,
    MinecartTNT = 524385,
    MinecartChest = 524386,
    MinecartFurnace = 524387,
    MinecartCommandBlock = 524388,
    SkeletonMonster = 1116928,
    Skeleton = 1116962,
    Stray = 1116974,
    WitherSkeleton = 1116976,
    EquineAnimal = 2118400,
    Horse = 2118423,
    Donkey = 2118424,
    Mule = 2118425,
    SkeletonHorse = 2186010,
    ZombieHorse = 2186011,
    Projectile = 4194304,
    ExperiencePotion = 4194372,
    ShulkerBullet = 4194380,
    DragonFireball = 4194383,
    Snowball = 4194385,
    ThrownEgg = 4194386,
    LargeFireball = 4194389,
    ThrownPotion = 4194390,
    Enderpearl = 4194391,
    WitherSkull = 4194393,
    WitherSkullDangerous = 4194395,
    SmallFireball = 4194398,
    LingeringPotion = 4194405,
    LlamaSpit = 4194406,
    EvocationFang = 4194407,
    IceBomb = 4194410,
    AbstractArrow = 8388608,
    Trident = 12582985,
    Arrow = 12582992,
    VillagerBase = 16777984,
    Villager = 16777999,
    VillagerV2 = 16778099
}
export declare class ActorDefinitionIdentifier extends NativeClass {
    namespace: CxxString;
    identifier: CxxString;
    initEvent: CxxString;
    fullName: CxxString;
    readonly canonicalName: HashedString;
    static constructWith(fullName: EntityId): ActorDefinitionIdentifier;
    static constructWith(fullName: string): ActorDefinitionIdentifier;
    static constructWith(type: ActorType): ActorDefinitionIdentifier;
    /** @deprecated use {@link constructWith()} instead*/
    static create(type: string | ActorType): ActorDefinitionIdentifier;
}
export declare class ActorDamageSource extends NativeClass {
    vftable: VoidPointer;
    cause: int32_t;
    /** @deprecated Use {@link create} instead. */
    static constructWith(cause: ActorDamageCause): ActorDamageSource;
    static create(cause: ActorDamageCause): ActorDamageSource;
    /**
     *
     * @param cause damage cause
     */
    setCause(cause: ActorDamageCause): void;
    getDamagingEntity(): Actor | null;
    getDamagingEntityUniqueID(): ActorUniqueID;
    isEntitySource(): this is ActorDamageByActorSource;
    isChildEntitySource(): this is ActorDamageByChildActorSource;
    isBlockSource(): this is ActorDamageByBlockSource;
}
export declare class ActorDamageByBlockSource extends ActorDamageSource {
    /**
     * At least Magma, Stalactite, and Stalagmite are verified that used in BDS
     */
    static create(block: Block, cause: ActorDamageCause): ActorDamageByBlockSource;
    static create(this: never, cause: ActorDamageCause): ActorDamageSource;
    block: Block;
}
export declare class ActorDamageByActorSource extends ActorDamageSource {
    static constructWith(damagingEntity: Actor, cause?: ActorDamageCause): ActorDamageByActorSource;
    static constructWith(this: never, cause: ActorDamageCause): ActorDamageSource;
}
export declare class ActorDamageByChildActorSource extends ActorDamageByActorSource {
    static constructWith(childEntity: Actor, damagingEntity: Actor, cause?: ActorDamageCause): ActorDamageByChildActorSource;
    static constructWith(this: never, cause: ActorDamageCause): ActorDamageSource;
    static constructWith(this: never, damagingEntity: Actor, cause?: ActorDamageCause): ActorDamageByActorSource;
    getChildEntityUniqueId(): ActorUniqueID;
}
export declare enum ActorDamageCause {
    /** The kill command */
    Override = 0,
    /** @deprecated */
    None = 0,
    Contact = 1,
    EntityAttack = 2,
    Projectile = 3,
    Suffocation = 4,
    /** @deprecated Typo */
    Suffoocation = 4,
    Fall = 5,
    Fire = 6,
    FireTick = 7,
    Lava = 8,
    Drowning = 9,
    BlockExplosion = 10,
    EntityExplosion = 11,
    Void = 12,
    Suicide = 13,
    Magic = 14,
    Wither = 15,
    Starve = 16,
    Anvil = 17,
    Thorns = 18,
    FallingBlock = 19,
    Piston = 20,
    FlyIntoWall = 21,
    Magma = 22,
    Fireworks = 23,
    Lightning = 24,
    Charging = 25,
    Temperature = 26,
    Freeze = 27,
    Stalactite = 28,
    Stalagmite = 29,
    RamAttack = 30,
    SonicBoom = 31,
    All = 34
}
export declare enum ActorFlags {
    OnFire = 0,
    Sneaking = 1,
    Riding = 2,
    Sprinting = 3,
    UsingItem = 4,
    Invisible = 5,
    Tempted = 6,
    InLove = 7,
    Saddled = 8,
    Powered = 9,
    /**
     * @deprecated typo.
     */
    Ignit0ed = 10,
    Ignited = 10,
    Baby = 11,
    Converting = 12,
    Critical = 13,
    CanShowName = 14,
    AlwaysShowName = 15,
    NoAI = 16,
    Silent = 17,
    WallClimbing = 18,
    CanClimb = 19,
    CanSwim = 20,
    CanFly = 21,
    CanWalk = 22,
    Resting = 23,
    Sitting = 24,
    Angry = 25,
    Interested = 26,
    Charged = 27,
    Tamed = 28,
    Orphaned = 29,
    Leashed = 30,
    Sheared = 31,
    Gliding = 32,
    Elder = 33,
    Moving = 34,
    Breathing = 35,
    Chested = 36,
    Stackable = 37,
    ShowBottom = 38,
    Standing = 39,
    Shaking = 40,
    Idling = 41,
    Casting = 42,
    Charging = 43,
    WasdControlled = 44,
    CanPowerJump = 45,
    Lingering = 46,
    HasCollision = 47,
    HasGravity = 48,
    FireImmune = 49,
    Dancing = 50,
    Enchanted = 51,
    ReturnTrident = 52,
    ContainerIsPrivate = 53,
    IsTransforming = 54,
    DamageNearbyMobs = 55,
    Swimming = 56,
    Bribed = 57,
    IsPregnant = 58,
    LayingEgg = 59,
    RiderCanPick = 60,
    TransitionSitting = 61,
    Eating = 62,
    LayingDown = 63,
    /**
     * @deprecated Typo!
     */
    Snezing = 64,
    Sneezing = 64,
    Trusting = 65,
    Rolling = 66,
    Scared = 67,
    InScaffolding = 68,
    OverScaffolding = 69,
    FallThroughScaffolding = 70,
    Blocking = 71,
    TransitionBlocking = 72,
    BlockedUsingShield = 73,
    BlockedUsingDamagedShield = 74,
    Sleeping = 75,
    WantsToWake = 76,
    TradeInterest = 77,
    DoorBreaker = 78,
    BreakingObstruction = 79,
    DoorOpener = 80,
    IsIllagerCaptain = 81,
    Stunned = 82,
    Roaring = 83,
    DelayedAttack = 84,
    IsAvoidingMobs = 85,
    FacingTargetToRangeAttack = 86,
    HiddenWhenInvisible = 87,
    IsInUI = 88,
    Stalking = 89,
    Emoting = 90,
    Celebrating = 91,
    Admiring = 92,
    CelebratingSpecial = 93,
    OutOfControl = 94,
    RamAttack = 95,
    PlayingDead = 96,
    InAscendableBlock = 97,
    OverDescendableBlock = 98
}
export declare enum ActorLinkType {
    None = 0,
    Riding = 1,
    Passenger = 2
}
export declare class ActorLink extends NativeStruct {
    type: ActorLinkType;
    A: ActorUniqueID;
    B: ActorUniqueID;
    immediate: bool_t;
    causedByRider: bool_t;
}
export declare class OwnerStorageEntity extends AbstractClass {
    _getStackRef(): EntityContext;
}
export declare class EntityRefTraits extends AbstractClass {
    context: OwnerStorageEntity;
}
export declare class WeakEntityRef extends AbstractClass {
    tryUnwrap<T extends typeof Actor>(clazz: T, getRemoved?: boolean): InstanceType<T> | null;
    tryUnwrapPlayer(getRemoved?: boolean): Player | null;
    tryUnwrapActor(getRemoved?: boolean): Actor | null;
}
export declare class EntityContext extends AbstractClass {
    enttRegistry: VoidPointer;
    entityId: int32_t;
    isValid(): boolean;
    /** @deprecated use {@link isValid()} instead */
    isVaild(): boolean;
    _enttRegistry(): VoidPointer;
    /**
     * Returns copied EntityId
     */
    _getEntityId(): VoidPointer /** WrappedEntityId */;
}
/** @deprecated merged into EntityContext */
export declare const EntityContextBase: typeof EntityContext;
/** @deprecated merged into EntityContext */
export type EntityContextBase = EntityContext;
export declare class Actor extends AbstractClass {
    vftable: VoidPointer;
    ctxbase: EntityContext;
    /** @deprecated use {@link getIdentifier()} instead */
    get identifier(): EntityId;
    /**
     * Summon a new entity
     * @example Actor.summonAt(player.getRegion(), player.getPosition(), ActorType.Pig)
     * @example Actor.summonAt(player.getRegion(), player.getPosition(), ActorType.Pig, player)
     * @example Actor.summonAt(player.getRegion(), player.getPosition(), ActorType.Pig, -1, player)
     * */
    static summonAt(region: BlockSource, pos: Vec3, type: ActorDefinitionIdentifier | ActorType, summoner?: Actor): Actor;
    static summonAt(region: BlockSource, pos: Vec3, type: ActorDefinitionIdentifier | ActorType, id?: ActorUniqueID, summoner?: Actor): Actor;
    static summonAt(region: BlockSource, pos: Vec3, type: ActorDefinitionIdentifier | ActorType, id?: int64_as_float_t, summoner?: Actor): Actor;
    /**
     * Get the Actor instance of an entity with its EntityContext
     */
    static tryGetFromEntity(entity: EntityContext, getRemoved?: boolean): Actor | null;
    /**
     * Teleports the actor to another dimension
     * @deprecated respawn parameter deleted
     *
     * @param dimensionId - The dimension ID
     * @param respawn - Indicates whether the dimension change is based on a respawn (player died in dimension)
     *
     * @see DimensionId
     */
    changeDimension(dimensionId: DimensionId, respawn: boolean): void;
    /**
     * Teleports the actor to another dimension
     *
     * @param dimensionId - The dimension ID
     *
     * @see DimensionId
     */
    changeDimension(dimensionId: DimensionId): void;
    /**
     * Teleports the player to a specified position
     * @deprecated sourceActorId deleted
     *
     * @remarks This function is used when entities teleport players (e.g: ender pearls). Use Actor.teleport() if you want to teleport the player.
     *
     * @param position - Position to teleport the player to
     * @param shouldStopRiding - Defines whether the player should stop riding an entity when teleported
     * @param cause - Cause of teleportation
     * @param sourceEntityType - Entity type that caused the teleportation
     * @param sourceActorId - ActorUniqueID of the source entity
     *
     * @privateRemarks causes of teleportation are currently unknown.
     */
    teleportTo(position: Vec3, shouldStopRiding: boolean, cause: number, sourceEntityType: number, sourceActorId: ActorUniqueID): void;
    /**
     * Teleports the player to a specified position
     * @remarks This function is used when entities teleport players (e.g: ender pearls). Use Actor.teleport() if you want to teleport the player.
     *
     * @param position - Position to teleport the player to
     * @param shouldStopRiding - Defines whether the player should stop riding an entity when teleported
     * @param cause - Cause of teleportation
     * @param sourceEntityType - Entity type that caused the teleportation
     * @param unknown
     *
     * @privateRemarks causes of teleportation are currently unknown.
     */
    teleportTo(position: Vec3, shouldStopRiding: boolean, cause: number, sourceEntityType: number, unknown?: boolean): void;
    /**
     * Adds an item to the entity's inventory
     * @remarks Entity(Mob) inventory will not be updated. Use Mob.sendInventory() to update it.
     *
     * @param itemStack - Item to add
     * @returns {boolean} Whether the item has been added successfully (Full inventory can be a cause of failure)
     */
    addItem(itemStack: ItemStack): boolean;
    sendPacket(packet: Packet): void;
    /**
     * Actually it's Mob::getArmorValue in BDS.
     * @returns the entity's armor value (as an integer)
     */
    getArmorValue(): number;
    /**
     * Returns the Dimension instance of the entity currently in
     */
    getDimension(): Dimension;
    /**
     * Returns the dimension id of the entity currently in
     */
    getDimensionId(): DimensionId;
    /**
     * Returns the entity's identifier
     */
    getIdentifier(): EntityId;
    /**
     * Returns the ActorDefinitionIdentifier instance of the entity
     */
    getActorIdentifier(): ActorDefinitionIdentifier;
    /**
     * Returns the item currently in the entity's mainhand slot
     */
    getCarriedItem(): ItemStack;
    /**
     * @alias of getCarriedItem
     */
    getMainhandSlot(): ItemStack;
    /**
     * Sets the item currently in the entity's mainhand slot
     */
    setCarriedItem(item: ItemStack): void;
    /**
     * @alias of setCarriedItem
     */
    setMainhandSlot(item: ItemStack): void;
    /**
     * Returns the item currently in the entity's offhand slot
     */
    getOffhandSlot(): ItemStack;
    /**
     * Sets the item currently in the entity's offhand slot
     */
    setOffhandSlot(item: ItemStack): void;
    /**
     * @alias instanceof Mob
     */
    isMob(): this is Mob;
    /**
     * @alias instanceof ServerPlayer
     */
    isPlayer(): this is ServerPlayer;
    /**
     * @deprecated use Player.prototype.isSimulated instead. A SimulatedPlayer is a ServerPlayer anyway.
     */
    isPlayer(includeSimulatedPlayer: boolean): this is SimulatedPlayer;
    /**
     * @alias instanceof SimulatedPlayer
     */
    isSimulatedPlayer(): this is SimulatedPlayer;
    /**
     * @alias instanceof ItemActor
     */
    isItem(): this is ItemActor;
    isSneaking(): boolean;
    hasType(type: ActorType): boolean;
    isType(type: ActorType): boolean;
    /**
     * Kills the entity (itself)
     */
    kill(): void;
    /**
     * Makes the entity dead
     * @param damageSource ex) ActorDamageSource.create(ActorDamageCause.Lava)
     */
    die(damageSource: ActorDamageSource): void;
    /**
     * Returns the entity's attribute map
     */
    getAttributes(): BaseAttributeMap;
    /**
     * Returns the entity's name
     * @deprecated use getNameTag() instead
     */
    getName(): string;
    /**
     * Returns the entity's name
     */
    getNameTag(): string;
    setHurtTime(time: number): void;
    /**
     * Changes the entity's name
     *
     * Calls Player::setName if it's Player.
     * or it calls Actor::setNameTag.
     */
    setName(name: string): void;
    /**
     * Changes the entity's nametag
     */
    setNameTag(name: string): void;
    /**
     * Set if the entity's nametag is visible
     */
    setNameTagVisible(visible: boolean): void;
    /**
     * Set a text under the entity's name (original is name of objective for scoreboard)
     */
    setScoreTag(text: string): void;
    /**
     * Returns a text under the entity's name (original is name of objective for scoreboard)
     */
    getScoreTag(): string;
    /**
     * Despawn the entity. Don't use for this Player.
     */
    despawn(): void;
    getNetworkIdentifier(): NetworkIdentifier;
    /**
     * Returns the entity's position
     */
    getPosition(): Vec3;
    /**
     * Returns the entity's feet position
     */
    getFeetPos(): Vec3;
    /**
     * Returns the entity's rotation
     */
    getRotation(): Vec2;
    /**
     * Returns the BlockSource instance which the entity is ticking
     * @alias getDimensionBlockSource
     */
    getRegion(): BlockSource;
    /**
     * Returns the BlockSource instance which the entity is ticking
     */
    getDimensionBlockSource(): BlockSource;
    getUniqueIdLow(): number;
    getUniqueIdHigh(): number;
    getUniqueIdBin(): bin64_t;
    /**
     * Returns address of the entity's unique id
     */
    getUniqueIdPointer(): StaticPointer;
    /**
     * Returns the entity's type
     */
    getEntityTypeId(): ActorType;
    /**
     * Returns the entity's command permission level
     */
    getCommandPermissionLevel(): CommandPermissionLevel;
    /**
     * Returns the entity's specific attribute
     */
    getAttribute(id: AttributeId): number;
    /**
     * Changes the entity's specific attribute
     */
    setAttribute(id: AttributeId, value: number): AttributeInstance | null;
    /**
     * Returns the entity's runtime id
     */
    getRuntimeID(): ActorRuntimeID;
    /**
     * Gets the entity component of bedrock scripting api
     *
     * @deprecated bedrock scripting API is removed.
     */
    getEntity(): any;
    /**
     * Adds an effect to the entity. If a weaker effect of the same type is already applied, it will be replaced. If a weaker or equal-strength effect is already applied but has a shorter duration, it will be replaced.
     */
    addEffect(effect: MobEffectInstance): void;
    /**
     * Removes the effect with the specified ID from the entity
     */
    removeEffect(id: MobEffectIds): void;
    protected _hasEffect(mobEffect: MobEffect): boolean;
    /**
     * Returns whether the specified effect is active on the entity
     */
    hasEffect(id: MobEffectIds): boolean;
    protected _getEffect(mobEffect: MobEffect): MobEffectInstance | null;
    /**
     * Returns the effect instance active on this entity with the specified ID, or null if the entity does not have the effect.
     */
    getEffect(id: MobEffectIds): MobEffectInstance | null;
    removeAllEffects(): void;
    /**
     * Adds a tag to the entity.
     * Related functions: {@link getTags}, {@link removeTag}, {@link hasTag}
     * @returns {boolean} Whether the tag has been added successfully
     */
    addTag(tag: string): boolean;
    /**
     * Returns whether the entity has the tag.
     * Related functions: {@link getTags}, {@link addTag}, {@link removeTag}
     */
    hasTag(tag: string): boolean;
    /**
     * Removes a tag from the entity.
     * Related functions: {@link getTags}, {@link addTag}, {@link hasTag}
     * @returns {boolean} Whether the tag has been removed successfully
     */
    removeTag(tag: string): boolean;
    /**
     * Returns tags the entity has.
     * Related functions: {@link addTag}, {@link removeTag}, {@link hasTag}
     */
    getTags(): string[];
    /**
     * Teleports the entity to a specified position
     */
    teleport(pos: Vec3, dimensionId?: DimensionId, facePosition?: Vec3 | null): void;
    /**
     * Returns the entity's armor
     */
    getArmor(slot: ArmorSlot): ItemStack;
    /**
     * Sets the entity's sneaking status
     */
    setSneaking(value: boolean): void;
    /**
     * Returns the entity's health
     */
    getHealth(): number;
    /**
     * Returns the entity's maximum health
     */
    getMaxHealth(): number;
    /**
     * @param tag this function stores nbt values to this parameter
     */
    save(tag: CompoundTag): boolean;
    /**
     * it returns JS converted NBT
     */
    save(): Record<string, any>;
    readAdditionalSaveData(tag: CompoundTag | NBT.Compound): void;
    load(tag: CompoundTag | NBT.Compound): void;
    allocateAndSave(): CompoundTag;
    protected hurt_(source: ActorDamageSource, damage: number, knock: boolean, ignite: boolean): boolean;
    hurt(source: ActorDamageSource, damage: number, knock: boolean, ignite: boolean): boolean;
    hurt(cause: ActorDamageCause, damage: number, knock: boolean, ignite: boolean): boolean;
    /**
     * Changes a specific status flag of the entity
     * @remarks Most of the time it will be reset by ticking
     *
     */
    setStatusFlag(flag: ActorFlags, value: boolean): void;
    /**
     * Returns a specific status flag of the entity
     */
    getStatusFlag(flag: ActorFlags): boolean;
    /**
     * Returns the Level instance of the entity currently in
     */
    getLevel(): Level;
    /**
     * Returns if the entity is alive
     */
    isAlive(): boolean;
    /**
     * Returns if the entity is invisible
     */
    isInvisible(): boolean;
    /**
     * Makes `this` rides on the ride
     * @param ride ride, vehicle
     * @returns Returns whether riding was successful
     */
    startRiding(ride: Actor): boolean;
    protected _isRiding(): boolean;
    protected _isRidingOn(entity: Actor): boolean;
    /**
     * Returns if the entity is riding (on an entity)
     */
    isRiding(): boolean;
    isRiding(entity: Actor): boolean;
    protected _isPassenger(ride: Actor): boolean;
    isPassenger(ride: ActorUniqueID): boolean;
    isPassenger(ride: Actor): boolean;
    /**
     * The result is smooth movement only with `server-authoritative-movement=server-auth-with-rewind` & `correct-player-movement=true` in `server.properties`.
     *
     * If the entity is a Player, it works with only `server-authoritative-movement=server-auth-with-rewind` & `correct-player-movement=true` in `server.properties`.
     */
    setVelocity(dest: Vec3): void;
    isInWater(): boolean;
    getArmorContainer(): SimpleContainer;
    getHandContainer(): SimpleContainer;
    setOnFire(seconds: number): void;
    setOnFireNoEffects(seconds: number): void;
    static fromUniqueIdBin(bin: bin64_t, getRemovedActor?: boolean): Actor | null;
    static fromUniqueId(lowbits: number, highbits: number, getRemovedActor?: boolean): Actor | null;
    /**
     * Gets the entity from entity component of bedrock scripting api
     * @deprecated bedrock scripting API is removed.
     */
    static fromEntity(entity: unknown, getRemovedActor?: boolean): Actor | null;
    static all(): IterableIterator<Actor>;
    [nativeClassUtil.inspectFields](obj: Record<string, any>): void;
    runCommand(command: string, mute?: CommandResultType, permissionLevel?: CommandPermissionLevel): CommandResult<CommandResult.Any>;
    isMoving(): boolean;
    getEquippedTotem(): ItemStack;
    consumeTotem(): boolean;
    hasTotemEquipped(): boolean;
    protected hasFamily_(familyType: HashedString): boolean;
    /**
     * Returns whether the entity has the family type.
     * Ref: https://minecraft.wiki/w/Family
     */
    hasFamily(familyType: HashedString | string): boolean;
    /**
     * Returns the distance from the entity(returns of {@link getPosition}) to {@link dest}
     */
    distanceTo(dest: Vec3): number;
    /**
     * Returns the mob that hurt the entity(`this`)
     */
    getLastHurtByMob(): Mob | null;
    /**
     * Returns the last actor damage cause for the entity.
     */
    getLastHurtCause(): ActorDamageCause;
    /**
     * Returns the last damage amount for the entity.
     */
    getLastHurtDamage(): number;
    /**
     * Returns a mob that was hurt by the entity(`this`)
     */
    getLastHurtMob(): Mob | null;
    /**
     * Returns whether the entity was last hit by a player.
     */
    wasLastHitByPlayer(): boolean;
    /**
     * Returns the speed of the entity
     * If the entity is a Player and server-authoritative-movement(in `server.properties`) is `client-auth`, the result is always 0m/s.
     */
    getSpeedInMetersPerSecond(): number;
    protected fetchNearbyActorsSorted_(maxDistance: Vec3, filter: ActorType): CxxVector<DistanceSortedActor>;
    /**
     * Fetches other entities nearby from the entity.
     */
    fetchNearbyActorsSorted(maxDistance: Vec3, filter: ActorType): DistanceSortedActor[];
    /**
     * Returns whether the player is in creative mode
     */
    isCreative(): boolean;
    /**
     * Returns whether the player is in adventure mode
     */
    isAdventure(): boolean;
    /**
     * Returns whether the player is in survival mode
     */
    isSurvival(): boolean;
    /**
     * Returns whether the player is in spectator mode
     */
    isSpectator(): boolean;
    /**
     * Removes the entity
     */
    remove(): void;
    /**
     * Returns whether the actor is angry
     */
    isAngry(): boolean;
    /**
     * Find actor's attack target
     * @deprecated code not found
     */
    findAttackTarget(): Actor | null;
    /**
     * Get actor targeting block
     */
    getBlockTarget(): BlockPos;
    isAttackableGamemode(): boolean;
    isInvulnerableTo(damageSource: ActorDamageSource): boolean;
    canSee(target: Actor): boolean;
    canSee(target: Vec3): boolean;
    isValidTarget(source?: Actor | null): boolean;
    canAttack(target: Actor | null, unknown?: boolean): boolean;
    getLastDeathPos(): CxxOptional<BlockPos>;
    getLastDeathDimension(): CxxOptional<DimensionId>;
    protected _getViewVector(unused: float32_t): Vec3;
    getViewVector(): Vec3;
    isImmobile(): boolean;
    isSwimming(): boolean;
    /**
     * Changes the actor's size
     * @remarks This function does not update the actor's skin size.
     *
     * @param width - New width
     * @param height - New height
     */
    setSize(width: number, height: number): void;
    isInsidePortal(): boolean;
    isInWorld(): boolean;
    isInWaterOrRain(): boolean;
    isInThunderstorm(): boolean;
    isInSnow(): boolean;
    isInScaffolding(): boolean;
    isInRain(): boolean;
    isInPrecipitation(): boolean;
    isInLove(): boolean;
    isInLava(): boolean;
    isInContactWithWater(): boolean;
    isInClouds(): boolean;
    /**
     * @deprecated it's meaningless. Doesn't work for decayed objects.
     */
    isRemoved(): boolean;
    isBaby(): boolean;
    getEntityData(): SynchedActorDataEntityWrapper;
    /**
     * Scale: 1 is for adult (normal), 0.5 is for baby.
     * It changes the size of Hitbox, and entity's size.
     */
    setScale(scale: float32_t): void;
    /**
     * Scale: 1 is for adult (normal), 0.5 is for baby.
     */
    getScale(): float32_t;
    getOwner(): Mob | null;
    setOwner(entityId: ActorUniqueID): void;
    getVariant(): int32_t;
    setVariant(variant: int32_t): void;
    protected _tryGetComponent(comp: string): any | null;
    tryGetComponent<K extends keyof ComponentsClassMap, T extends ComponentsClassMap[K]>(comp: K): T | null;
}
interface ComponentsClassMap {
    "minecraft:physics": PhysicsComponent;
    "minecraft:projectile": ProjectileComponent;
    "minecraft:damage_sensor": DamageSensorComponent;
    "minecraft:command_block": CommandBlockComponent;
    "minecraft:nameable": NameableComponent;
    "minecraft:navigation": NavigationComponent;
    "minecraft:npc": NpcComponent;
    "minecraft:rideable": RideableComponent;
    "minecraft:container": ContainerComponent;
    "minecraft:pushable": PushableComponent;
    "minecraft:shooter": ShooterComponent;
    "minecraft:conditional_bandwidth_optimization": ConditionalBandwidthOptimizationComponent;
}
export declare class SynchedActorDataEntityWrapper extends AbstractClass {
    /**
     * SynchedActorDataEntityWrapper::set<float>
     */
    setFloat(id: ActorDataIDs, value: float32_t): void;
    /**
     * SynchedActorDataEntityWrapper::getFloat
     */
    getFloat(id: ActorDataIDs): float32_t;
    /**
     * SynchedActorDataEntityWrapper::set<int>
     */
    setInt(id: ActorDataIDs, value: int32_t): void;
    /**
     * SynchedActorDataEntityWrapper::getInt
     */
    getInt(id: ActorDataIDs): int32_t;
}
export declare enum ActorDataIDs /** : unsigned short */ {
    Variant = 2,// used as int, in Actor::setVariant
    Scale = 38,// used as float, in Actor::setSize
    Width = 53,// used as float, in Actor::setSize
    Height = 54
}
export declare class DistanceSortedActor extends NativeStruct {
    entity: Actor;
    /** @deprecated use distanceSq */
    distance: float32_t;
    distanceSq: float32_t;
}
export declare class Mob extends Actor {
    /**
     * @returns the entity's armor value (as an integer)
     */
    getArmorValue(): number;
    /**
     * Applies knockback to the mob
     */
    knockback(source: Actor | null, damage: int32_t, xd: float32_t, zd: float32_t, power: float32_t, height: float32_t, heightCap: float32_t): void;
    getSpeed(): number;
    isSprinting(): boolean;
    sendArmorSlot(slot: ArmorSlot): void;
    setSprinting(shouldSprint: boolean): void;
    protected _sendInventory(shouldSelectSlot: boolean): void;
    /**
     * Updates the mob's inventory
     * @remarks used in PlayerHotbarPacket if the mob is a player
     *
     * @param shouldSelectSlot - Defines whether the sync selected slot also. (Sends `PlayerHotbarPacket`)
     */
    sendInventory(shouldSelectSlot?: boolean): void;
    setSpeed(speed: number): void;
    protected hurtEffects_(sourceOrCause: ActorDamageSource, damage: number, knock: boolean, ignite: boolean): boolean;
    /**
     * Shows hurt effects to the mob. Actually not hurt.
     * Useful when change the health of the mob without triggering {@link events.entityHurt} event.
     */
    hurtEffects(damageCause: ActorDamageCause, damage: number, knock: boolean, ignite: boolean): boolean;
    hurtEffects(damageSource: ActorDamageSource, damage: number, knock: boolean, ignite: boolean): boolean;
    getArmorCoverPercentage(): float32_t;
    getToughnessValue(): int32_t;
    isBlocking(): boolean;
}
export declare class ItemActor extends Actor {
    itemStack: ItemStack;
}
export {};
