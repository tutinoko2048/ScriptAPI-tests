import { VoidPointer } from "../core";
import type { CxxVector } from "../cxxvector";
import { NativeClass } from "../nativeclass";
import { bool_t, CxxString, CxxStringWith8Bytes, int32_t, uint16_t, uint8_t } from "../nativetype";
import type { Actor, DimensionId, ItemActor } from "./actor";
import type { ChunkPos } from "./blockpos";
import { BlockPos } from "./blockpos";
import type { ChunkSource, LevelChunk } from "./chunk";
import type { CommandName } from "./commandname";
import type { Dimension } from "./dimension";
import { HashedString } from "./hashedstring";
import type { Container, ItemStack, ItemStackBase } from "./inventory";
import { CompoundTag, NBT } from "./nbt";
import type { BlockActorDataPacket } from "./packets";
import type { Player, ServerPlayer } from "./player";
export declare class BlockLegacy extends NativeClass {
    vftable: VoidPointer;
    /**
     * @deprecated Use `this.getRenderBlock().getDescriptionId()` instead
     */
    descriptionId: CxxString;
    getCommandName(): string;
    /**
     * @deprecated Use `this.getCommandNames2()` instead
     */
    getCommandNames(): CxxVector<CxxStringWith8Bytes>;
    getCommandNames2(): CxxVector<CommandName>;
    /**
     * Returns the category of the block in creative inventory
     */
    getCreativeCategory(): number;
    /**
     * Changes the time needed to destroy the block
     * @remarks Will not affect actual destroy time but will affect the speed of cracks
     */
    setDestroyTime(time: number): void;
    /**
     * Returns the time needed to destroy the block
     */
    getDestroyTime(): number;
    /**
     * Returns the Block instance
     */
    getRenderBlock(): Block;
    getBlockEntityType(): BlockActorType;
    getBlockItemId(): number;
    getStateFromLegacyData(data: number): Block;
    use(subject: Player, blockPos: BlockPos, face: number): bool_t;
    getDefaultState(): Block;
    /**
     * @deprecated parameter removed
     */
    tryGetStateFromLegacyData(data: uint16_t, u: bool_t): Block;
    tryGetStateFromLegacyData(data: uint16_t): Block;
    getSilkTouchedItemInstance(block: Block): ItemStack;
    getDestroySpeed(): number;
}
export declare class Block extends NativeClass {
    vftable: VoidPointer;
    blockLegacy: BlockLegacy;
    /**
     * @removed use getVariant instead.
     */
    get data(): uint16_t;
    /**
     * @deprecated no need to destruct. use `Block.create`
     */
    static constructWith(blockName: BlockId, data?: number): Block | null;
    /**
     * @deprecated no need to destruct. use `Block.create`
     */
    static constructWith(blockName: string, data?: number): Block | null;
    /**
     * @param blockName Formats like 'minecraft:wool'
     * @return Block instance
     */
    static create(blockName: BlockId, data?: number): Block | null;
    /**
     * @return Block instance
     */
    static create(blockName: string, data?: number): Block | null;
    protected _getName(): HashedString;
    getName(): string;
    getDescriptionId(): CxxString;
    getRuntimeId(): int32_t;
    getBlockEntityType(): BlockActorType;
    hasBlockEntity(): boolean;
    use(subject: Player, blockPos: BlockPos, face: number): bool_t;
    getVariant(): number;
    getSerializationId(): CompoundTag;
    getSilkTouchItemInstance(): ItemStack;
    isUnbreakable(): boolean;
    buildDescriptionId(): string;
    isCropBlock(): boolean;
    popResource(blockSource: BlockSource, blockPos: BlockPos, itemStack: ItemStack): ItemActor;
    canHurtAndBreakItem(): boolean;
    getThickness(): number;
    hasComparatorSignal(): boolean;
    getTranslucency(): number;
    /** @deprecated */
    getExplosionResistance(actor: Actor | null): number;
    getExplosionResistance(): number;
    getComparatorSignal(blockSource: BlockSource, blockPos: BlockPos, facing: uint8_t): number;
    getDirectSignal(blockSource: BlockSource, blockPos: BlockPos, facing: int32_t): number;
    isSignalSource(): boolean;
    getDestroySpeed(): number;
}
declare enum BlockUpdateFlags {
    NONE = 0,
    NEIGHBORS = 1,
    NETWORK = 2,
    NOGRAPHIC = 4,
    PRIORITY = 8,
    ALL = 3,
    ALL_PRIORITY = 11
}
export declare class BlockSource extends NativeClass {
    vftable: VoidPointer;
    ownerThreadID: VoidPointer;
    allowUnpopulatedChunks: bool_t;
    publicSource: bool_t;
    protected _setBlock(x: number, y: number, z: number, block: Block, updateFlags: number, actor: Actor | null): boolean;
    getBlock(blockPos: BlockPos): Block;
    /**
     *
     * @param blockPos Position of the block to place
     * @param block The Block to place
     * @param updateFlags BlockUpdateFlags, to place without ticking neighbor updates use only BlockUpdateFlags.NETWORK
     * @returns true if the block was placed, false if it was not
     */
    setBlock(blockPos: BlockPos, block: Block, updateFlags?: BlockUpdateFlags): boolean;
    getChunk(pos: ChunkPos): LevelChunk | null;
    getChunkAt(pos: BlockPos): LevelChunk | null;
    getChunkSource(): ChunkSource;
    getBlockEntity(blockPos: BlockPos): BlockActor | null;
    getDimension(): Dimension;
    getDimensionId(): DimensionId;
    removeBlockEntity(blockPos: BlockPos): void;
    getBrightness(blockPos: BlockPos): number;
    checkBlockDestroyPermission(actor: Actor, blockPos: BlockPos, item: ItemStackBase, b: bool_t): bool_t;
}
export declare class BlockActor extends NativeClass {
    vftable: VoidPointer;
    isChestBlockActor(): this is ChestBlockActor;
    /**
     * @param tag this function stores nbt values to this parameter
     */
    save(tag: CompoundTag): boolean;
    /**
     * it returns JS converted NBT
     */
    save(): Record<string, any>;
    load(tag: CompoundTag | NBT.Compound): void;
    /**
     * @deprecated use allocateAndSave
     */
    constructAndSave(): CompoundTag;
    allocateAndSave(): CompoundTag;
    setChanged(): void;
    /**
     * Sets a custom name to the block. (e.g : chest, furnace...)
     *
     * @param name - Name to set
     *
     * @remarks This will not update the block client-side. use `BlockActor.updateClientSide()` to do so.
     */
    setCustomName(name: string): void;
    getContainer(): Container | null;
    getType(): BlockActorType;
    getPosition(): BlockPos;
    /**
     * make a packet for updating the client-side.
     * it has a risk about memoryleaks but following the original function name.
     *
     * @return allocated BlockActorDataPacket. it needs to be disposed of.
     */
    getServerUpdatePacket(blockSource: BlockSource): BlockActorDataPacket;
    /**
     * Updates the block actor client-side.
     *
     * @param player - The player to update the block for.
     */
    updateClientSide(player: ServerPlayer): void;
    getCustomName(): string;
}
export declare enum BlockActorType {
    None = 0,
    Furnace = 1,
    Chest = 2,
    NetherReactor = 3,
    Sign = 4,
    MobSpawner = 5,
    Skull = 6,
    FlowerPot = 7,
    BrewingStand = 8,
    EnchantingTable = 9,
    DaylightDetector = 10,
    Music = 11,
    Comparator = 12,
    Dispenser = 13,
    Dropper = 14,
    Hopper = 15,
    Cauldron = 16,
    ItemFrame = 17,
    Piston = 18,
    MovingBlock = 19,
    Beacon = 21,
    EndPortal = 22,
    EnderChest = 23,
    EndGateway = 24,
    ShulkerBox = 25,
    CommandBlock = 26,
    Bed = 27,
    Banner = 28,
    StructureBlock = 32,
    Jukebox = 33,
    ChemistryTable = 34,
    Conduit = 35,
    Jigsaw = 36,
    Lectern = 37,
    BlastFurnace = 38,
    Smoker = 39,
    Bell = 40,
    Campfire = 41,
    Barrel = 42,
    Beehive = 43,
    Lodestone = 44,
    SculkSensor = 45,
    SporeBlossom = 46,
    SculkCatalyst = 48
}
export declare class ButtonBlock extends BlockLegacy {
}
export declare class ChestBlock extends BlockLegacy {
}
export declare class ChestBlockActor extends BlockActor {
    /**
     * Returns whether the chest is a double chest
     */
    isLargeChest(): boolean;
    /**
     * Makes a player open the chest
     *
     * @param player - Player that will open the chest
     *
     * @remarks The chest must be in range of the player !
     */
    openBy(player: Player): void;
    /**
     * Returns the position of the other chest forming the double chest.
     *
     * @remarks If the chest is not a double chest, BlockPos ZERO (0,0,0) is returned.
     */
    getPairedChestPosition(): BlockPos;
}
export declare enum PistonAction {
    Extend = 1,
    Retract = 3
}
export declare class PistonBlockActor extends NativeClass {
    action: PistonAction;
    getPosition(): BlockPos;
    getAttachedBlocks(): BlockPos[];
    getFacingDir(region: BlockSource): BlockPos;
}
export declare class BlockUtils extends NativeClass {
    static isDownwardFlowingLiquid(block: Block): boolean;
    static isBeehiveBlock(block: BlockLegacy): boolean;
    static isWaterSource(block: Block): boolean;
    static isFullFlowingLiquid(block: Block): boolean;
    static allowsNetherVegetation(block: BlockLegacy): boolean;
    static isThinFenceOrWallBlock(block: Block): boolean;
    static isLiquidSource(block: Block): boolean;
    static getLiquidBlockHeight(block: Block, blockPos: BlockPos): number;
    static canGrowTreeWithBeehive(block: Block): boolean;
}
export {};
