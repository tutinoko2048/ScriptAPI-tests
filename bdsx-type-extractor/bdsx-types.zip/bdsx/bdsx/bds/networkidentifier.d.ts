import { StaticPointer, VoidPointer } from "../core";
import { Hashable } from "../hashset";
import { AbstractClass, NativeStruct } from "../nativeclass";
import { CxxString, bin64_t, int32_t } from "../nativetype";
import { CxxStringWrapper } from "../pointer";
import { ConnectionRequest } from "./connreq";
import type { Packet } from "./packet";
import type { ServerPlayer } from "./player";
import { RakNet } from "./raknet";
import { RakNetConnector } from "./raknetinstance";
declare enum SubClientId {
}
export declare class NetworkSystem extends AbstractClass {
    vftable: VoidPointer;
    /** @deprecated use bedrockServer.connector */
    instance: RakNetConnector;
    send(ni: NetworkIdentifier, packet: Packet, senderSubClientId: number): void;
    send(ni: NetworkIdentifier, packet: Packet, senderSubClientId: SubClientId): void;
    sendInternal(ni: NetworkIdentifier, packet: Packet, data: CxxStringWrapper): void;
    getConnectionFromId(ni: NetworkIdentifier): NetworkConnection | null;
}
export import NetworkHandler = NetworkSystem;
export declare class NetworkConnection extends AbstractClass {
    networkIdentifier: NetworkIdentifier;
    disconnect(): void;
}
export declare namespace NetworkSystem {
    /** @deprecated renamed to NetworkConnection */
    const Connection: typeof NetworkConnection;
    /** @deprecated renamed to NetworkConnection */
    type Connection = NetworkConnection;
}
declare class ServerNetworkHandler$Client extends AbstractClass {
}
export declare class ServerNetworkHandler extends AbstractClass {
    vftable: VoidPointer;
    readonly motd: CxxString;
    readonly maxPlayers: int32_t;
    disconnectClient(client: NetworkIdentifier, message?: string, skipMessage?: boolean): void;
    /**
     * @alias allowIncomingConnections
     */
    setMotd(motd: string): void;
    /**
     * @deprecated use setMaxNumPlayers
     */
    setMaxPlayers(count: number): void;
    allowIncomingConnections(motd: string, shouldAnnounce: boolean): void;
    updateServerAnnouncement(): void;
    setMaxNumPlayers(n: number): void;
    /**
     * it's the same with `client.getActor()`
     */
    _getServerPlayer(client: NetworkIdentifier, clientSubId: number): ServerPlayer | null;
    _getServerPlayer(client: NetworkIdentifier, clientSubId: SubClientId): ServerPlayer | null;
    fetchConnectionRequest(target: NetworkIdentifier): ConnectionRequest;
}
export declare namespace ServerNetworkHandler {
    type Client = ServerNetworkHandler$Client;
}
export declare class NetworkIdentifier extends NativeStruct implements Hashable {
    unknown: bin64_t;
    address: RakNet.AddressOrGUID;
    type: int32_t;
    assignTo(target: VoidPointer): void;
    equals(other: NetworkIdentifier): boolean;
    hash(): number;
    getActor(): ServerPlayer | null;
    getAddress(): string;
    toString(): string;
    static fromPointer(ptr: StaticPointer): NetworkIdentifier;
    static all(): IterableIterator<NetworkIdentifier>;
}
/** @deprecated use bedrockServer.networkSystem */
export declare let networkSystem: NetworkSystem;
export {};
