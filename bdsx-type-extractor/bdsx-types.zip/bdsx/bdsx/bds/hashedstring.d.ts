import { VoidPointer } from "../core";
import { NativeClass } from "../nativeclass";
import { CxxString, NativeType } from "../nativetype";
export declare class HashedString extends NativeClass {
    hash: VoidPointer | null;
    str: CxxString;
    recentCompared: HashedString | null;
    [NativeType.ctor](): void;
    set(str: string): void;
    static constructWith(str: string): HashedString;
}
export declare const HashedStringToString: NativeType<string>;
export type HashedStringToString = string;
