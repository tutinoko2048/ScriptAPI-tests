import type { VoidPointer } from "../core";
import { CxxVector, CxxVectorLike } from "../cxxvector";
import { NativeClass } from "../nativeclass";
import type { Actor, ActorDefinitionIdentifier, ActorRuntimeID, ActorUniqueID, DimensionId, EntityRefTraits, ItemActor, WeakEntityRef } from "./actor";
import { BlockLegacy, BlockSource } from "./block";
import type { BlockPos, Vec3 } from "./blockpos";
import type { Dimension } from "./dimension";
import type { GameRules } from "./gamerules";
import type { ItemStack } from "./inventory";
import type { Player, ServerPlayer } from "./player";
import type { Scoreboard } from "./scoreboard";
import { StructureManager } from "./structure";
import { WeakRefT } from "./weakreft";
export declare enum Difficulty {
    Peaceful = 0,
    Easy = 1,
    Normal = 2,
    Hard = 3
}
export declare class Level extends NativeClass {
    vftable: VoidPointer;
    /** @deprecated Use `this.getPlayers()` instead */
    get players(): CxxVectorLike<ServerPlayer>;
    /**
     * Returns an array of all online players in the level
     */
    getPlayers(): ServerPlayer[];
    getUsers(): CxxVector<EntityRefTraits>;
    getActiveUsers(): CxxVector<WeakEntityRef>;
    protected _getEntities(): CxxVector<EntityRefTraits>;
    getEntities(): Actor[];
    getRuntimeEntity(runtimeId: ActorRuntimeID, getRemoved?: boolean): Actor | null;
    getRuntimePlayer(runtimeId: ActorRuntimeID): Player | null;
    createDimension(id: DimensionId): Dimension;
    getOrCreateDimension(id: DimensionId): WeakRefT<Dimension>;
    /**
     * Destroys a block at the given position
     *
     * @returns {boolean} Whether the block was destroyed successfully
     */
    destroyBlock(blockSource: BlockSource, blockPos: BlockPos, dropResources: boolean): boolean;
    /**
     * Gets an entity with the given unique id
     */
    fetchEntity(actorUniqueId: ActorUniqueID, getRemoved: boolean): Actor | null;
    /**
     * Returns the number of current online players
     */
    getActivePlayerCount(): number;
    /**
     * Returns the ActorFactory instance
     */
    getActorFactory(): ActorFactory;
    /**
     * Returns the AdventureSettings instance
     */
    getAdventureSettings(): AdventureSettings;
    /**
     * Returns the BlockPalette instance
     */
    getBlockPalette(): BlockPalette;
    /**
     * Returns the Dimension instance
     */
    getDimension(dimension: DimensionId): Dimension | null;
    getDimensionWeakRef(dimension: DimensionId): WeakRefT<Dimension>;
    /**
     * Returns the LevelData instance
     */
    getLevelData(): LevelData;
    /**
     * Returns the GameRules instance
     * @deprecated use bedrockServer.gameRules
     */
    getGameRules(): GameRules;
    /**
     * Returns the Scoreboard instance
     */
    getScoreboard(): Scoreboard;
    /**
     * Returns the level's random seed
     */
    getSeed(): number;
    /**
     * Constructs a StructureManager instance, you need to destruct it later
     * @deprecated use bedrockServer.structureManager
     */
    getStructureManager(): StructureManager;
    /**
     * Returns the Spawner instance
     */
    getSpawner(): Spawner;
    /**
     * Returns the TagRegistry instance
     */
    getTagRegistry(): TagRegistry;
    /**
     * Returns the level's time
     */
    getTime(): number;
    /**
     * Returns the level's current tick
     */
    getCurrentTick(): number;
    /**
     * Returns whether the level has allow-cheats turned on
     */
    hasCommandsEnabled(): boolean;
    /**
     * Changes the allow-cheats state of the level
     */
    setCommandsEnabled(value: boolean): void;
    setShouldSendSleepMessage(value: boolean): void;
    /**
     * Changes the level's time
     */
    setTime(time: number): void;
    /**
     * Syncs the level's game rules with all clients
     */
    syncGameRules(): void;
    /**
     * Spawn a particle effect at the given position
     *
     * @param effectName accepts format like "minecraft:arrow_spell_emitter"
     *
     * @see https://www.digminecraft.com/lists/particle_list_pe.php
     * */
    spawnParticleEffect(effectName: string, spawnLocation: Vec3, dimension: Dimension): void;
    /**
     * Returns a random Player
     */
    getRandomPlayer(): Player | null;
    /**
     * Updates the level's weather
     */
    updateWeather(rainLevel: number, rainTime: number, lightningLevel: number, lightningTime: number): void;
    setDefaultSpawn(pos: BlockPos): void;
    getDefaultSpawn(): BlockPos;
    explode(region: BlockSource, source: Actor | null, pos: Vec3, explosionRadius: number, fire: boolean, breaksBlocks: boolean, maxResistance: number, allowUnderwater: boolean): void;
    getPlayerByXuid(xuid: string): Player | null;
    getDifficulty(): Difficulty;
    setDifficulty(difficulty: Difficulty): void;
    getNewUniqueID(): ActorUniqueID;
    getNextRuntimeID(): ActorRuntimeID;
    sendAllPlayerAbilities(player: Player): void;
}
export declare class ServerLevel extends Level {
}
export declare class LevelData extends NativeClass {
    getGameDifficulty(): Difficulty;
    setGameDifficulty(value: Difficulty): void;
}
export declare class ActorFactory extends NativeClass {
}
export declare namespace JsonUtil {
    /** @param name only accepts format like "minecraft:wool" */
    function getBlockLegacy(name: BlockId): BlockLegacy;
    function getBlockLegacy(name: string): BlockLegacy;
}
export declare class BlockPalette extends NativeClass {
    /**
     * @deprecated use {@link JsonUtil.getBlockLegacy}
     */
    getBlockLegacy(name: BlockId | string): BlockLegacy;
}
export declare class AdventureSettings extends NativeClass {
}
export declare class TagRegistry extends NativeClass {
}
export declare class Spawner extends NativeClass {
    spawnItem(region: BlockSource, itemStack: ItemStack, pos: Vec3, throwTime: number): ItemActor;
    spawnMob(region: BlockSource, id: ActorDefinitionIdentifier, pos: Vec3, naturalSpawn?: boolean, surface?: boolean, fromSpawner?: boolean): Actor;
}
export declare enum LevelEvent {
    SoundClick = 1000,
    SoundClickFail = 1001,
    SoundLaunch = 1002,
    SoundOpenDoor = 1003,
    SoundFizz = 1004,
    SoundFuse = 1005,
    SoundPlayRecording = 1006,
    SoundGhastWarning = 1007,
    SoundGhastFireball = 1008,
    SoundBlazeFireball = 1009,
    SoundZombieWoodenDoor = 1010,
    SoundZombieDoorCrash = 1012,
    SoundZombieInfected = 1016,
    SoundZombieConverted = 1017,
    SoundEndermanTeleport = 1018,
    SoundAnvilBroken = 1020,
    SoundAnvilUsed = 1021,
    SoundAnvilLand = 1022,
    SoundInfinityArrowPickup = 1030,
    SoundTeleportEnderPearl = 1032,
    SoundAddItem = 1040,
    SoundItemFrameBreak = 1041,
    SoundItemFramePlace = 1042,
    SoundItemFrameRemoveItem = 1043,
    SoundItemFrameRotateItem = 1044,
    SoundExperienceOrbPickup = 1051,
    SoundTotemUsed = 1052,
    SoundArmorStandBreak = 1060,
    SoundArmorStandHit = 1061,
    SoundArmorStandLand = 1062,
    SoundArmorStandPlace = 1063,
    ParticlesShoot = 2000,
    ParticlesDestroyBlock = 2001,
    ParticlesPotionSplash = 2002,
    ParticlesEyeOfEnderDeath = 2003,
    ParticlesMobBlockSpawn = 2004,
    ParticleCropGrowth = 2005,
    ParticleSoundGuardianGhost = 2006,
    ParticleDeathSmoke = 2007,
    ParticleDenyBlock = 2008,
    ParticleGenericSpawn = 2009,
    ParticlesDragonEgg = 2010,
    ParticlesCropEaten = 2011,
    ParticlesCrit = 2012,
    ParticlesTeleport = 2013,
    ParticlesCrackBlock = 2014,
    ParticlesBubble = 2015,
    ParticlesEvaporate = 2016,
    ParticlesDestroyArmorStand = 2017,
    ParticlesBreakingEgg = 2018,
    ParticleDestroyEgg = 2019,
    ParticlesEvaporateWater = 2020,
    ParticlesDestroyBlockNoSound = 2021,
    ParticlesKnockbackRoar = 2022,
    ParticlesTeleportTrail = 2023,
    ParticlesPointCloud = 2024,
    ParticlesExplosion = 2025,
    ParticlesBlockExplosion = 2026,
    StartRaining = 185,
    StartThunderstorm = 186,
    StopRaining = 187,
    StopThunderstorm = 188,
    GlobalPause = 189,
    SimTimeStep = 190,
    SimTimeScale = 191,
    ActivateBlock = 3500,
    CauldronExplode = 3501,
    CauldronDyeArmor = 3502,
    CauldronCleanArmor = 3503,
    CauldronFillPotion = 3504,
    CauldronTakePotion = 3505,
    CauldronFillWater = 3506,
    CauldronTakeWater = 3507,
    CauldronAddDye = 3508,
    CauldronCleanBanner = 3509,
    CauldronFlush = 3510,
    AgentSpawnEffect = 3511,
    CauldronFillLava = 3512,
    CauldronTakeLava = 3513,
    StartBlockCracking = 3600,
    StopBlockCracking = 3601,
    UpdateBlockCracking = 3602,
    AllPlayersSleeping = 9800,
    JumpPrevented = 9810,
    ParticleLegacyEvent = 16384
}
export declare enum BedSleepingResult {
    OK_2 = 0,
    NOT_POSSIBLE_HERE = 1,
    NOT_POSSIBLE_NOW = 2,
    TOO_FAR_AWAY = 3,
    OTHER_PROBLEM = 4,
    NOT_SAFE = 5
}
