import { BuildPlatform } from "../common";
import { VoidPointer } from "../core";
import { CxxPair } from "../cxxpair";
import { CxxVector } from "../cxxvector";
import { mce } from "../mce";
import { AbstractClass, MantleClass, NativeClass, NativeStruct } from "../nativeclass";
import { bin64_t, bool_t, CxxString, float32_t, int16_t, int32_t, int64_as_float_t, NativeType, uint16_t, uint32_t, uint64_as_float_t, uint8_t } from "../nativetype";
import { ActorDefinitionIdentifier, ActorLink, ActorRuntimeID, ActorUniqueID } from "./actor";
import { AttributeInstanceHandle } from "./attribute";
import { BlockPos, ChunkPos, Vec2, Vec3 } from "./blockpos";
import { ConnectionRequest, JsonValue } from "./connreq";
import { CxxOptional } from "./cxxoptional";
import type { Form } from "./form";
import { HashedString } from "./hashedstring";
import { ComplexInventoryTransaction, ContainerId, ContainerType, ItemStackNetIdVariant, NetworkItemStackDescriptor } from "./inventory";
import { Difficulty } from "./level";
import { MolangVariableMap } from "./molangvariablemap";
import { CompoundTag } from "./nbt";
import { Packet } from "./packet";
import type { GameType, Player } from "./player";
import { DisplaySlot, ObjectiveSortOrder, ScoreboardId } from "./scoreboard";
import { SerializedSkin } from "./skin";
export declare class LoginPacket extends Packet {
    protocol: int32_t;
    /**
     * it can be null if the wrong client version
     */
    connreq: ConnectionRequest | null;
}
export declare class PlayStatusPacket extends Packet {
    status: int32_t;
}
export declare class ServerToClientHandshakePacket extends Packet {
    jwt: CxxString;
}
export declare class ClientToServerHandshakePacket extends Packet {
}
export declare class DisconnectPacket extends Packet {
    skipMessage: bool_t;
    message: CxxString;
}
export declare enum PackType {
    Invalid = 0,
    Addon = 1,
    Cached = 2,
    CopyProtected = 3,
    Behavior = 4,
    PersonaPiece = 5,
    Resources = 6,
    Skins = 7,
    WorldTemplate = 8,
    Count = 9
}
export declare class ResourcePacksInfoPacket extends Packet {
}
export declare class ResourcePackStackPacket extends Packet {
}
/** @deprecated Use ResourcePackStackPacket, follow the real class name */
export declare const ResourcePackStacksPacket: typeof ResourcePackStackPacket;
/** @deprecated use ResourcePackStackPacket, follow the real class name */
export type ResourcePackStacksPacket = ResourcePackStackPacket;
export declare enum ResourcePackResponse {
    Cancel = 1,
    Downloading = 2,
    DownloadingFinished = 3,
    ResourcePackStackFinished = 4
}
export declare class ResourcePackClientResponsePacket extends Packet {
}
export declare class TextPacket extends Packet {
    type: TextPacket.Types;
    name: CxxString;
    message: CxxString;
    params: CxxVector<CxxString>;
    needsTranslation: bool_t;
    xboxUserId: CxxString;
    platformChatId: CxxString;
}
export declare namespace TextPacket {
    enum Types {
        Raw = 0,
        Chat = 1,
        Translate = 2,
        /** @deprecated **/
        Translated = 2,
        Popup = 3,
        JukeboxPopup = 4,
        Tip = 5,
        SystemMessage = 6,
        /** @deprecated **/
        Sytem = 6,
        Whisper = 7,
        Announcement = 8,
        TextObject = 9,
        /** @deprecated **/
        ObjectWhisper = 9
    }
}
export declare class SetTimePacket extends Packet {
    time: int32_t;
}
export declare class LevelSettings extends MantleClass {
    seed: int64_as_float_t;
    gameType: GameType;
    difficulty: Difficulty;
    commandsEnabled: bool_t;
    texturePacksRequired: bool_t;
    customSkinsDisabled: bool_t;
}
export declare class StartGamePacket extends Packet {
    readonly settings: LevelSettings;
}
export declare class AddPlayerPacket extends Packet {
}
export declare class AddActorPacket extends Packet {
    readonly links: CxxVector<ActorLink>;
    readonly pos: Vec3;
    readonly velocity: Vec3;
    readonly rot: Vec2;
    headYaw: float32_t;
    entityId: ActorUniqueID;
    runtimeId: ActorRuntimeID;
    readonly type: ActorDefinitionIdentifier;
    readonly attributeHandles: CxxVector<AttributeInstanceHandle>;
}
export declare class RemoveActorPacket extends Packet {
    actorId: ActorUniqueID;
}
export declare class AddItemActorPacket extends Packet {
}
export declare class TakeItemActorPacket extends Packet {
}
export declare class MoveActorAbsolutePacket extends Packet {
    actorId: ActorRuntimeID;
    flags: uint8_t;
    pos: Vec3;
    /** Byte of x-rotation(pitch), to convert to normal pitch value divide it by 0.71
     * @see https://wiki.vg/Bedrock_Protocol#Data_types PlayerLocation */
    xRot: uint8_t;
    /** Byte of y-rotation(yaw), to convert to normal yaw value divide it by 0.71
     * @see https://wiki.vg/Bedrock_Protocol#Data_types PlayerLocation */
    yRot: uint8_t;
    /** Byte of z-rotation(head yaw), to convert to normal yaw value divide it by 0.71
     * @see https://wiki.vg/Bedrock_Protocol#Data_types PlayerLocation */
    zRot: uint8_t;
}
export declare namespace MoveActorAbsolutePacket {
    enum Flags {
        hasX = 1,
        hasY = 2,
        hasZ = 4,
        hasPitch = 8,
        hasYaw = 16,
        hasHeadYaw = 32,
        onGround = 64,
        teleported = 128
    }
}
export declare class MovePlayerPacket extends Packet {
    actorId: ActorRuntimeID;
    readonly pos: Vec3;
    pitch: float32_t;
    yaw: float32_t;
    headYaw: float32_t;
    mode: uint8_t;
    onGround: bool_t;
    ridingActorId: ActorRuntimeID;
    teleportCause: int32_t;
    teleportItem: int32_t;
    tick: bin64_t;
}
export declare namespace MovePlayerPacket {
    enum Modes {
        Normal = 0,
        Reset = 1,
        Teleport = 2,
        Pitch = 3
    }
}
export declare class PassengerJumpPacket extends Packet {
}
/** @deprecated use PassengerJumpPacket */
export declare const RiderJumpPacket: typeof PassengerJumpPacket;
/** @deprecated use PassengerJumpPacket */
export type RiderJumpPacket = PassengerJumpPacket;
export declare class UpdateBlockPacket extends Packet {
    readonly blockPos: BlockPos;
    dataLayerId: UpdateBlockPacket.DataLayerIds;
    flags: UpdateBlockPacket.Flags;
    blockRuntimeId: uint32_t;
}
export declare namespace UpdateBlockPacket {
    enum Flags {
        None = 0,
        Neighbors = 1,
        Network = 2,
        All = 3,
        NoGraphic = 4,
        Priority = 8,
        AllPriority = 11
    }
    enum DataLayerIds {
        Normal = 0,
        Liquid = 1
    }
}
export declare class AddPaintingPacket extends Packet {
}
export declare class TickSyncPacket extends Packet {
}
/** @deprecated Removed packet, use LevelSoundEventPacket instead. */
export declare class LevelSoundEventPacketV1 extends Packet {
}
export declare class LevelEventPacket extends Packet {
    eventId: int32_t;
    readonly pos: Vec3;
    data: int32_t;
}
export declare class BlockEventPacket extends Packet {
    readonly pos: BlockPos;
    type: int32_t;
    data: int32_t;
}
export declare class ActorEventPacket extends Packet {
    actorId: ActorRuntimeID;
    event: uint8_t;
    data: int32_t;
}
export declare namespace ActorEventPacket {
    enum Events {
        Jump = 1,
        HurtAnimation = 2,
        DeathAnimation = 3,
        ArmSwing = 4,
        StopAttack = 5,
        TameFail = 6,
        TameSuccess = 7,
        ShakeWet = 8,
        UseItem = 9,
        EatGrassAnimation = 10,
        FishHookBubble = 11,
        FishHookPosition = 12,
        FishHookHook = 13,
        FishHookTease = 14,
        SquidInkCloud = 15,
        ZombieVillagerCure = 16,
        AmbientSound = 17,
        Respawn = 18,
        IronGolemOfferFlower = 19,
        IronGolemWithdrawFlower = 20,
        LoveParticles = 21,
        VillagerAngry = 22,
        VillagerHappy = 23,
        WitchSpellParticles = 24,
        FireworkParticles = 25,
        InLoveParticles = 26,
        SilverfishSpawnAnimation = 27,
        GuardianAttack = 28,
        WitchDrinkPotion = 29,
        WitchThrowPotion = 30,
        MinecartTntPrimeFuse = 31,
        CreeperPrimeFuse = 32,
        AirSupplyExpired = 33,
        PlayerAddXpLevels = 34,
        ElderGuardianCurse = 35,
        AgentArmSwing = 36,
        EnderDragonDeath = 37,
        DustParticles = 38,
        ArrowShake = 39,
        EatingItem = 57,
        BabyAnimalFeed = 60,
        DeathSmokeCloud = 61,
        CompleteTrade = 62,
        RemoveLeash = 63,
        ConsumeTotem = 65,
        PlayerCheckTreasureHunterAchievement = 66,
        EntitySpawn = 67,
        DragonPuke = 68,
        ItemEntityMerge = 69,
        StartSwim = 70,
        BalloonPop = 71,
        TreasureHunt = 72,
        AgentSummon = 73,
        ChargedCrossbow = 74,
        Fall = 75
    }
}
export declare class MobEffectPacket extends Packet {
}
declare class AttributeModifier extends AbstractClass {
}
export declare class AttributeData extends NativeClass {
    current: number;
    min: number;
    max: number;
    default: number;
    readonly name: HashedString;
    _dummy1: AttributeModifier | null;
    _dummy2: AttributeModifier | null;
    _dummy3: AttributeModifier | null;
    [NativeType.ctor](): void;
}
export declare class UpdateAttributesPacket extends Packet {
    actorId: ActorRuntimeID;
    readonly attributes: CxxVector<AttributeData>;
}
export declare class InventoryTransactionPacket extends Packet {
    legacyRequestId: uint32_t;
    transaction: ComplexInventoryTransaction | null;
}
export declare class MobEquipmentPacket extends Packet {
    runtimeId: ActorRuntimeID;
    readonly item: NetworkItemStackDescriptor;
    slot: int32_t;
    selectedSlot: int32_t;
    containerId: ContainerId;
}
export declare class MobArmorEquipmentPacket extends Packet {
}
export declare class InteractPacket extends Packet {
    action: uint8_t;
    actorId: ActorRuntimeID;
    readonly pos: Vec3;
}
export declare namespace InteractPacket {
    enum Actions {
        LeaveVehicle = 3,
        Mouseover = 4,
        OpenNPC = 5,
        OpenInventory = 6
    }
}
export declare class BlockPickRequestPacket extends Packet {
}
export declare class ActorPickRequestPacket extends Packet {
}
export declare class PlayerActionPacket extends Packet {
    readonly pos: BlockPos;
    readonly resultPos: BlockPos;
    face: int32_t;
    action: PlayerActionPacket.Actions;
    actorId: ActorRuntimeID;
}
export declare namespace PlayerActionPacket {
    enum Actions {
        /** @deprecated */
        StartBreak = 0,
        /** @deprecated */
        AbortBreak = 1,
        /** @deprecated */
        StopBreak = 2,
        GetUpdatedBlock = 3,
        /** @deprecated */
        DropItem = 4,
        StartSleeping = 5,
        StopSleeping = 6,
        Respawn = 7,
        /** @deprecated */
        Jump = 8,
        /** @deprecated */
        StartSprint = 9,
        /** @deprecated */
        StopSprint = 10,
        /** @deprecated */
        StartSneak = 11,
        /** @deprecated */
        StopSneak = 12,
        CreativePlayerDestroyBlock = 13,
        DimensionChangeAck = 14,
        /** @deprecated */
        StartGlide = 15,
        /** @deprecated */
        StopGlide = 16,
        /** @deprecated */
        BuildDenied = 17,
        CrackBreak = 18,
        /** @deprecated */
        ChangeSkin = 19,
        /** @deprecated */
        SetEnchantmentSeed = 20,
        /** @deprecated */
        StartSwimming = 21,
        /** @deprecated */
        StopSwimming = 22,
        StartSpinAttack = 23,
        StopSpinAttack = 24,
        InteractBlock = 25,
        PredictDestroyBlock = 26,
        ContinueDestroyBlock = 27,
        StartItemUseOn = 28,
        StopItemUseOn = 29
    }
}
export declare class EntityFallPacket extends Packet {
}
export declare class HurtArmorPacket extends Packet {
}
export declare class SetActorDataPacket extends Packet {
}
export declare class SetActorMotionPacket extends Packet {
    runtimeId: ActorRuntimeID;
    motion: Vec3;
}
export declare class SetActorLinkPacket extends Packet {
    link: ActorLink;
}
export declare class SetHealthPacket extends Packet {
    health: uint8_t;
}
export declare class SetSpawnPositionPacket extends Packet {
    pos: BlockPos;
    spawnType: int32_t;
    dimension: int32_t;
    causingBlockPos: BlockPos;
}
export declare class AnimatePacket extends Packet {
    actorId: ActorRuntimeID;
    action: int32_t;
    rowingTime: float32_t;
}
export declare namespace AnimatePacket {
    enum Actions {
        SwingArm = 1,
        WakeUp = 3,
        CriticalHit = 4,
        MagicCriticalHit = 5,
        RowRight = 128,
        RowLeft = 129
    }
}
export declare class RespawnPacket extends Packet {
    pos: Vec3;
    state: uint8_t;
    runtimeId: ActorRuntimeID | null;
}
export declare class ContainerOpenPacket extends Packet {
    /** @deprecated */
    windowId: uint8_t;
    containerId: ContainerId;
    type: ContainerType;
    readonly pos: BlockPos;
    entityUniqueIdAsNumber: int64_as_float_t;
    entityUniqueId: bin64_t;
}
export declare class ContainerClosePacket extends Packet {
    /** @deprecated */
    windowId: uint8_t;
    containerId: ContainerId;
    server: bool_t;
}
export declare class PlayerHotbarPacket extends Packet {
    selectedSlot: uint32_t;
    selectHotbarSlot: bool_t;
    /** @deprecated */
    windowId: uint8_t;
    containerId: ContainerId;
}
export declare class InventoryContentPacket extends Packet {
    containerId: ContainerId;
    readonly slots: CxxVector<NetworkItemStackDescriptor>;
}
export declare class InventorySlotPacket extends Packet {
    containerId: ContainerId;
    slot: uint32_t;
    descriptor: NetworkItemStackDescriptor;
}
export declare class ContainerSetDataPacket extends Packet {
}
export declare class CraftingDataPacket extends Packet {
}
/** @deprecated removed */
export declare class CraftingEventPacket extends Packet {
    containerId: ContainerId;
    containerType: ContainerType;
    recipeId: mce.UUID;
    readonly inputItems: CxxVector<NetworkItemStackDescriptor>;
    readonly outputItems: CxxVector<NetworkItemStackDescriptor>;
}
export declare class GuiDataPickItemPacket extends Packet {
}
/**
 * @deprecated deleted from BDS
 */
export declare class AdventureSettingsPacket extends Packet {
    flag1: uint32_t;
    commandPermission: uint32_t;
    flag2: uint32_t;
    playerPermission: uint32_t;
    actorId: ActorUniqueID;
    customFlag: uint32_t;
}
export declare class BlockActorDataPacket extends Packet {
    readonly pos: BlockPos;
    readonly data: CompoundTag;
}
export declare class PlayerInputPacket extends Packet {
}
export declare class LevelChunkPacket extends Packet {
    readonly pos: ChunkPos;
    cacheEnabled: bool_t;
    serializedChunk: CxxString;
    subChunksCount: uint32_t;
}
export declare class SetCommandsEnabledPacket extends Packet {
    commandsEnabled: bool_t;
}
export declare class SetDifficultyPacket extends Packet {
    difficulty: Difficulty;
}
export declare class ChangeDimensionPacket extends Packet {
    dimensionId: uint32_t;
    x: float32_t;
    y: float32_t;
    z: float32_t;
    respawn: bool_t;
}
export declare class SetPlayerGameTypePacket extends Packet {
    playerGameType: GameType;
}
export declare class PlayerListEntry extends AbstractClass {
    id: ActorUniqueID;
    uuid: mce.UUID;
    name: CxxString;
    xuid: CxxString;
    platformOnlineId: CxxString;
    buildPlatform: BuildPlatform;
    readonly skin: SerializedSkin;
    static constructWith(player: Player): PlayerListEntry;
    /** @deprecated Use {@link constructWith()} instead  */
    static create(player: Player): PlayerListEntry;
}
export declare class PlayerListPacket extends Packet {
    readonly entries: CxxVector<PlayerListEntry>;
    action: uint8_t;
}
export declare class SimpleEventPacket extends Packet {
    subtype: uint16_t;
}
export declare class LegacyTelemetryEventPacket extends Packet {
}
/** @deprecated Use LegacyTelemetryEventPacket instead, to match to official class name*/
export declare const EventPacket: typeof LegacyTelemetryEventPacket;
/** @deprecated Use LegacyTelemetryEventPacket instead, to match to official class name*/
export type EventPacket = LegacyTelemetryEventPacket;
/** @deprecated Use EventPacket instead, to match to official class name*/
export declare const TelemetryEventPacket: typeof LegacyTelemetryEventPacket;
/** @deprecated Use EventPacket instead, to match to official class name*/
export type TelemetryEventPacket = EventPacket;
export declare class SpawnExperienceOrbPacket extends Packet {
    readonly pos: Vec3;
    amount: int32_t;
}
export declare class ClientboundMapItemDataPacket extends Packet {
}
/** @deprecated Use ClientboundMapItemDataPacket instead, to match to official class name*/
export declare const MapItemDataPacket: typeof ClientboundMapItemDataPacket;
/** @deprecated Use ClientboundMapItemDataPacket instead, to match to official class name*/
export type MapItemDataPacket = ClientboundMapItemDataPacket;
/** @deprecated Use ClientboundMapItemDataPacket instead, to match to official class name*/
export declare const ClientboundMapItemData: typeof ClientboundMapItemDataPacket;
/** @deprecated Use ClientboundMapItemDataPacket instead, to match to official class name*/
export type ClientboundMapItemData = ClientboundMapItemDataPacket;
export declare class MapInfoRequestPacket extends Packet {
}
export declare class RequestChunkRadiusPacket extends Packet {
}
export declare class ChunkRadiusUpdatedPacket extends Packet {
}
export declare class ItemFrameDropItemPacket extends Packet {
}
export declare class GameRulesChangedPacket extends Packet {
}
export declare class CameraPacket extends Packet {
}
export declare class BossEventPacket extends Packet {
    /** @deprecated */
    unknown: bin64_t;
    /** Always 1 */
    flagDarken: int32_t;
    /** Always 2 */
    flagFog: int32_t;
    /** Unique ID of the boss */
    entityUniqueId: bin64_t;
    playerUniqueId: bin64_t;
    type: uint32_t;
    title: CxxString;
    healthPercent: float32_t;
    color: BossEventPacket.Colors;
    overlay: BossEventPacket.Overlay;
    darkenScreen: bool_t;
    createWorldFog: bool_t;
}
export declare namespace BossEventPacket {
    enum Types {
        Show = 0,
        RegisterPlayer = 1,
        Hide = 2,
        UnregisterPlayer = 3,
        HealthPercent = 4,
        Title = 5,
        Properties = 6,
        Style = 7
    }
    enum Colors {
        Pink = 0,
        Blue = 1,
        Red = 2,
        Green = 3,
        Yellow = 4,
        Purple = 5,
        White = 6
    }
    enum Overlay {
        Progress = 0,
        Notched6 = 1,
        Notched10 = 2,
        Notched12 = 3,
        Notched20 = 4
    }
}
export declare class ShowCreditsPacket extends Packet {
    runtimeId: ActorRuntimeID;
    state: ShowCreditsPacket.CreditsState;
}
export declare namespace ShowCreditsPacket {
    enum CreditsState {
        StartCredits = 0,
        EndCredits = 1
    }
}
declare class AvailableCommandsParamData extends NativeClass {
    paramName: CxxString;
    paramType: int32_t;
    isOptional: bool_t;
    flags: uint8_t;
}
declare class AvailableCommandsOverloadData extends NativeClass {
    readonly parameters: CxxVector<AvailableCommandsParamData>;
}
declare class AvailableCommandsCommandData extends AbstractClass {
    name: CxxString;
    description: CxxString;
    flags: uint16_t;
    permission: uint8_t;
    /** @deprecated use overloads */
    readonly parameters: CxxVector<CxxVector<CxxString>>;
    readonly overloads: CxxVector<AvailableCommandsOverloadData>;
    aliases: int32_t;
}
declare class AvailableCommandsEnumData extends AbstractClass {
}
export declare class AvailableCommandsPacket extends Packet {
    readonly enumValues: CxxVector<CxxString>;
    readonly postfixes: CxxVector<CxxString>;
    readonly enums: CxxVector<AvailableCommandsEnumData>;
    readonly commands: CxxVector<AvailableCommandsCommandData>;
}
export declare namespace AvailableCommandsPacket {
    type CommandData = AvailableCommandsCommandData;
    const CommandData: typeof AvailableCommandsCommandData;
    type EnumData = AvailableCommandsEnumData;
    const EnumData: typeof AvailableCommandsEnumData;
}
export declare class CommandRequestPacket extends Packet {
    command: CxxString;
}
export declare class CommandBlockUpdatePacket extends Packet {
}
export declare class CommandOutputPacket extends Packet {
}
export declare class UpdateTradePacket extends Packet {
    containerId: ContainerId;
    containerType: ContainerType;
    displayName: CxxString;
    traderTier: int32_t;
    entityId: ActorUniqueID;
    lastTradingPlayer: ActorUniqueID;
    data: CompoundTag;
}
export declare class UpdateEquipPacket extends Packet {
}
export declare class ResourcePackDataInfoPacket extends Packet {
}
export declare class ResourcePackChunkDataPacket extends Packet {
}
export declare class ResourcePackChunkRequestPacket extends Packet {
}
export declare class TransferPacket extends Packet {
    address: CxxString;
    port: uint16_t;
}
export declare class PlaySoundPacket extends Packet {
    soundName: CxxString;
    /**
     * coordinates that are 8 times larger.
     * packet.pos.x = pos.x * 8
     */
    readonly pos: BlockPos;
    volume: float32_t;
    pitch: float32_t;
}
export declare class StopSoundPacket extends Packet {
    soundName: CxxString;
    stopAll: bool_t;
}
/**
 * @remark use ServerPlayer.sendTitle instead of sending it.
 */
export declare class SetTitlePacket extends Packet {
    type: int32_t;
    text: CxxString;
    fadeInTime: int32_t;
    stayTime: int32_t;
    fadeOutTime: int32_t;
    xuid: CxxString;
    platformOnlineId: CxxString;
}
export declare namespace SetTitlePacket {
    enum Types {
        Clear = 0,
        Reset = 1,
        Title = 2,
        Subtitle = 3,
        Actionbar = 4,
        AnimationTimes = 5
    }
}
export declare class AddBehaviorTreePacket extends Packet {
}
export declare class StructureBlockUpdatePacket extends Packet {
}
/** @deprecated This packet only works on partnered servers.*/
export declare class ShowStoreOfferPacket extends Packet {
}
/** @deprecated This packet only works on partnered servers.*/
export declare class PurchaseReceiptPacket extends Packet {
}
export declare class PlayerSkinPacket extends Packet {
    uuid: mce.UUID;
    readonly skin: SerializedSkin;
    localizedNewSkinName: CxxString;
    localizedOldSkinName: CxxString;
}
export declare class SubClientLoginPacket extends Packet {
}
export declare class AutomationClientConnectPacket extends Packet {
}
/** @deprecated Use AutomationClientConnectPacket instead, to match to official class name*/
export declare const WSConnectPacket: typeof AutomationClientConnectPacket;
/** @deprecated Use AutomationClientConnectPacket instead, to match to official class name*/
export type WSConnectPacket = AutomationClientConnectPacket;
export declare class SetLastHurtByPacket extends Packet {
}
export declare class BookEditPacket extends Packet {
    type: uint8_t;
    inventorySlot: int32_t;
    pageNumber: int32_t;
    secondaryPageNumber: int32_t;
    text: CxxString;
    author: CxxString;
    xuid: CxxString;
}
export declare namespace BookEditPacket {
    enum Types {
        ReplacePage = 0,
        AddPage = 1,
        DeletePage = 2,
        SwapPages = 3,
        SignBook = 4
    }
}
export declare class NpcRequestPacket extends Packet {
    runtimeId: ActorRuntimeID;
    requestType: NpcRequestPacket.RequestType;
    command: CxxString;
    actionType: NpcRequestPacket.ActionType;
    sceneName: CxxString;
}
export declare namespace NpcRequestPacket {
    enum RequestType {
        SetActions = 0,
        ExecuteAction = 1,
        ExecuteClosingCommands = 2,
        SetName = 3,
        SetAction = 4,
        SetSkin = 5,
        SetInteractionText = 6
    }
    enum ActionType {
        SetActions = 0,
        ExecuteAction = 1,
        ExecuteClosingCommands = 2,
        SetName = 3,
        SetAction = 4,
        SetSkin = 5,
        SetInteractionText = 6,
        ExecuteOpeningCommands = 7
    }
}
/** @deprecated Only usable in Education Edition, Bedrock will not display the photo. */
export declare class PhotoTransferPacket extends Packet {
}
export declare class ModalFormRequestPacket extends Packet {
    id: uint32_t;
    content: CxxString;
}
/** @deprecated use ModalFormRequestPacket, follow the real class name */
export declare const ShowModalFormPacket: typeof ModalFormRequestPacket;
/** @deprecated use ModalFormRequestPacket, follow the real class name */
export type ShowModalFormPacket = ModalFormRequestPacket;
export declare class ModalFormResponsePacket extends Packet {
    id: uint32_t;
    response: CxxOptional<JsonValue>;
    cancelationReason: CxxOptional<Form.CancelationReason>;
}
export declare class ServerSettingsRequestPacket extends Packet {
}
export declare class ServerSettingsResponsePacket extends Packet {
    id: uint32_t;
    content: CxxString;
}
export declare class ShowProfilePacket extends Packet {
    xuid: CxxString;
}
export declare class SetDefaultGameTypePacket extends Packet {
}
export declare class RemoveObjectivePacket extends Packet {
    objectiveName: CxxString;
}
export declare class SetDisplayObjectivePacket extends Packet {
    displaySlot: "list" | "sidebar" | "belowname" | "" | DisplaySlot;
    objectiveName: CxxString;
    displayName: CxxString;
    criteriaName: "dummy" | "";
    sortOrder: ObjectiveSortOrder;
}
export declare class ScorePacketInfo extends NativeClass {
    scoreboardId: ScoreboardId;
    objectiveName: CxxString;
    score: int32_t;
    type: ScorePacketInfo.Type;
    playerEntityUniqueId: bin64_t;
    entityUniqueId: bin64_t;
    customName: CxxString;
}
export declare namespace ScorePacketInfo {
    enum Type {
        PLAYER = 1,
        ENTITY = 2,
        FAKE_PLAYER = 3
    }
}
export declare class SetScorePacket extends Packet {
    type: uint8_t;
    readonly entries: CxxVector<ScorePacketInfo>;
}
export declare namespace SetScorePacket {
    enum Type {
        CHANGE = 0,
        REMOVE = 1
    }
}
export declare class LabTablePacket extends Packet {
}
export declare class UpdateBlockSyncedPacket extends Packet {
}
/** @deprecated Use UpdateBlockSyncedPacket instead, to match to official class name*/
export declare const UpdateBlockPacketSynced: typeof UpdateBlockSyncedPacket;
/** @deprecated Use UpdateBlockSyncedPacket instead, to match to official class name*/
export type UpdateBlockPacketSynced = UpdateBlockSyncedPacket;
export declare class MoveActorDeltaPacket extends Packet {
}
export declare class SetScoreboardIdentityPacket extends Packet {
}
export declare class SetLocalPlayerAsInitializedPacket extends Packet {
    actorId: ActorRuntimeID;
}
export declare class UpdateSoftEnumPacket extends Packet {
}
export declare class NetworkStackLatencyPacket extends Packet {
}
/** @deprecated removed */
export declare class ScriptCustomEventPacket extends Packet {
}
export declare class SpawnParticleEffectPacket extends Packet {
    dimensionId: uint8_t;
    actorId: ActorUniqueID;
    readonly pos: Vec3;
    particleName: CxxString;
    molangVariablesJson: MolangVariableMap;
}
/** @deprecated use SpawnParticleEffectPacket, follow real class name */
export declare const SpawnParticleEffect: typeof SpawnParticleEffectPacket;
/** @deprecated use SpawnParticleEffectPacket, follow real class name */
export type SpawnParticleEffect = SpawnParticleEffectPacket;
export declare class AvailableActorIdentifiersPacket extends Packet {
}
/** @deprecated Removed packet, use LevelSoundEventPacket instead. */
export declare class LevelSoundEventPacketV2 extends Packet {
}
export declare class NetworkChunkPublisherUpdatePacket extends Packet {
    position: BlockPos;
    /** @warning This field may not be the radius, this is just a guess. */
    radius: uint8_t;
}
export declare class BiomeDefinitionListPacket extends Packet {
    nbt: CompoundTag;
}
/** @deprecated Use BiomeDefinitionListPacket instead, to match to official class name*/
export declare const BiomeDefinitionList: typeof BiomeDefinitionListPacket;
/** @deprecated Use BiomeDefinitionListPacket instead, to match to official class name*/
export type BiomeDefinitionList = BiomeDefinitionListPacket;
export declare class LevelSoundEventPacket extends Packet {
    sound: uint32_t;
    readonly pos: Vec3;
    extraData: int32_t;
    entityType: CxxString;
    isBabyMob: bool_t;
    disableRelativeVolume: bool_t;
}
export declare class LevelEventGenericPacket extends Packet {
}
export declare class LecternUpdatePacket extends Packet {
    page: uint8_t;
    pageCount: uint8_t;
    position: Vec3;
    dropBook: bool_t;
}
export declare class RemoveEntityPacket extends Packet {
}
export declare class ClientCacheStatusPacket extends Packet {
    enabled: bool_t;
}
export declare class OnScreenTextureAnimationPacket extends Packet {
    animationType: int32_t;
}
export declare class MapCreateLockedCopyPacket extends Packet {
    original: uint64_as_float_t;
    new: uint64_as_float_t;
}
/** @deprecated Use MapCreateLockedCopyPacket instead, to match to official class name*/
export declare const MapCreateLockedCopy: typeof MapCreateLockedCopyPacket;
/** @deprecated Use MapCreateLockedCopyPacket instead, to match to official class name*/
export type MapCreateLockedCopy = MapCreateLockedCopyPacket;
export declare class StructureTemplateDataRequestPacket extends Packet {
}
export declare class StructureTemplateDataResponsePacket extends Packet {
}
/** @deprecated Use StructureTemplateDataResponsePacket instead, to match to official class name*/
export declare const StructureTemplateDataExportPacket: typeof StructureTemplateDataResponsePacket;
/** @deprecated Use StructureTemplateDataResponsePacket instead, to match to official class name*/
export type StructureTemplateDataExportPacket = StructureTemplateDataResponsePacket;
export declare class ClientCacheBlobStatusPacket extends Packet {
}
export declare class ClientCacheMissResponsePacket extends Packet {
}
export declare class EducationSettingsPacket extends Packet {
}
export declare class EmotePacket extends Packet {
    runtimeId: ActorRuntimeID;
    emoteId: CxxString;
    flag: EmotePacket.Flags;
}
export declare namespace EmotePacket {
    enum Flags {
        ServerSide = 1,
        MuteChat = 2
    }
}
/** @deprecated Minecraft Education Edition exclusive */
export declare class MultiplayerSettingsPacket extends Packet {
}
export declare class SettingsCommandPacket extends Packet {
}
export declare class AnvilDamagePacket extends Packet {
}
export declare class CompletedUsingItemPacket extends Packet {
    itemId: int16_t;
    action: CompletedUsingItemPacket.Actions;
}
export declare namespace CompletedUsingItemPacket {
    enum Actions {
        EquipArmor = 0,
        Eat = 1,
        Attack = 2,
        Consume = 3,
        Throw = 4,
        Shoot = 5,
        Place = 6,
        FillBottle = 7,
        FillBucket = 8,
        PourBucket = 9,
        UseTool = 10,
        Interact = 11,
        Retrieved = 12,
        Dyed = 13,
        Traded = 14
    }
}
export declare class NetworkSettingsPacket extends Packet {
}
export declare class PlayerAuthInputPacket extends Packet {
    getInput(inputData: PlayerAuthInputPacket.InputData): boolean;
    pitch: float32_t;
    yaw: float32_t;
    readonly pos: Vec3;
    headYaw: float32_t;
    /** @deprecated */
    get heaYaw(): float32_t;
    readonly delta: Vec3;
    /** @deprecated use delta */
    moveX: float32_t;
    /** @deprecated use delta */
    moveY: float32_t;
    /** @deprecated use delta */
    moveZ: float32_t;
    readonly vrGazeDirection: Vec3;
    inputFlags: uint64_as_float_t;
    inputMode: int32_t;
    playMode: uint32_t;
    tick: uint64_as_float_t;
}
export declare namespace PlayerAuthInputPacket {
    enum InputData {
        Ascend = 0,
        Descend = 1,
        NorthJump = 2,
        JumpDown = 3,
        SprintDown = 4,
        ChangeHeight = 5,
        Jumping = 6,
        AutoJumpingInWater = 7,
        Sneaking = 8,
        SneakDown = 9,
        Up = 10,
        Down = 11,
        Left = 12,
        Right = 13,
        UpLeft = 14,
        UpRight = 15,
        WantUp = 16,
        WantDown = 17,
        WantDownSlow = 18,
        WantUpSlow = 19,
        Sprinting = 20,
        AscendScaffolding = 21,
        DescendScaffolding = 22,
        SneakToggleDown = 23,
        PersistSneak = 24,
        StartSprinting = 25,
        StopSprinting = 26,
        StartSneaking = 27,
        StopSneaking = 28,
        StartSwimming = 29,
        StopSwimming = 30,
        StartJumping = 31,
        StartGliding = 32,
        StopGliding = 33,
        PerformItemInteraction = 34,
        PerformBlockActions = 35,
        PerformItemStackRequest = 36,
        HandledTeleport = 37,
        Emoting = 38,
        MissedSwing = 39,
        StartCrawling = 40,
        StopCrawling = 41,
        StartFlying = 42,
        StopFlying = 43,
        AckActorData = 44
    }
}
export declare class CreativeContentPacket extends Packet {
}
export declare class PlayerEnchantOptionsPacket extends Packet {
}
export declare class ItemStackRequestSlotInfo extends NativeStruct {
    openContainerNetId: uint8_t;
    slot: uint8_t;
    readonly netIdVariant: ItemStackNetIdVariant;
}
export declare enum ItemStackRequestActionType {
    Take = 0,
    Place = 1,
    Swap = 2,
    Drop = 3,
    Destroy = 4,
    Consume = 5,
    Create = 6,
    PlaceInItemContainer = 7,
    TakeFromItemContainer = 8,
    ScreenLabTableCombine = 9,
    ScreenBeaconPayment = 10,
    ScreenHUDMineBlock = 11,
    CraftRecipe = 12,
    CraftRecipeAuto = 13,
    CraftCreative = 14,
    CraftRecipeOptional = 15,
    CraftRepairAndDisenchant = 16,
    CraftLoom = 17,
    /** @deprecated Deprecated in BDS */
    CraftNonImplemented_DEPRECATEDASKTYLAING = 18,
    /** @deprecated Deprecated in BDS */
    CraftResults_DEPRECATEDASKTYLAING = 19
}
export declare class ItemStackRequestAction extends AbstractClass {
    vftable: VoidPointer;
    type: ItemStackRequestActionType;
}
export declare class ItemStackRequestActionTransferBase extends ItemStackRequestAction {
    getSrc(): ItemStackRequestSlotInfo;
}
export declare class ItemStackRequestData extends AbstractClass {
    clientRequestId: int32_t;
    get stringsToFilter(): CxxVector<CxxString>;
    /** @deprecated use getActions */
    get actions(): CxxVector<ItemStackRequestAction>;
    getStringsToFilter(): CxxVector<CxxString>;
    getActions(): CxxVector<ItemStackRequestAction>;
    tryFindAction(action: ItemStackRequestActionType): ItemStackRequestAction | null;
}
export declare class ItemStackRequestBatch extends AbstractClass {
    data: CxxVector<ItemStackRequestData>;
}
export declare class ItemStackRequestPacket extends Packet {
    getRequestBatch(): ItemStackRequestBatch;
}
/** @deprecated use ItemStackRequestPacket, follow the real class name */
export declare const ItemStackRequest: typeof ItemStackRequestPacket;
/** @deprecated use ItemStackRequestPacket, follow the real class name */
export type ItemStackRequest = ItemStackRequestPacket;
export declare class ItemStackResponsePacket extends Packet {
}
/** @deprecated use ItemStackResponsePacket, follow the real class name */
export declare const ItemStackResponse: typeof ItemStackResponsePacket;
/** @deprecated use ItemStackResponsePacket, follow the real class name */
export type ItemStackResponse = ItemStackResponsePacket;
export declare class PlayerArmorDamagePacket extends Packet {
}
export declare class CodeBuilderPacket extends Packet {
}
export declare class UpdatePlayerGameTypePacket extends Packet {
    gameType: GameType;
    playerId: ActorUniqueID;
}
export declare class EmoteListPacket extends Packet {
}
export declare class PositionTrackingDBServerBroadcastPacket extends Packet {
    action: PositionTrackingDBServerBroadcastPacket.Actions;
    trackingId: int32_t;
}
export declare namespace PositionTrackingDBServerBroadcastPacket {
    enum Actions {
        Update = 0,
        Destroy = 1,
        NotFound = 2
    }
}
/** @deprecated use PositionTrackingDBServerBroadcastPacket, follow the real class name */
export declare const PositionTrackingDBServerBroadcast: typeof PositionTrackingDBServerBroadcastPacket;
/** @deprecated use PositionTrackingDBServerBroadcastPacket, follow the real class name */
export type PositionTrackingDBServerBroadcast = PositionTrackingDBServerBroadcastPacket;
export declare class PositionTrackingDBClientRequestPacket extends Packet {
    action: PositionTrackingDBClientRequestPacket.Actions;
    trackingId: int32_t;
}
export declare namespace PositionTrackingDBClientRequestPacket {
    enum Actions {
        Query = 0
    }
}
/** @deprecated Use PositionTrackingDBClientRequestPacket, follow the real class name */
export declare const PositionTrackingDBClientRequest: typeof PositionTrackingDBClientRequestPacket;
/** @deprecated Use PositionTrackingDBClientRequestPacket, follow the real class name */
export type PositionTrackingDBClientRequest = PositionTrackingDBClientRequestPacket;
export declare class DebugInfoPacket extends Packet {
}
export declare class PacketViolationWarningPacket extends Packet {
}
export declare class MotionPredictionHintsPacket extends Packet {
}
export declare class AnimateEntityPacket extends Packet {
}
export declare class CameraShakePacket extends Packet {
    intensity: float32_t;
    duration: float32_t;
    shakeType: uint8_t;
    shakeAction: uint8_t;
}
export declare namespace CameraShakePacket {
    enum ShakeType {
        Positional = 0,
        Rotational = 1
    }
    enum ShakeAction {
        Add = 0,
        Stop = 1
    }
}
export declare class PlayerFogPacket extends Packet {
}
export declare class CorrectPlayerMovePredictionPacket extends Packet {
}
export declare class ItemComponentPacket extends Packet {
    entries: CxxVector<CxxPair<CxxString, CompoundTag>>;
}
export declare class FilterTextPacket extends Packet {
}
export declare class ClientboundDebugRendererPacket extends Packet {
}
export declare class SyncActorPropertyPacket extends Packet {
}
export declare class AddVolumeEntityPacket extends Packet {
}
export declare class RemoveVolumeEntityPacket extends Packet {
}
export declare class SimulationTypePacket extends Packet {
}
export declare class NpcDialoguePacket extends Packet {
    /** ActorUniqueID of the Npc */
    actorId: ActorUniqueID;
    action: NpcDialoguePacket.Actions;
    /** Always empty */
    actorIdAsNumber: int64_as_float_t;
}
export declare namespace NpcDialoguePacket {
    enum Actions {
        Open = 0,
        Close = 1
    }
}
/** @deprecated not available */
export declare class BlockPalette extends Packet {
}
/** @deprecated not available */
export declare class VideoStreamConnect_DEPRECATED extends Packet {
}
export declare class AddEntityPacket extends Packet {
}
/** @deprecated Use AddEntityPacket instead, to match to official class name*/
export declare const AddEntity: typeof AddEntityPacket;
/** @deprecated Use AddEntityPacket instead, to match to official class name*/
export type AddEntity = AddEntityPacket;
export declare class EduUriResourcePacket extends Packet {
}
export declare class CreatePhotoPacket extends Packet {
}
export declare class UpdateSubChunkBlocksPacket extends Packet {
}
/** @deprecated use UpdateSubChunkBlocksPacket, follow the real class name */
export declare const UpdateSubChunkBlocks: typeof UpdateSubChunkBlocksPacket;
/** @deprecated use UpdateSubChunkBlocksPacket, follow the real class name */
export type UpdateSubChunkBlocks = UpdateSubChunkBlocksPacket;
export declare class PlayerStartItemCooldownPacket extends Packet {
}
export declare class ScriptMessagePacket extends Packet {
}
export declare class CodeBuilderSourcePacket extends Packet {
}
export declare class TickingAreasLoadStatusPacket extends Packet {
}
export declare class DimensionDataPacket extends Packet {
}
export declare class AgentActionEventPacket extends Packet {
}
export declare class ChangeMobPropertyPacket extends Packet {
}
export declare class LessonProgressPacket extends Packet {
}
export declare class RequestAbilityPacket extends Packet {
}
export declare class RequestPermissionsPacket extends Packet {
}
export declare class ToastRequestPacket extends Packet {
    title: CxxString;
    body: CxxString;
}
export declare class UpdateAbilitiesPacket extends Packet {
}
export declare class UpdateAdventureSettingsPacket extends Packet {
}
export declare class DeathInfoPacket extends Packet {
    /**
     * First: text
     * Second: params for translating
     */
    info: CxxPair<CxxString, CxxVector<CxxString>>;
}
export declare class EditorNetworkPacket extends Packet {
}
export declare class FeatureRegistryPacket extends Packet {
}
export declare class ServerStatsPacket extends Packet {
}
export declare class RequestNetworkSettingsPacket extends Packet {
}
export declare class GameTestRequestPacket extends Packet {
}
export declare class GameTestResultsPacket extends Packet {
}
export declare class UpdateClientInputLocksPacket extends Packet {
}
/** @deprecated removed */
export declare class ClientCheatAbilityPacket extends Packet {
}
export declare class CameraPresetsPacket extends Packet {
}
export declare class UnlockedRecipesPacket extends Packet {
}
export declare class CameraInstructionPacket extends Packet {
}
export declare class CompressedBiomeDefinitionListPacket extends Packet {
}
export declare class TrimDataPacket extends Packet {
}
export declare class OpenSignPacket extends Packet {
}
export declare class AgentAnimationPacket extends Packet {
}
export declare class RefreshEntitlementsPacket extends Packet {
}
export declare class PlayerToggleCrafterSlotRequestPacket extends Packet {
}
export declare class SetPlayerInventoryOptionsPacket extends Packet {
}
export declare const PacketIdToType: {
    1: typeof LoginPacket;
    2: typeof PlayStatusPacket;
    3: typeof ServerToClientHandshakePacket;
    4: typeof ClientToServerHandshakePacket;
    5: typeof DisconnectPacket;
    6: typeof ResourcePacksInfoPacket;
    7: typeof ResourcePackStackPacket;
    8: typeof ResourcePackClientResponsePacket;
    9: typeof TextPacket;
    10: typeof SetTimePacket;
    11: typeof StartGamePacket;
    12: typeof AddPlayerPacket;
    13: typeof AddActorPacket;
    14: typeof RemoveActorPacket;
    15: typeof AddItemActorPacket;
    17: typeof TakeItemActorPacket;
    18: typeof MoveActorAbsolutePacket;
    19: typeof MovePlayerPacket;
    20: typeof PassengerJumpPacket;
    21: typeof UpdateBlockPacket;
    22: typeof AddPaintingPacket;
    23: typeof TickSyncPacket;
    24: typeof LevelSoundEventPacketV1;
    25: typeof LevelEventPacket;
    26: typeof BlockEventPacket;
    27: typeof ActorEventPacket;
    28: typeof MobEffectPacket;
    29: typeof UpdateAttributesPacket;
    30: typeof InventoryTransactionPacket;
    31: typeof MobEquipmentPacket;
    32: typeof MobArmorEquipmentPacket;
    33: typeof InteractPacket;
    34: typeof BlockPickRequestPacket;
    35: typeof ActorPickRequestPacket;
    36: typeof PlayerActionPacket;
    38: typeof HurtArmorPacket;
    39: typeof SetActorDataPacket;
    40: typeof SetActorMotionPacket;
    41: typeof SetActorLinkPacket;
    42: typeof SetHealthPacket;
    43: typeof SetSpawnPositionPacket;
    44: typeof AnimatePacket;
    45: typeof RespawnPacket;
    46: typeof ContainerOpenPacket;
    47: typeof ContainerClosePacket;
    48: typeof PlayerHotbarPacket;
    49: typeof InventoryContentPacket;
    50: typeof InventorySlotPacket;
    51: typeof ContainerSetDataPacket;
    52: typeof CraftingDataPacket;
    53: typeof CraftingEventPacket;
    54: typeof GuiDataPickItemPacket;
    55: typeof AdventureSettingsPacket;
    56: typeof BlockActorDataPacket;
    57: typeof PlayerInputPacket;
    58: typeof LevelChunkPacket;
    59: typeof SetCommandsEnabledPacket;
    60: typeof SetDifficultyPacket;
    61: typeof ChangeDimensionPacket;
    62: typeof SetPlayerGameTypePacket;
    63: typeof PlayerListPacket;
    64: typeof SimpleEventPacket;
    65: typeof LegacyTelemetryEventPacket;
    66: typeof SpawnExperienceOrbPacket;
    67: typeof ClientboundMapItemDataPacket;
    68: typeof MapInfoRequestPacket;
    69: typeof RequestChunkRadiusPacket;
    70: typeof ChunkRadiusUpdatedPacket;
    71: typeof ItemFrameDropItemPacket;
    72: typeof GameRulesChangedPacket;
    73: typeof CameraPacket;
    74: typeof BossEventPacket;
    75: typeof ShowCreditsPacket;
    76: typeof AvailableCommandsPacket;
    77: typeof CommandRequestPacket;
    78: typeof CommandBlockUpdatePacket;
    79: typeof CommandOutputPacket;
    80: typeof UpdateTradePacket;
    81: typeof UpdateEquipPacket;
    82: typeof ResourcePackDataInfoPacket;
    83: typeof ResourcePackChunkDataPacket;
    84: typeof ResourcePackChunkRequestPacket;
    85: typeof TransferPacket;
    86: typeof PlaySoundPacket;
    87: typeof StopSoundPacket;
    88: typeof SetTitlePacket;
    89: typeof AddBehaviorTreePacket;
    90: typeof StructureBlockUpdatePacket;
    91: typeof ShowStoreOfferPacket;
    92: typeof PurchaseReceiptPacket;
    93: typeof PlayerSkinPacket;
    94: typeof SubClientLoginPacket;
    95: typeof AutomationClientConnectPacket;
    96: typeof SetLastHurtByPacket;
    97: typeof BookEditPacket;
    98: typeof NpcRequestPacket;
    99: typeof PhotoTransferPacket;
    100: typeof ModalFormRequestPacket;
    101: typeof ModalFormResponsePacket;
    102: typeof ServerSettingsRequestPacket;
    103: typeof ServerSettingsResponsePacket;
    104: typeof ShowProfilePacket;
    105: typeof SetDefaultGameTypePacket;
    106: typeof RemoveObjectivePacket;
    107: typeof SetDisplayObjectivePacket;
    108: typeof SetScorePacket;
    109: typeof LabTablePacket;
    110: typeof UpdateBlockSyncedPacket;
    111: typeof MoveActorDeltaPacket;
    112: typeof SetScoreboardIdentityPacket;
    113: typeof SetLocalPlayerAsInitializedPacket;
    114: typeof UpdateSoftEnumPacket;
    115: typeof NetworkStackLatencyPacket;
    118: typeof SpawnParticleEffectPacket;
    119: typeof AvailableActorIdentifiersPacket;
    120: typeof LevelSoundEventPacketV2;
    121: typeof NetworkChunkPublisherUpdatePacket;
    122: typeof BiomeDefinitionListPacket;
    123: typeof LevelSoundEventPacket;
    124: typeof LevelEventGenericPacket;
    125: typeof LecternUpdatePacket;
    127: typeof AddEntityPacket;
    128: typeof RemoveEntityPacket;
    129: typeof ClientCacheStatusPacket;
    130: typeof OnScreenTextureAnimationPacket;
    131: typeof MapCreateLockedCopyPacket;
    132: typeof StructureTemplateDataRequestPacket;
    133: typeof StructureTemplateDataResponsePacket;
    135: typeof ClientCacheBlobStatusPacket;
    136: typeof ClientCacheMissResponsePacket;
    137: typeof EducationSettingsPacket;
    138: typeof EmotePacket;
    139: typeof MultiplayerSettingsPacket;
    140: typeof SettingsCommandPacket;
    141: typeof AnvilDamagePacket;
    142: typeof CompletedUsingItemPacket;
    143: typeof NetworkSettingsPacket;
    144: typeof PlayerAuthInputPacket;
    145: typeof CreativeContentPacket;
    146: typeof PlayerEnchantOptionsPacket;
    147: typeof ItemStackRequestPacket;
    148: typeof ItemStackResponsePacket;
    149: typeof PlayerArmorDamagePacket;
    150: typeof CodeBuilderPacket;
    151: typeof UpdatePlayerGameTypePacket;
    152: typeof EmoteListPacket;
    153: typeof PositionTrackingDBServerBroadcastPacket;
    154: typeof PositionTrackingDBClientRequestPacket;
    155: typeof DebugInfoPacket;
    156: typeof PacketViolationWarningPacket;
    157: typeof MotionPredictionHintsPacket;
    158: typeof AnimateEntityPacket;
    159: typeof CameraShakePacket;
    160: typeof PlayerFogPacket;
    161: typeof CorrectPlayerMovePredictionPacket;
    162: typeof ItemComponentPacket;
    163: typeof FilterTextPacket;
    164: typeof ClientboundDebugRendererPacket;
    165: typeof SyncActorPropertyPacket;
    166: typeof AddVolumeEntityPacket;
    167: typeof RemoveVolumeEntityPacket;
    168: typeof SimulationTypePacket;
    169: typeof NpcDialoguePacket;
    170: typeof EduUriResourcePacket;
    171: typeof CreatePhotoPacket;
    172: typeof UpdateSubChunkBlocksPacket;
    176: typeof PlayerStartItemCooldownPacket;
    177: typeof ScriptMessagePacket;
    178: typeof CodeBuilderSourcePacket;
    179: typeof TickingAreasLoadStatusPacket;
    180: typeof DimensionDataPacket;
    181: typeof AgentActionEventPacket;
    182: typeof ChangeMobPropertyPacket;
    183: typeof LessonProgressPacket;
    184: typeof RequestAbilityPacket;
    185: typeof RequestPermissionsPacket;
    186: typeof ToastRequestPacket;
    187: typeof UpdateAbilitiesPacket;
    188: typeof UpdateAdventureSettingsPacket;
    189: typeof DeathInfoPacket;
    190: typeof EditorNetworkPacket;
    191: typeof FeatureRegistryPacket;
    192: typeof ServerStatsPacket;
    193: typeof RequestNetworkSettingsPacket;
    194: typeof GameTestRequestPacket;
    195: typeof GameTestResultsPacket;
    196: typeof UpdateClientInputLocksPacket;
    198: typeof CameraPresetsPacket;
    199: typeof UnlockedRecipesPacket;
    300: typeof CameraInstructionPacket;
    301: typeof CompressedBiomeDefinitionListPacket;
    302: typeof TrimDataPacket;
    303: typeof OpenSignPacket;
    304: typeof AgentAnimationPacket;
    305: typeof RefreshEntitlementsPacket;
    306: typeof PlayerToggleCrafterSlotRequestPacket;
    307: typeof SetPlayerInventoryOptionsPacket;
};
export type PacketIdToType = {
    [key in keyof typeof PacketIdToType]: InstanceType<(typeof PacketIdToType)[key]>;
};
export {};
