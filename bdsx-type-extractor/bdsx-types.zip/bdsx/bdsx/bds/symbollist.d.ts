export declare function loadAllSymbols(): string[];
/** @deprecated use loadAllSymbols() */
export declare const undecoratedPrivateSymbols: string[];
/** @deprecated use loadAllSymbols() */
export declare const undecoratedSymbols: string[];
/** @deprecated use loadAllSymbols() */
export declare const decoratedSymbols: string[];
