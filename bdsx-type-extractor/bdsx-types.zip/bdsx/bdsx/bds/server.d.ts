import { LoopbackPacketSender } from "../bds/loopbacksender";
import { VoidPointer } from "../core";
import { AbstractClass } from "../nativeclass";
import { bool_t, CxxString, uint16_t } from "../nativetype";
import { CxxSharedPtr } from "../sharedpointer";
import type { DimensionId } from "./actor";
import { Bedrock } from "./bedrock";
import type { MinecraftCommands } from "./command";
import { Dimension } from "./dimension";
import { Level, ServerLevel } from "./level";
import { NetworkSystem, NetworkIdentifier, ServerNetworkHandler } from "./networkidentifier";
import type { ServerPlayer } from "./player";
export declare class MinecraftEventing extends AbstractClass {
}
export declare class ResourcePackManager extends AbstractClass {
}
export declare class Whitelist extends AbstractClass {
}
export declare class PrivateKeyManager extends AbstractClass {
}
export declare class ServerMetrics extends AbstractClass {
}
export declare class ServerMetricsImpl extends ServerMetrics {
}
export declare class EntityRegistryOwned extends AbstractClass {
}
export declare class VanillaServerGameplayEventListener extends AbstractClass {
}
/** @deprecated typo, use {@link VanillaServerGameplayEventListener} instead. */
export type VanilaServerGameplayEventListener = VanillaServerGameplayEventListener;
/** @deprecated typo, use {@link VanillaServerGameplayEventListener} instead. */
export declare const VanilaServerGameplayEventListener: typeof VanillaServerGameplayEventListener;
/**
 * @deprecated
 * unknown instance
 */
export declare class Minecraft$Something {
    network: NetworkSystem;
    level: ServerLevel;
    shandler: ServerNetworkHandler;
}
export declare class VanillaGameModuleServer extends AbstractClass {
    listener: VanillaServerGameplayEventListener;
}
/** @deprecated typo, use {@link VanillaGameModuleServer} */
export type VanilaGameModuleServer = VanillaGameModuleServer;
/** @deprecated typo, use {@link VanillaGameModuleServer} */
export declare const VanilaGameModuleServer: typeof VanillaGameModuleServer;
export declare class Minecraft extends AbstractClass {
    vftable: VoidPointer;
    offset_20: VoidPointer;
    vanillaGameModuleServer: CxxSharedPtr<VanillaGameModuleServer>;
    /** @deprecated Use `Minecraft::getCommands` instead */
    get commands(): MinecraftCommands;
    /** @deprecated */
    get something(): Minecraft$Something;
    /** @deprecated Use `Minecraft::getNetworkHandler` instead */
    get network(): NetworkSystem;
    /** @deprecated Unused */
    LoopbackPacketSender: LoopbackPacketSender;
    server: DedicatedServer;
    /**
     * @deprecated use bedrockServer.level
     */
    getLevel(): Level;
    /**
     * @deprecated use bedrockServer.networkSystem
     */
    getNetworkHandler(): NetworkSystem;
    /**
     * @deprecated use bedrockServer.serverNetworkHandler
     */
    getServerNetworkHandler(): ServerNetworkHandler;
    /**
     * @deprecated use bedrockServer.minecraftCommands
     */
    getCommands(): MinecraftCommands;
    /**
     * @deprecated it's a kind of global variable. it will generate a JS instance per access.
     */
    getNonOwnerPointerServerNetworkHandler(): Bedrock.NonOwnerPointer<ServerNetworkHandler>;
}
export declare class DedicatedServer extends AbstractClass {
    vftable: VoidPointer;
}
export declare class ScriptFramework extends AbstractClass {
    vftable: VoidPointer;
}
export declare class SemVersion extends AbstractClass {
    major: uint16_t;
    minor: uint16_t;
    patch: uint16_t;
    preRelease: CxxString;
    buildMeta: CxxString;
    fullVersionString: CxxString;
    validVersion: bool_t;
    anyVersion: bool_t;
}
export declare class BaseGameVersion extends SemVersion {
}
export declare class MinecraftServerScriptEngine extends ScriptFramework {
}
export declare class ServerInstance extends AbstractClass {
    vftable: VoidPointer;
    /** @deprecated use bedrockServer.dedicatedServer */
    server: DedicatedServer;
    /** @deprecated use bedrockServer.minecraft */
    minecraft: Minecraft;
    /** @deprecated use bedrockServer.networkSystem */
    networkSystem: NetworkSystem;
    protected _disconnectAllClients(message: CxxString): void;
    createDimension(id: DimensionId): Dimension;
    /**
     * Returns the number of current online players
     */
    getActivePlayerCount(): number;
    /**
     * Disconnects all clients with the given message
     */
    disconnectAllClients(message?: string): void;
    /**
     * Disconnects a specific client with the given message
     */
    disconnectClient(client: NetworkIdentifier, message?: string, skipMessage?: boolean): void;
    /**
     * Returns the server's message-of-the-day
     */
    getMotd(): string;
    /**
     * Changes the server's message-of-the-day
     */
    setMotd(motd: string): void;
    /**
     * Returns the server's maximum player capacity
     */
    getMaxPlayers(): number;
    /**
     * Changes the server's maximum player capacity
     */
    setMaxPlayers(count: number): void;
    /**
     * Returns an array of all online players
     */
    getPlayers(): ServerPlayer[];
    /**
     * Resends all clients the updated command list
     */
    updateCommandList(): void;
    /**
     * Returns the server's current network protocol version
     */
    getNetworkProtocolVersion(): number;
    /**
     * Returns the server's current game version
     */
    getGameVersion(): SemVersion;
    /**
     * Creates a promise that resolves on the next tick
     */
    nextTick(): Promise<void>;
}
/** @deprecated use bedrockServer.serverInstance */
export declare let serverInstance: ServerInstance;
