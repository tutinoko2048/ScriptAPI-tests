import { VoidPointer } from "../core";
import { AbstractClass } from "../nativeclass";
import { CxxString } from "../nativetype";
import { CxxSharedPtr } from "../sharedpointer";
import { RakNet } from "./raknet";
import { BinaryStream } from "./stream";
export declare class RaknetNetworkPeer extends AbstractClass {
    vftable: VoidPointer;
    u1: VoidPointer;
    u2: VoidPointer;
    peer: RakNet.RakPeer;
    addr: RakNet.AddressOrGUID;
}
export declare class EncryptedNetworkPeer extends AbstractClass {
    peer: CxxSharedPtr<RaknetNetworkPeer>;
}
export declare class CompressedNetworkPeer extends AbstractClass {
    peer: EncryptedNetworkPeer;
}
export declare class BatchedNetworkPeer extends AbstractClass {
    vftable: VoidPointer;
    peer: CompressedNetworkPeer;
    stream: BinaryStream;
    /**
     * @deprecated parameter removed
     */
    sendPacket(data: CxxString, reliability: number, n: number, n2: number, compressibility: number): void;
    /**
     * @deprecated parameter removed
     */
    sendPacket(data: CxxString, reliability: number, n: number, compressibility: number): void;
    sendPacket(data: CxxString, reliability: number, compressibility: number): void;
}
