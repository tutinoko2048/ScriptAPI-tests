import { BlockPos, Vec3 } from "../bds/blockpos";
import { CommandResult } from "../commandresult";
import { VoidPointer } from "../core";
import { mce } from "../mce";
import { AbstractClass } from "../nativeclass";
import { CxxString } from "../nativetype";
import { Actor } from "./actor";
import type { CommandPermissionLevel, CommandPositionFloat } from "./command";
import { Dimension } from "./dimension";
import { Level, ServerLevel } from "./level";
import { CompoundTag } from "./nbt";
export declare enum CommandOriginType {
    Player = 0,
    CommandBlock = 1,
    MinecartCommandBlock = 2,
    DevConsole = 3,
    Test = 4,
    AutomationPlayer = 5,
    ClientAutomation = 6,
    Server = 7,
    Entity = 8,
    Virtual = 9,
    GameArgument = 10,
    EntityServer = 11,
    Precompiled = 12,
    GameMasterEntityServer = 13,
    Scripting = 14
}
export declare class CommandOrigin extends AbstractClass {
    vftable: VoidPointer;
    uuid: mce.UUID;
    level: ServerLevel;
    dispose(): void;
    constructWith(vftable: VoidPointer, level: ServerLevel): void;
    isServerCommandOrigin(): boolean;
    /**
     * @deprecated bedrock scripting API is removed.
     */
    isScriptCommandOrigin(): boolean;
    getRequestId(): CxxString;
    /**
     * @remarks Do not call this the second time, assign it to a variable when calling this
     */
    getName(): string;
    getBlockPosition(): BlockPos;
    getWorldPosition(): Vec3;
    getLevel(): Level;
    getOriginType(): CommandOriginType;
    /**
     * Returns the dimension of the received command
     */
    getDimension(): Dimension;
    /**
     * Returns the entity that send the command
     * @remarks Null if the command origin is the console
     */
    getEntity(): Actor | null;
    /**
     * return the command result
     */
    handleCommandOutputCallback(value: unknown & CommandResult.Any, statusCode?: number, statusMessage?: string): void;
    /**
     * @param tag this function stores nbt values to this parameter
     */
    save(tag: CompoundTag): boolean;
    /**
     * it returns JS converted NBT
     */
    save(): Record<string, any>;
    allocateAndSave(): CompoundTag;
}
export declare class PlayerCommandOrigin extends CommandOrigin {
}
export declare class ActorCommandOrigin extends CommandOrigin {
    static constructWith(actor: Actor): ActorCommandOrigin;
    static allocateWith(actor: Actor): ActorCommandOrigin;
}
export declare class VirtualCommandOrigin extends CommandOrigin {
    static allocateWith(origin: CommandOrigin, actor: Actor, cmdPos: CommandPositionFloat): VirtualCommandOrigin;
    static constructWith(origin: CommandOrigin, actor: Actor, cmdPos: CommandPositionFloat): VirtualCommandOrigin;
}
/**
 * @deprecated bedrock scripting API is removed.
 */
export declare class ScriptCommandOrigin extends PlayerCommandOrigin {
}
export declare class ServerCommandOrigin extends CommandOrigin {
    static constructWith(requestId: string, level: ServerLevel, permissionLevel: CommandPermissionLevel, dimension: Dimension | null): ServerCommandOrigin;
    static allocateWith(requestId: string, level: ServerLevel, permissionLevel: CommandPermissionLevel, dimension: Dimension | null): ServerCommandOrigin;
}
