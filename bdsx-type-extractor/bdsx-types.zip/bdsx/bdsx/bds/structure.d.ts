import { VoidPointer } from "../core";
import { AbstractClass, nativeClassUtil } from "../nativeclass";
import { CxxString, int32_t } from "../nativetype";
import { Block, BlockSource } from "./block";
import { BlockPos, Vec3 } from "./blockpos";
import type { BlockPalette } from "./level";
import { CompoundTag, NBT } from "./nbt";
export declare enum Rotation {
    None = 0,
    Rotate90 = 1,
    Rotate180 = 2,
    Rotate270 = 3,
    Rotate360 = 4
}
export declare enum Mirror {
    None = 0,
    X = 1,
    Z = 2,
    XZ = 3
}
export declare class StructureSettings extends AbstractClass {
    static constructWith(size: BlockPos, ignoreEntities?: boolean, ignoreBlocks?: boolean): StructureSettings;
    getIgnoreJigsawBlocks(): boolean;
    isAnimated(): boolean;
    getPaletteName(): string;
    getReloadActorEquipment(): boolean;
    getAnimationTicks(): number;
    setIgnoreBlocks(ignoreBlocks: boolean): void;
    setIgnoreEntities(ignoreEntities: boolean): void;
    setIgnoreJigsawBlocks(ignoreJigsawBlocks: boolean): void;
    setIntegritySeed(seed: number): void;
    setIntegrityValue(value: number): void;
    setMirror(mirror: Mirror): void;
    setPaletteName(name: string): void;
    setPivot(pivot: Vec3): void;
    setReloadActorEquipment(reloadActorEquipment: boolean): void;
    setRotation(rotation: Rotation): void;
    setStructureOffset(offset: BlockPos): void;
    setStructureSize(size: BlockPos): void;
    [nativeClassUtil.inspectFields](obj: Record<string, any>): void;
}
export declare class StructureTemplateData extends AbstractClass {
    vftable: VoidPointer;
    formatVersion: int32_t;
    readonly size: BlockPos;
    readonly structureWorldOrigin: BlockPos;
    save(): Record<string, any>;
    allocateAndSave(): CompoundTag;
    load(tag: CompoundTag | NBT.Compound): boolean;
}
export declare class StructureTemplate extends AbstractClass {
    vftable: VoidPointer;
    name: CxxString;
    data: StructureTemplateData;
    fillFromWorld(region: BlockSource, pos: BlockPos, settings: StructureSettings): void;
    placeInWorld(region: BlockSource, palette: BlockPalette, pos: BlockPos, settings: StructureSettings): void;
    getBlockAtPos(pos: BlockPos): Block;
    getSize(): BlockPos;
    allocateAndSave(): CompoundTag;
    save(): Record<string, any>;
    load(tag: CompoundTag | NBT.Compound): boolean;
}
export declare class StructureManager extends AbstractClass {
    vftable: VoidPointer;
    getOrCreate(name: string): StructureTemplate;
}
