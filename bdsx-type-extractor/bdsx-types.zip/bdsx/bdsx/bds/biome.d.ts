import { VoidPointer } from "../core";
import { AbstractClass } from "../nativeclass";
import { CxxString } from "../nativetype";
export declare enum VanillaBiomeTypes {
    Beach = 0,
    Desert = 1,
    ExtremeHills = 2,
    Flat = 3,
    Forest = 4,
    Hell = 5,
    Ice = 6,
    Jungle = 7,
    Mesa = 8,
    MushroomIsland = 9,
    Ocean = 10,
    Plain = 11,
    River = 12,
    Savanna = 13,
    StoneBeach = 14,
    Swamp = 15,
    Taiga = 16,
    TheEnd = 17,
    DataDriven = 18
}
export declare class Biome extends AbstractClass {
    vftable: VoidPointer;
    name: CxxString;
    /**
     * Returns the type of the biome (not the name)
     */
    getBiomeType(): VanillaBiomeTypes;
}
