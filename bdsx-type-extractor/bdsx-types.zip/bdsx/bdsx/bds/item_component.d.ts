import { NativeClass } from "../nativeclass";
import { int64_as_float_t } from "../nativetype";
import { Actor } from "./actor";
import { Block, BlockSource } from "./block";
import { Vec3 } from "./blockpos";
import { HashedString } from "./hashedstring";
import type { ItemDescriptor, ItemStack, ItemStackBase } from "./inventory";
import { CompoundTag } from "./nbt";
import type { Player } from "./player";
export declare namespace cereal {
    class ReflectionCtx extends NativeClass {
        u: int64_as_float_t;
    }
}
export declare class ItemComponent extends NativeClass {
    static getIdentifier(): HashedString;
    buildNetworkTag(u?: cereal.ReflectionCtx): CompoundTag;
    initializeFromNetwork(tag: CompoundTag, u?: cereal.ReflectionCtx): void;
    isCooldown(): this is CooldownItemComponent;
    isDurability(): this is DurabilityItemComponent;
    isDigger(): this is DiggerItemComponent;
    isDisplayName(): this is DisplayNameItemComponent;
    isDyePowder(): this is DyePowderItemComponent;
    isEntityPlacer(): this is EntityPlacerItemComponent;
    isFood(): this is FoodItemComponent;
    isFuel(): this is FuelItemComponent;
    isIcon(): this is IconItemComponent;
    isKnockbackResistance(): this is KnockbackResistanceItemComponent;
    isOnUse(): this is OnUseItemComponent;
    isPlanter(): this is PlanterItemComponent;
    isProjectile(): this is ProjectileItemComponent;
    isRecord(): this is RecordItemComponent;
    isRenderOffsets(): this is RenderOffsetsItemComponent;
    isRepairable(): this is RepairableItemComponent;
    isShooter(): this is ShooterItemComponent;
    isThrowable(): this is ThrowableItemComponent;
    isWeapon(): this is WeaponItemComponent;
    isWearable(): this is WearableItemComponent;
    isArmor(): this is ArmorItemComponent;
}
export declare class CooldownItemComponent extends ItemComponent {
}
export declare class ArmorItemComponent extends ItemComponent {
}
export declare class DiggerItemComponent extends ItemComponent {
    mineBlock(itemStack: ItemStack, block: Block, int1: number, int2: number, int3: number, actor: Actor): boolean;
}
export declare class DurabilityItemComponent extends ItemComponent {
    getDamageChance(int: number): number;
}
export declare class DisplayNameItemComponent extends ItemComponent {
}
/**
 * @deprecated removed
 */
export declare class DyePowderItemComponent extends ItemComponent {
}
export declare class EntityPlacerItemComponent extends ItemComponent {
    setActorCustomName(actor: Actor, itemStack: ItemStack): void;
}
export declare class FoodItemComponent extends ItemComponent {
    canAlwaysEat(): boolean;
    getUsingConvertsToItemDescriptor(): ItemDescriptor;
}
export declare class FuelItemComponent extends ItemComponent {
}
export declare class IconItemComponent extends ItemComponent {
}
/**
 * @deprecated removed
 */
export declare class KnockbackResistanceItemComponent extends ItemComponent {
    getProtectionValue(): number;
}
export declare class OnUseItemComponent extends ItemComponent {
}
export declare class PlanterItemComponent extends ItemComponent {
}
export declare class ProjectileItemComponent extends ItemComponent {
    getShootDir(player: Player, float: number): Vec3;
    shootProjectile(blockSource: BlockSource, vec3: Vec3, _vec3: Vec3, float: number, player: Player): Actor;
}
export declare class RecordItemComponent extends ItemComponent {
}
export declare class RenderOffsetsItemComponent extends ItemComponent {
}
/**
 * TODO: implement enum
 */
type RepairItemResult = number;
export declare class RepairableItemComponent extends ItemComponent {
    handleItemRepair(itemStackBase: ItemStackBase, _itemStackBase: ItemStackBase): RepairItemResult;
}
export declare class ShooterItemComponent extends ItemComponent {
}
export declare class ThrowableItemComponent extends ItemComponent {
    getLaunchPower(int1: number, int2: number, int3: number): number;
}
export declare class WeaponItemComponent extends ItemComponent {
}
export declare class WearableItemComponent extends ItemComponent {
}
export {};
