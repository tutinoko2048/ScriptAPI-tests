import { VoidPointer } from "../core";
import { NativeClass } from "../nativeclass";
import { float32_t, int16_t } from "../nativetype";
import type { Actor, ActorUniqueID, DimensionId } from "./actor";
import { BlockSource } from "./block";
import { BlockPos, ChunkPos, Vec3 } from "./blockpos";
import { ChunkSource, LevelChunk } from "./chunk";
import { HashedStringToString } from "./hashedstring";
import type { Player } from "./player";
export declare class Dimension extends NativeClass {
    vftable: VoidPointer;
    /** @deprecated Use `this.getBlockSource()` instead */
    get blockSource(): BlockSource;
    getBlockSource(): BlockSource;
    getChunkSource(): ChunkSource;
    getDimensionId(): DimensionId;
    _sendBlockEntityUpdatePacket(pos: BlockPos): void;
    fetchNearestAttackablePlayer(actor: Actor, distance: number): Player;
    fetchNearestAttackablePlayer(actor: Actor, distance: number, blockPos: BlockPos): Player;
    getSunAngle(): number;
    getTimeOfDay(): number;
    isDay(): boolean;
    distanceToNearestPlayerSqr2D(pos: Vec3): number;
    transferEntityToUnloadedChunk(actor: Actor, levelChunk?: LevelChunk): void;
    getSpawnPos(): BlockPos;
    getPlayers(): Player[];
    fetchNearestPlayerToActor(actor: Actor, distance: number): Player | null;
    fetchNearestPlayerToPosition(x: number, y: number, z: number, distance: number, findAnyNearPlayer: boolean): Player | null;
    getMoonBrightness(): float32_t;
    getHeight(): int16_t;
    getMinHeight(): int16_t;
    tryGetClosestPublicRegion(chunkPos: ChunkPos): BlockSource;
    removeActorByID(actorUniqueId: ActorUniqueID): void;
    getDefaultBiomeString(): HashedStringToString;
    /**
     * @deprecated use getDefaultBiomeString
     */
    getDefaultBiome(): number;
    getMoonPhase(): number;
}
