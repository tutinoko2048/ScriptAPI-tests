import { AbstractClass, NativeClass, NativeStruct } from "../nativeclass";
import { bool_t, float32_t } from "../nativetype";
import type { CommandPermissionLevel } from "./command";
import type { PlayerPermission } from "./player";
export declare class Abilities extends AbstractClass {
    getAbility(abilityIndex: AbilitiesIndex): Ability;
    setAbility(abilityIndex: AbilitiesIndex, value: boolean | number): void;
    isFlying(): boolean;
    getFloat(abilityIndex: AbilitiesIndex): number;
    getBool(abilityIndex: AbilitiesIndex): boolean;
    static getAbilityName(abilityIndex: AbilitiesIndex): string;
    static nameToAbilityIndex(name: string): AbilitiesIndex;
}
export declare enum AbilitiesLayer {
}
export declare class LayeredAbilities extends AbstractClass {
    getLayer(layer: AbilitiesLayer): Abilities;
    protected _setAbility(abilityIndex: AbilitiesIndex, value: boolean): void;
    /**
     * Returns the command permission level of the ability owner
     */
    getCommandPermissions(): CommandPermissionLevel;
    /**
     * Returns the player permission level of the ability owner
     */
    getPlayerPermissions(): PlayerPermission;
    /**
     * Changes the command permission level of the ability owner
     */
    setCommandPermissions(commandPermissionLevel: CommandPermissionLevel): void;
    /**
     * Changes the player permission level of the ability owner
     */
    setPlayerPermissions(playerPermissionLevel: PlayerPermission): void;
    /**
     * Returns the command permission level of the ability owner
     * @deprecated use getCommandPermissions, use the native function name
     */
    getCommandPermissionLevel(): CommandPermissionLevel;
    /**
     * Returns the player permission level of the ability owner
     * @deprecated use getPlayerPermissions, use the native function name
     */
    getPlayerPermissionLevel(): PlayerPermission;
    /**
     * Changes the command permission level of the ability owner
     * @deprecated use setCommandPermissions, use the native function name
     */
    setCommandPermissionLevel(commandPermissionLevel: CommandPermissionLevel): void;
    /**
     * Changes the player permission level of the ability owner
     * @deprecated use setPlayerPermissions, use the native function name
     */
    setPlayerPermissionLevel(playerPermissionLevel: PlayerPermission): void;
    getAbility(abilityIndex: AbilitiesIndex): Ability;
    getAbility(abilityLayer: AbilitiesLayer, abilityIndex: AbilitiesIndex): Ability;
    setAbility(abilityIndex: AbilitiesIndex, value: boolean | number): void;
    isFlying(): boolean;
    getFloat(abilityIndex: AbilitiesIndex): number;
    getBool(abilityIndex: AbilitiesIndex): boolean;
}
export declare enum AbilitiesIndex {
    Build = 0,
    Mine = 1,
    DoorsAndSwitches = 2,
    OpenContainers = 3,
    AttackPlayers = 4,
    AttackMobs = 5,
    OperatorCommands = 6,
    Teleport = 7,
    /** Both are 8 */
    ExposedAbilityCount = 8,
    Invulnerable = 8,
    Flying = 9,
    MayFly = 10,
    Instabuild = 11,
    Lightning = 12,
    FlySpeed = 13,
    WalkSpeed = 14,
    Muted = 15,
    WorldBuilder = 16,
    NoClip = 17,
    AbilityCount = 19
}
export declare class Ability extends NativeClass {
    type: Ability.Type;
    value: Ability.Value;
    options: Ability.Options;
    getBool(): boolean;
    getFloat(): number;
    setBool(value: boolean): void;
    setFloat(value: number): void;
    getValue(): boolean | number | undefined;
    setValue(value: boolean | number): void;
    static readonly INVALID_ABILITY: Ability;
}
export declare namespace Ability {
    enum Type {
        Invalid = 0,
        Unset = 1,
        Bool = 2,
        Float = 3
    }
    enum Options {
        None = 0,
        NoSave = 1,
        CommandExposed = 2,
        PermissionsInterfaceExposed = 4,
        WorldbuilderOverrides = 8,
        NoSaveCommandExposed = 3,
        NoSavePermissionsInterfaceExposed = 5,
        CommandExposedPermissionsInterfaceExposed = 6,
        NoSaveCommandExposedPermissionsInterfaceExposed = 7,
        NoSaveWorldbuilderOverrides = 9,
        CommandExposedWorldbuilderOverrides = 10,
        NoSaveCommandExposedWorldbuilderOverrides = 11,
        PermissionsInterfaceExposedWorldbuilderOverrides = 12,
        NoSavePermissionsInterfaceExposedWorldbuilderOverrides = 13,
        CommandExposedPermissionsInterfaceExposedWorldbuilderOverrides = 14,
        All = 15
    }
    class Value extends NativeStruct {
        boolVal: bool_t;
        floatVal: float32_t;
    }
}
