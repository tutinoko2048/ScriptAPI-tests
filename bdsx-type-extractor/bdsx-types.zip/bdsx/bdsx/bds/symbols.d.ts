import { NativePointer } from "../core";
declare namespace procNamespace {
    const vftable: {
        readonly [key: string]: [number, number?];
    };
}
/**
 * @remark Backward compatibility cannot be guaranteed. The symbol name can be changed by BDS updating.
 */
export declare const proc: {
    readonly [key: string]: NativePointer;
} & typeof procNamespace;
/** @deprecated use proc */
export declare const proc2: {
    readonly [key: string]: NativePointer;
} & typeof procNamespace;
export {};
