import type * as commandenum from "../commandenum";
import { CommandParameterType } from "../commandparam";
import * as commandparser from "../commandparser";
import { StaticPointer, VoidPointer } from "../core";
import { CxxMap } from "../cxxmap";
import { CxxPair } from "../cxxpair";
import { CxxVector } from "../cxxvector";
import { AbstractClass, KeysFilter, NativeClass, NativeClassType, NativeStruct } from "../nativeclass";
import { CommandParameterNativeType, CxxString, NativeType, Type, bin64_t, bool_t, float32_t, int16_t, int32_t, uint32_t, uint64_as_float_t, uint8_t } from "../nativetype";
import { CxxSharedPtr } from "../sharedpointer";
import { Actor, ActorDefinitionIdentifier } from "./actor";
import { Block } from "./block";
import { BlockPos, Vec3 } from "./blockpos";
import { CommandSymbols } from "./cmdsymbolloader";
import { CommandName } from "./commandname";
import { CommandOrigin } from "./commandorigin";
import { JsonValue } from "./connreq";
import { MobEffect } from "./effects";
import { HashedString } from "./hashedstring";
import { ItemStack } from "./inventory";
import { InvertableFilter } from "./invertablefilter";
import { AvailableCommandsPacket } from "./packets";
import { HasTypeId, typeid_t } from "./typeid";
export declare enum CommandPermissionLevel {
    Normal = 0,
    Operator = 1,
    Host = 2,
    Automation = 3,
    Admin = 4,
    Internal = 5
}
export declare enum CommandCheatFlag {
    Cheat = 0,
    NotCheat = 64,
    /** @deprecated */
    NoCheat = 64,
    None = 0
}
export declare enum CommandExecuteFlag {
    Allowed = 0,
    Disallowed = 16
}
export declare enum CommandSyncFlag {
    Synced = 0,
    Local = 8
}
export declare enum CommandTypeFlag {
    None = 0,
    Message = 32
}
export declare enum CommandUsageFlag {
    Normal = 0,
    Test = 1,
    /** @deprecated Use `CommandVisibilityFlag` */
    Hidden = 2,
    _Unknown = 128
}
/** Putting in flag1 or flag2 are both ok, you can also combine with other flags like CommandCheatFlag.NoCheat | CommandVisibilityFlag.HiddenFromCommandBlockOrigin but combining is actually not quite useful */
export declare enum CommandVisibilityFlag {
    Visible = 0,
    /** Bug: Besides from being hidden from command blocks, players cannot see it also well, but they are still able to execute */
    HiddenFromCommandBlockOrigin = 2,
    HiddenFromPlayerOrigin = 4,
    /** Still visible to console */
    Hidden = 6
}
/** @deprecated **/
export declare const CommandFlag: typeof CommandCheatFlag;
export declare enum SoftEnumUpdateType {
    Add = 0,
    Remove = 1,
    Replace = 2
}
export declare class MCRESULT extends NativeStruct {
    result: uint32_t;
    getFullCode(): number;
    isSuccess(): boolean;
}
export declare class CommandPosition extends NativeStruct {
    static readonly [CommandParameterType.symbol]: true;
    x: float32_t;
    y: float32_t;
    z: float32_t;
    isXRelative: bool_t;
    isYRelative: bool_t;
    isZRelative: bool_t;
    local: bool_t;
    static create(x: number, isXRelative: boolean, y: number, isYRelative: boolean, z: number, isZRelative: boolean, local: boolean): CommandPosition;
    protected _getPosition(unknown: number, origin: CommandOrigin, offsetFromBase: Vec3): Vec3;
    getPosition(origin: CommandOrigin, offsetFromBase?: Vec3): Vec3;
    protected _getBlockPosition(unknown: number, origin: CommandOrigin, offsetFromBase: Vec3): BlockPos;
    getBlockPosition(origin: CommandOrigin, offsetFromBase?: Vec3): BlockPos;
}
export declare class CommandPositionFloat extends CommandPosition {
    static readonly [CommandParameterType.symbol]: true;
    static create(x: number, isXRelative: boolean, y: number, isYRelative: boolean, z: number, isZRelative: boolean, local: boolean): CommandPositionFloat;
}
export declare enum CommandSelectionOrder {
    Sorted = 0,
    InvertSorted = 1,
    Random = 2
}
export declare enum CommandSelectionType {
    /** Used in @s */
    Self = 0,
    /** Used in @e */
    Entities = 1,
    /** Used in @a */
    Players = 2,
    /** Used in @r */
    DefaultPlayers = 3,
    /** Used in @c */
    OwnedAgent = 4,
    /** Used in @v */
    Agents = 5
}
export declare class CommandSelectorBase<TARGET extends Actor = Actor> extends AbstractClass {
    version: number;
    type: CommandSelectionType;
    order: CommandSelectionOrder;
    nameFilters: CxxVector<CommandName>;
    typeFilters: CxxVector<InvertableFilter<ActorDefinitionIdentifier>>;
    familyFilters: CxxVector<InvertableFilter<HashedString>>;
    tagFilters: CxxVector<CommandName>;
    /** std::vector<std::function<bool (const CommandOrigin &,const Actor &)>> */
    /** component size is 0x40 */
    position: CommandPosition;
    boxDeltas: Vec3;
    radiusMinSquared: number;
    radiusMaxSquared: number;
    count: number;
    includeDeadPlayers: boolean;
    isPositionBound: boolean;
    distanceFiltered: boolean;
    positionFiltered: boolean;
    countFiltered: boolean;
    haveDeltas: boolean;
    forcePlayer: boolean;
    excludeAgents: boolean;
    isExplicitIdSelector: boolean;
    private _newResults;
    newResults<T extends TARGET>(origin: CommandOrigin, typeFilter?: new (...args: any[]) => T): T[];
    getName(): string;
    hasName(): boolean;
    addTypeFilter(filter: CommandName): void;
    filter(origin: CommandOrigin, entity: Actor): boolean;
    getExplicitPlayerName(): string;
    setBox(deltas: BlockPos): void;
    setIncludeDeadPlayers(includeDead: boolean): void;
    setOrder(order: CommandSelectionOrder): void;
    setPosition(position: CommandPosition): void;
    setRadiusMin(rm: number): void;
    setRadiusMax(r: number): void;
    setResultCount(count: number): void;
    setType(type: CommandSelectionType): void;
}
export declare class WildcardCommandSelector<TARGET extends Actor> extends CommandSelectorBase<TARGET> {
    static make<T extends Actor>(type: Type<T>): NativeClassType<WildcardCommandSelector<T>>;
}
interface WildcardCommandSelectorType<T extends Actor> extends NativeClassType<WildcardCommandSelector<T>> {
    [CommandParameterType.symbol]: true;
}
export declare const ActorWildcardCommandSelector: WildcardCommandSelectorType<Actor>;
export declare const PlayerWildcardCommandSelector: WildcardCommandSelectorType<import("./player").Player>;
export declare class CommandSelector<TARGET extends Actor> extends CommandSelectorBase<TARGET> {
    static make<T extends Actor>(type: Type<T>): NativeClassType<CommandSelector<T>>;
}
interface CommandSelectorType<T extends Actor> extends NativeClassType<CommandSelector<T>> {
    [CommandParameterType.symbol]: true;
}
export declare const ActorCommandSelector: CommandSelectorType<Actor>;
export declare const PlayerCommandSelector: CommandSelectorType<import("./player").Player>;
export declare class CommandFilePath extends NativeClass {
    static readonly [CommandParameterType.symbol]: true;
    text: CxxString;
}
export declare class CommandIntegerRange extends NativeClass {
    static readonly [CommandParameterType.symbol]: true;
    min: int32_t;
    max: int32_t;
    inverted: bool_t;
    isWithinRange(value: number): boolean;
}
export declare class CommandItem extends NativeStruct {
    static readonly [CommandParameterType.symbol]: true;
    version: int32_t;
    id: int32_t;
    createInstance(count: number): ItemStack;
}
export declare class CommandMessage extends NativeClass {
    static readonly [CommandParameterType.symbol]: true;
    data: CxxVector<CommandMessage.MessageComponent>;
    getMessage(origin: CommandOrigin): string;
}
export declare namespace CommandMessage {
    class MessageComponent extends NativeClass {
        string: CxxString;
        selection: WildcardCommandSelector<Actor>;
    }
}
export declare class CommandRawText extends NativeClass {
    static readonly [CommandParameterType.symbol]: true;
    text: CxxString;
}
export declare class CommandWildcardInt extends NativeStruct {
    static readonly [CommandParameterType.symbol]: true;
    isWildcard: bool_t;
    value: int32_t;
}
export declare class CommandContext extends NativeClass {
    command: CxxString;
    origin: CommandOrigin;
    version: int32_t;
    /**
     * @param commandOrigin it's destructed by the destruction of CommandContext
     */
    constructWith(command: string, commandOrigin: CommandOrigin, version?: number): void;
    /**
     * @param commandOrigin it's destructed by the destruction of CommandContext
     */
    static constructWith(command: string, commandOrigin: CommandOrigin, version?: number): CommandContext;
    /**
     * @deprecated
     * @param commandOrigin it's destructed by the destruction of CommandContext. it should be allocated by malloc
     */
    static constructSharedPtr(command: string, commandOrigin: CommandOrigin, version?: number): CxxSharedPtr<CommandContext>;
}
export declare namespace CommandVersion {
    const CurrentVersion: number;
}
export declare enum CommandOutputType {
    None = 0,
    LastOutput = 1,
    Silent = 2,
    /** @deprecated */
    Type3 = 3,
    AllOutput = 3,// user / server console / command block
    /** @deprecated */
    ScriptEngine = 4,
    DataSet = 4
}
type CommandOutputParameterType = string | boolean | number | Actor | BlockPos | Vec3 | Actor[];
export declare class CommandOutputParameter extends NativeClass {
    string: CxxString;
    count: int32_t;
    /**
     * @deprecated use constructWith to be sure. it has to be destructed.
     */
    static create(input: CommandOutputParameterType, count?: number): CommandOutputParameter;
    constructWith(input: CommandOutputParameterType, count?: number): void;
    static constructWith(input: CommandOutputParameterType, count?: number): CommandOutputParameter;
}
declare class CommandPropertyBag extends AbstractClass {
    json: JsonValue;
}
export declare class CommandOutput extends NativeClass {
    type: CommandOutputType;
    propertyBag: CommandPropertyBag;
    getSuccessCount(): number;
    getType(): CommandOutputType;
    /**
     * @deprecated use constructWith, Uniform naming conventions
     */
    constructAs(type: CommandOutputType): void;
    constructWith(type: CommandOutputType): void;
    empty(): boolean;
    /**
     * CommandOutput::set<std::string>()
     */
    set_string(key: string, value: string): void;
    /**
     * CommandOutput::set<int>()
     */
    set_int(key: string, value: number): void;
    /**
     * CommandOutput::set<int>()
     */
    set_bool(key: string, value: boolean): void;
    /**
     * CommandOutput::set<float>()
     */
    set_float(key: string, value: number): void;
    /**
     * CommandOutput::set<BlockPos>()
     */
    set_BlockPos(key: string, value: BlockPos): void;
    /**
     * CommandOutput::set<Vec3>()
     */
    set_Vec3(key: string, value: Vec3): void;
    set(key: string, value: string | number | boolean | BlockPos | Vec3): void;
    protected _successNoMessage(): void;
    protected _success(message: string, params: CxxVector<CommandOutputParameter>): void;
    /**
     * @param params CAUTION! it will destruct the parameters.
     */
    success(message?: string, params?: CommandOutputParameterType[] | CommandOutputParameter[] | CxxVector<CommandOutputParameter>): void;
    protected _error(message: string, params: CxxVector<CommandOutputParameter>): void;
    /**
     * @param params CAUTION! it will destruct the parameters.
     */
    error(message: string, params?: CommandOutputParameterType[] | CommandOutputParameter[] | CxxVector<CommandOutputParameter>): void;
    protected _addMessage(message: string, params: CxxVector<CommandOutputParameter>): void;
    /**
     * @param params CAUTION! it will destruct the parameters.
     */
    addMessage(message: string, params?: CommandOutputParameterType[] | CommandOutputParameter[]): void;
    static constructWith(type: CommandOutputType): CommandOutput;
}
export declare class CommandOutputSender extends NativeClass {
    vftable: VoidPointer;
    _toJson(commandOutput: CommandOutput): JsonValue;
    sendToAdmins(origin: CommandOrigin, output: CommandOutput, permission: CommandPermissionLevel): void;
}
export declare class MinecraftCommands extends NativeClass {
    vftable: VoidPointer;
    /**
     * @deprecated use bedrockServer.commandOutputSender
     */
    sender: CommandOutputSender;
    handleOutput(origin: CommandOrigin, output: CommandOutput): void;
    /**
     * @param ctx it's destructed by this function
     * @deprecated old method
     */
    executeCommand(ctx: CxxSharedPtr<CommandContext>, suppressOutput: boolean): MCRESULT;
    executeCommand(ctx: CommandContext, suppressOutput: boolean): MCRESULT;
    /**
     * @deprecated use bedrockServer.commandRegistry
     */
    getRegistry(): CommandRegistry;
    static getOutputType(origin: CommandOrigin): CommandOutputType;
}
export declare enum CommandParameterDataType {
    NORMAL = 0,
    ENUM = 1,
    SOFT_ENUM = 2,
    POSTFIX = 3
}
export declare enum CommandParameterOption {
    None = 0,
    EnumAutocompleteExpansion = 1,
    HasSemanticConstraint = 2
}
export declare class CommandParameterData extends NativeClass {
    tid: typeid_t<CommandRegistry>;
    parser: VoidPointer | null;
    name: CxxString;
    /** @deprecated Use {@link enumNameOrPostfix} instead */
    desc: VoidPointer | null;
    enumNameOrPostfix: VoidPointer | null;
    /** @deprecated Use {@link enumOrPostfixSymbol} instead */
    unk56: int32_t;
    enumOrPostfixSymbol: int32_t;
    unk40_string: VoidPointer | null;
    unk48_offset: int32_t;
    type: CommandParameterDataType;
    offset: int32_t;
    flag_offset: int32_t;
    optional: bool_t;
    /** @deprecated Use {@link options} instead */
    pad73: bool_t;
    options: CommandParameterOption;
}
export declare class CommandVFTable extends NativeStruct {
    destructor: VoidPointer;
    collectOptionalArguments: VoidPointer;
    execute: VoidPointer | null;
}
export declare class CommandRegistry extends HasTypeId {
    enumValues: CxxVector<CxxString>;
    enums: CxxVector<CommandRegistry.Enum>;
    enumLookup: CxxMap<CxxString, uint32_t>;
    enumValueLookup: CxxMap<CxxString, uint64_as_float_t>;
    signatures: CxxMap<CxxString, CommandRegistry.Signature>;
    softEnums: CxxVector<CommandRegistry.SoftEnum>;
    softEnumLookup: CxxMap<CxxString, uint32_t>;
    registerCommand(command: string, description: string, level: CommandPermissionLevel, flag1: CommandCheatFlag | CommandVisibilityFlag, flag2: CommandUsageFlag | CommandVisibilityFlag): void;
    registerAlias(command: string, alias: string): void;
    /**
     * this method will destruct all parameters in params
     */
    registerOverload(name: string, commandClass: {
        new (): Command;
    }, params: CommandParameterData[]): void;
    registerOverloadInternal(signature: CommandRegistry.Signature, overload: CommandRegistry.Overload): void;
    getCommandName(command: string): string;
    findCommand(command: string): CommandRegistry.Signature | null;
    protected _serializeAvailableCommands(pk: AvailableCommandsPacket): AvailableCommandsPacket;
    serializeAvailableCommands(): AvailableCommandsPacket;
    /**
     * @deprecated use commandParser.get
     */
    static getParser<T>(type: Type<T>): VoidPointer;
    /**
     * @deprecated use commandParser.has
     */
    static hasParser<T>(type: Type<T>): boolean;
    /**
     * @deprecated use commandParser.load
     */
    static loadParser(symbols: CommandSymbols): void;
    /**
     * @deprecated use commandParser.set
     */
    static setParser(type: Type<any>, parserFnPointer: VoidPointer): void;
    /**
     * @deprecated no need to use
     */
    static setEnumParser(parserFnPointer: VoidPointer): void;
    hasEnum(name: string): boolean;
    getEnum(name: string): CommandRegistry.Enum | null;
    addEnumValues(name: string, values: string[]): number;
    getEnumValues(name: string): string[] | null;
    hasSoftEnum(name: string): boolean;
    getSoftEnum(name: string): CommandRegistry.SoftEnum | null;
    addSoftEnum(name: string, values: string[]): number;
    getSoftEnumValues(name: string): string[] | null;
    updateSoftEnum(type: SoftEnumUpdateType, name: string, values: string[]): void;
}
export declare namespace CommandRegistry {
    class Symbol extends NativeStruct {
        value: int32_t;
    }
    class Overload extends NativeClass {
        commandVersion: bin64_t;
        allocator: VoidPointer;
        parameters: CxxVector<CommandParameterData>;
        commandVersionOffset: int32_t;
        /** @deprecated */
        u6: int32_t;
        u7: uint8_t;
        symbols: CxxVector<CommandRegistry.Symbol>;
    }
    class Signature extends NativeClass {
        command: CxxString;
        description: CxxString;
        overloads: CxxVector<Overload>;
        permissionLevel: CommandPermissionLevel;
        commandSymbol: CommandRegistry.Symbol;
        commandAliasEnum: CommandRegistry.Symbol;
        flags: CommandCheatFlag | CommandExecuteFlag | CommandSyncFlag | CommandTypeFlag | CommandUsageFlag | CommandVisibilityFlag;
    }
    class ParseToken extends NativeClass {
        text: StaticPointer;
        length: uint32_t;
        type: CommandRegistry.Symbol;
        getText(): string;
    }
    class Enum extends NativeClass {
        name: CxxString;
        tid: typeid_t<CommandRegistry>;
        parser: VoidPointer;
        values: CxxVector<CxxPair<uint64_as_float_t, bin64_t>>;
    }
    class SoftEnum extends NativeClass {
        name: CxxString;
        list: CxxVector<CxxString>;
    }
    class Parser extends AbstractClass {
        constructWith(registry: CommandRegistry, version: number): void;
        parseCommand(command: string): boolean;
        createCommand(origin: CommandOrigin): Command | null;
        getErrorMessage(): string;
        getErrorParams(): string[];
        static constructWith(registry: CommandRegistry, version: number): Parser;
    }
}
export declare class Command extends NativeClass {
    vftable: CommandVFTable;
    /** @deprecated */
    u1: int32_t;
    version: int32_t;
    /** @deprecated */
    u2: VoidPointer | null;
    registry: CommandRegistry | null;
    /** @deprecated */
    u3: int32_t;
    commandSymbol: int32_t;
    /** @deprecated */
    u4: int16_t;
    permissionLevel: uint8_t;
    flags: int16_t;
    [NativeType.ctor](): void;
    [NativeType.dtor](): void;
    run(origin: CommandOrigin, output: CommandOutput): void;
    static mandatory<CMD extends Command, KEY extends keyof CMD, KEY_ISSET extends KeysFilter<CMD, bool_t> | null>(this: {
        new (): CMD;
    }, key: KEY, keyForIsSet: KEY_ISSET, enumNameOrPostfix?: string | null, type?: CommandParameterDataType, name?: string, options?: CommandParameterOption): CommandParameterData;
    static optional<CMD extends Command, KEY extends keyof CMD, KEY_ISSET extends KeysFilter<CMD, bool_t> | null>(this: {
        new (): CMD;
    }, key: KEY, keyForIsSet: KEY_ISSET, enumNameOrPostfix?: string | null, type?: CommandParameterDataType, name?: string, options?: CommandParameterOption): CommandParameterData;
    static manual(name: string, paramType: Type<any>, offset: number, flag_offset?: number, optional?: boolean, enumNameOrPostfix?: string | null, type?: CommandParameterDataType, options?: CommandParameterOption): CommandParameterData;
    static isWildcard<T extends Actor>(selectorBase: CommandSelectorBase<T>): boolean;
}
/** @deprecated import it from bdsx/command */
export declare const CommandMappedValue: typeof commandparser.CommandMappedValue;
/** @deprecated import it from bdsx/command */
export type CommandMappedValue<BaseType, NewType = BaseType> = commandparser.CommandMappedValue<BaseType, NewType>;
/** @deprecated import it from bdsx/command */
export declare const CommandEnum: typeof commandenum.CommandEnum;
/** @deprecated import it from bdsx/command */
export type CommandEnum<V> = commandenum.CommandEnum<V>;
/** @deprecated import it from bdsx/command */
export declare const CommandRawEnum: typeof commandenum.CommandRawEnum;
/** @deprecated import it from bdsx/command */
export type CommandRawEnum = commandenum.CommandRawEnum;
/** @deprecated import it from bdsx/command */
export declare const CommandStringEnum: typeof commandenum.CommandStringEnum;
/** @deprecated import it from bdsx/command */
export type CommandStringEnum<T extends string[]> = commandenum.CommandStringEnum<T>;
/** @deprecated import it from bdsx/command */
export declare const CommandIndexEnum: typeof commandenum.CommandIndexEnum;
/** @deprecated import it from bdsx/command */
export type CommandIndexEnum<T extends number | string> = commandenum.CommandIndexEnum<T>;
/** @deprecated import it from bdsx/command */
export declare const CommandSoftEnum: typeof commandenum.CommandSoftEnum;
/** @deprecated import it from bdsx/command */
export type CommandSoftEnum = commandenum.CommandSoftEnum;
declare class CommandBlockEnum extends CommandEnum<Block> {
    constructor();
    mapValue(value: commandenum.EnumResult): Block;
}
export declare namespace Command {
    const VFTable: typeof CommandVFTable;
    type VFTable = CommandVFTable;
    const Block: CommandBlockEnum;
    const MobEffect: CommandParameterNativeType<MobEffect>;
    const ActorDefinitionIdentifier: CommandParameterNativeType<ActorDefinitionIdentifier>;
}
/** @deprecated use Command.Block */
export declare const CommandBlock: CommandBlockEnum;
/** @deprecated use Command.MobEffect */
export declare const CommandMobEffect: CommandParameterNativeType<MobEffect>;
export {};
