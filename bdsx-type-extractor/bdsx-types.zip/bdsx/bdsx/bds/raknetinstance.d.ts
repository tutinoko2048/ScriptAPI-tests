import { VoidPointer } from "../core";
import { AbstractClass } from "../nativeclass";
import { RakNet } from "./raknet";
export declare class RakNetConnector extends AbstractClass {
    vftable: VoidPointer;
    /**
     * @deprecated use bedrockServer.rakPeer
     */
    peer: RakNet.RakPeer;
    getPort(): number;
}
/** @alias RakNetConnector */
export declare const RakNetInstance: typeof RakNetConnector;
/** @alias RakNetConnector */
export type RakNetInstance = RakNetConnector;
