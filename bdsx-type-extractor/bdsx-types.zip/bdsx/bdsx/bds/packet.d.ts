import { AbstractMantleClass } from "../nativeclass";
import { CxxString, int32_t, uint32_t } from "../nativetype";
import { CxxSharedPtr } from "../sharedpointer";
import { Bedrock } from "./bedrock";
import { NetworkIdentifier } from "./networkidentifier";
import { MinecraftPacketIds } from "./packetids";
import { BinaryStream } from "./stream";
export declare const PacketReadResult: import("../nativetype").NativeType<number> & {
    PacketReadNoError: number;
    PacketReadError: number;
};
export type PacketReadResult = uint32_t;
export declare const StreamReadResult: import("../nativetype").NativeType<number> & {
    Disconnect: number;
    Pass: number;
    Warning: number;
};
export type StreamReadResult = int32_t;
declare const sharedptr_of_packet: unique symbol;
export declare class Packet extends AbstractMantleClass {
    static ID: number;
    [sharedptr_of_packet]?: CxxSharedPtr<any> | null;
    getId(): MinecraftPacketIds;
    getName(): CxxString;
    write(stream: BinaryStream): void;
    read(stream: BinaryStream): Bedrock.VoidErrorCodeResult;
    /**
     * same with target.send
     */
    sendTo(target: NetworkIdentifier, senderSubClientId?: number): void;
    dispose(): void;
    /**
     * @deprecated unintuitive, the returning value need to be `dispose()`
     */
    static create<T extends Packet>(this: {
        new (alloc?: boolean): T;
        ID: number;
        ref(): any;
    }): T;
    /**
     * @return the returning value need to be `dispose()`
     */
    static allocate<T>(this: new () => T, copyFrom?: T | null): T;
}
export declare const PacketSharedPtr: import("../nativeclass").NativeClassType<CxxSharedPtr<Packet>>;
export type PacketSharedPtr = CxxSharedPtr<Packet>;
export declare const createPacketRaw: import("../makefunc").FunctionFromTypes_js<import("../core").NativePointer, null, [import("../nativeclass").NativeClassType<CxxSharedPtr<Packet>>, import("../nativetype").CommandParameterNativeType<number>], import("../nativeclass").NativeClassType<CxxSharedPtr<Packet>>>;
export {};
