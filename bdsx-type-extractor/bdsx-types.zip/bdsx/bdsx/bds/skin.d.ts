import { CxxVector } from "../cxxvector";
import { mce } from "../mce";
import { NativeClass } from "../nativeclass";
import { bool_t, CxxString, float32_t, int32_t, uint32_t } from "../nativetype";
import { JsonValue } from "./connreq";
import { SemVersion } from "./server";
export declare enum TrustedSkinFlag {
    Unset = 0,
    False = 1,
    True = 2
}
export declare enum PersonaAnimatedTextureType {
    None = 0,
    Face = 1,
    Body32x32 = 2,
    Body128x128 = 3
}
export declare enum PersonaPieceType {
    Unknown = 0,
    Skeleton = 1,
    Body = 2,
    Skin = 3,
    Bottom = 4,
    Feet = 5,
    Dress = 6,
    Top = 7,
    HighPants = 8,
    Hands = 9,
    Outerwear = 10,
    Back = 11,
    FacialHair = 12,
    Mouth = 13,
    Eyes = 14,
    Hair = 15,
    FaceAccessory = 16,
    Head = 17,
    Legs = 18,
    LeftLeg = 19,
    RightLeg = 20,
    Arms = 21,
    LeftArm = 22,
    RightArm = 23,
    Capes = 24,
    ClassicSkin = 25
}
export declare class AnimatedImageData extends NativeClass {
    type: PersonaAnimatedTextureType;
    image: mce.Image;
    frames: float32_t;
}
export declare class SerializedPersonaPieceHandle extends NativeClass {
    pieceId: CxxString;
    pieceType: uint32_t;
    packId: mce.UUID;
    isDefaultPiece: bool_t;
    productId: CxxString;
}
export declare class SerializedSkin extends NativeClass {
    /** @deprecated Use {@link id} instead */
    skinId: CxxString;
    id: CxxString;
    playFabId: CxxString;
    fullId: CxxString;
    resourcePatch: CxxString;
    defaultGeometryName: CxxString;
    skinImage: mce.Image;
    capeImage: mce.Image;
    skinAnimatedImages: CxxVector<AnimatedImageData>;
    geometryData: JsonValue;
    geometryDataEngineVersion: SemVersion;
    geometryDataMutable: JsonValue;
    animationData: CxxString;
    capeId: CxxString;
    personaPieces: CxxVector<SerializedPersonaPieceHandle>;
    armSizeType: int32_t;
    /**
     * analyzed from static persona::ArmSize::getTypeFromString
     * SerializedSkin::SerializedSkin calls it.
     */
    get armSize(): string;
    skinColor: mce.Color;
    isTrustedSkin: TrustedSkinFlag;
    isPremium: bool_t;
    isPersona: bool_t;
    /** @deprecated Use {@link isPersonaCapeOnClassicSkin} instead */
    isCapeOnClassicSkin: bool_t;
    isPersonaCapeOnClassicSkin: bool_t;
    isPrimaryUser: bool_t;
}
