import { AbstractClass } from "../nativeclass";
export declare class MolangVariableMap extends AbstractClass {
}
