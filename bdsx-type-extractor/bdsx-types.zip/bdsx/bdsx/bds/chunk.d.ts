import { NativeClass } from "../nativeclass";
import { bool_t } from "../nativetype";
import { Actor, ActorUniqueID, WeakEntityRef } from "./actor";
import type { Biome } from "./biome";
import type { BlockPos, ChunkBlockPos, ChunkPos } from "./blockpos";
import type { Level } from "./level";
export declare class LevelChunk extends NativeClass {
    getBiome(pos: ChunkBlockPos): Biome;
    getLevel(): Level;
    getPosition(): ChunkPos;
    getMin(): BlockPos;
    getMax(): BlockPos;
    isFullyLoaded(): boolean;
    /**
     * Converts a local ChunkBlockPos instance to a global BlockPos.
     */
    toWorldPos(pos: ChunkBlockPos): BlockPos;
    getEntity(actorId: ActorUniqueID): Actor | null;
    getChunkEntities(): WeakEntityRef[];
}
export declare class ChunkSource extends NativeClass {
    getLevel(): Level;
    isChunkKnown(chunkPos: ChunkPos): bool_t;
    isChunkSaved(chunkPos: ChunkPos): bool_t;
    isWithinWorldLimit(chunkPos: ChunkPos): bool_t;
    isShutdownDone(): bool_t;
}
