import { NativeClass } from "../nativeclass";
import type { Player } from "./player";
export declare class GameMode extends NativeClass {
    actor: Player;
}
export declare class SurvivalMode extends GameMode {
}
