import { VoidPointer } from "../core";
import { AbstractClass } from "../nativeclass";
import { float32_t } from "../nativetype";
export declare enum AttributeId {
    /** @deprecated deleted */
    ZombieSpawnReinforcementsChange = -1,
    PlayerHunger = 1,
    PlayerSaturation = 2,
    PlayerExhaustion = 3,
    PlayerLevel = 4,
    PlayerExperience = 5,
    Health = 6,
    FollowRange = 7,
    KnockbackResistance = 8,
    MovementSpeed = 9,
    UnderwaterMovementSpeed = 10,
    LavaMovementSpeed = 11,
    AttackDamage = 12,
    Absorption = 13,
    Luck = 14,
    JumpStrength = 15
}
export declare class AttributeInstance extends AbstractClass {
    vftable: VoidPointer;
    u1: VoidPointer;
    u2: VoidPointer;
    currentValue: float32_t;
    minValue: float32_t;
    maxValue: float32_t;
    defaultValue: float32_t;
}
export declare class BaseAttributeMap extends AbstractClass {
    getMutableInstance(type: AttributeId): AttributeInstance | null;
}
export declare class AttributeInstanceHandle extends AbstractClass {
    attributeId: AttributeId;
    attributeMap: BaseAttributeMap;
}
