import { BuildPlatform, Direction, VectorXYZ } from "../common";
import { mce } from "../mce";
import { float32_t } from "../nativetype";
import { HasStorage, Storage } from "../storage";
import type { LayeredAbilities } from "./abilities";
import { Actor, ActorDamageSource, DimensionId, EntityContext, Mob } from "./actor";
import { AttributeId, AttributeInstance } from "./attribute";
import { Bedrock } from "./bedrock";
import { Block } from "./block";
import { BlockPos, Vec3 } from "./blockpos";
import type { CommandPermissionLevel } from "./command";
import { Certificate } from "./connreq";
import type { GameMode } from "./gamemode";
import { HashedString } from "./hashedstring";
import { ArmorSlot, ContainerId, EnderChestContainer, Item, ItemStack, PlayerInventory, PlayerUIContainer, PlayerUISlot } from "./inventory";
import type { NetworkIdentifier, ServerNetworkHandler } from "./networkidentifier";
import type { Packet } from "./packet";
import { PlayerListEntry as _PlayerListEntry, BossEventPacket } from "./packets";
import { SerializedSkin } from "./skin";
declare namespace RawTextObject {
    interface Text {
        text: string;
    }
    interface Translate {
        translate: string;
        with?: string[];
    }
    interface Score {
        score: {
            name: string;
            objective: string;
        };
    }
    type Properties = Text | Translate | Score;
}
interface RawTextObject {
    rawtext: RawTextObject.Properties[];
}
export declare class Player extends Mob implements HasStorage {
    enderChestContainer: EnderChestContainer;
    playerUIContainer: PlayerUIContainer;
    deviceId: string;
    /**
     * @deprecated use {@link getGameMode} method
     */
    get gameMode(): GameMode;
    /** @deprecated Use `this.getSpawnDimension()` instead */
    get respawnDimension(): DimensionId;
    /** @deprecated Use `this.getSpawnPosition()` instead */
    get respawnPosition(): BlockPos;
    /** @deprecated use `this.getAbilities()` instead */
    get abilities(): LayeredAbilities;
    protected _setName(name: string): void;
    /**
     * Changes the player's name
     *
     * @param name - New name
     */
    setName(name: string): void;
    /**
     * Updates the player list to all players
     */
    updatePlayerList(): void;
    getGameMode(): GameMode;
    /**
     * Returns the player's gamemode
     */
    getGameType(): GameType;
    /**
     * Returns the player's inventory proxy
     * @alias getSupplies
     */
    getInventory(): PlayerInventory;
    /**
     * Returns the player's inventory proxy
     */
    getSupplies(): PlayerInventory;
    /**
     * Returns the player's permission level
     * @see PlayerPermission
     */
    getPermissionLevel(): PlayerPermission;
    /**
     * Returns the player's skin
     */
    getSkin(): SerializedSkin;
    /**
     * Returns the player's real name
     */
    getName(): string;
    /**
     * Triggers an item cooldown (e.g: Ender pearl)
     * @remarks This function seems to crash the server. use ItemStack.startCoolDown() instead.
     *
     * @param item - Item to start the cooldown on
     */
    startCooldown(item: Item): void;
    /**
     * Returns a tick. If you want seconds, divide by 20
     */
    getItemCooldownLeft(cooldownType: HashedString): number;
    /**
     * Changes the player's permissions
     */
    setPermissions(permissions: CommandPermissionLevel): void;
    /**
     * Changes the player's gamemode
     *
     * @param gameType - Gamemode to switch to
     */
    setGameType(gameType: GameType): void;
    /**
     * Sets the player's sleeping status
     */
    setSleeping(value: boolean): void;
    /**
     * Returns the player's sleeping status
     */
    isSleeping(): boolean;
    /**
     * Returns whether the player is currently jumping
     */
    isJumping(): boolean;
    syncAbilities(): void;
    /**
     * @deprecated Typo!
     */
    syncAbilties(): void;
    /**
     * Sets the player's respawn position
     *
     * @param pos - Respawn position
     * @param dimension - Dimension
     */
    setRespawnPosition(pos: BlockPos, dimension: DimensionId): void;
    /**
     * Sets the player's bed respawn position
     * @param pos - Position of the bed
     */
    setBedRespawnPosition(pos: BlockPos): void;
    /**
     * Returns the Dimension ID of the player's respawn point
     * @remarks Currently, it's always the Overworld
     */
    getSpawnDimension(): DimensionId;
    /**
     * Returns the position of the player's respawn point
     */
    getSpawnPosition(): BlockPos;
    /**
     *Clears the player's respawn position
     */
    clearRespawnPosition(): void;
    /**
     * Returns if the player has respawn position
     */
    hasRespawnPosition(): boolean;
    /**
     * Returns the player's certificate
     */
    getCertificate(): Certificate;
    /**
     * Returns the multiplier for the player block destroy time, with every factor accounted, except for if the tool is correct, the faster the higher
     */
    getDestroySpeed(block: Block): number;
    /**
     * Returns if the tool is correct to break a block
     */
    canDestroy(block: Block): boolean;
    /**
     * Returns the player's XP points
     */
    getExperience(): number;
    /**
     * Returns the player's progression to the next level, between 0.0 and 1.0
     */
    getExperienceProgress(): number;
    /**
     * Returns the player's XP level
     */
    getExperienceLevel(): number;
    /**
     * Sets the player's XP points
     *
     * @param xp - between 1 and the maximum XP points for the level
     */
    setExperience(xp: number): void;
    /**
     * Sets the player's progression to the next XP level
     *
     * @param progress - between 0.0 and 1.0
     */
    setExperienceProgress(progress: number): void;
    /**
     * Sets the player's XP level
     *
     * @param level - between 0 and 24791
     */
    setExperienceLevel(level: number): void;
    /**
     * Adds XP points to the player, recalculating their level & progress
     *
     * @param xp - XP to add
     */
    addExperience(xp: number): void;
    /**
     * Adds progress to the player's XP level
     *
     * @param progress - between 0.0 and 1.0
     */
    addExperienceProgress(progress: number): void;
    /**
     * Adds XP levels to the player
     *
     * @param levels - levels to add
     */
    addExperienceLevels(levels: number): void;
    /**
     * Reset the XP levels of the player
     */
    resetExperienceLevels(): void;
    /**
     * Subtracts XP points from the player
     *
     * @param xp - between 1 and the current XP points for the level
     */
    subtractExperience(xp: number): void;
    /**
     * Subtracts progress from the player's XP level
     *
     * @param progress - between 0.0 and the current XP progress
     */
    subtractExperienceProgress(progress: number): void;
    /**
     * Subtracts XP levels from the player
     *
     * @param levels - between 1 and the player's XP level
     */
    subtractExperienceLevels(levels: number): void;
    /**
     * Returns the total XP needed for the next level
     */
    getXpNeededForNextLevel(): number;
    /**
     * Returns the remaining XP needed for the next level
     */
    getRemainingXpForNextLevel(): number;
    getCursorSelectedItem(): ItemStack;
    setCursorSelectedItem(itemStack: ItemStack): void;
    getPlayerUIItem(slot: PlayerUISlot): ItemStack;
    setPlayerUIItem(slot: PlayerUISlot, itemStack: ItemStack): void;
    getPlatform(): BuildPlatform;
    /**
     * Returns the player's XUID
     */
    getXuid(): string;
    /**
     * Returns the player's UUID
     */
    getUuid(): mce.UUID;
    forceAllowEating(): boolean;
    getSpeed(): number;
    hasOpenContainer(): boolean;
    /**
     * Returns whether the player is hungry.
     */
    isHungry(): boolean;
    /**
     * Returns whether the player is hurt.
     */
    isHurt(): boolean;
    /**
     * Returns whether the player has spawned in the Level. Different from `isAlive`.
     * if true, it's a valid entity.
     */
    isSpawned(): boolean;
    /**
     * Returns whether the player is loading in login screen.
     * if true, it's not a valid entity.
     */
    isLoading(): boolean;
    /**
     * Returns whether the player is initialized.
     * if true, it's a valid entity.
     * it checks {@link isSpawned}, and {@link isLoading} etc. internally.
     */
    isPlayerInitialized(): boolean;
    /**
     * Get block destroy progress
     * @param block
     */
    getDestroyProgress(block: Block): number;
    /**
     * Respawn player
     */
    respawn(): void;
    /**
     * Returns whether the player is simulated
     */
    isSimulated(): this is SimulatedPlayer;
    /**
     * Set player's respawn ready
     * @param vec3
     */
    setRespawnReady(vec3: Vec3): void;
    /**
     * Set player's spawn block respawn position
     * @param blockPos
     * @param dimensionId
     */
    setSpawnBlockRespawnPosition(blockPos: BlockPos, dimensionId: DimensionId): void;
    setSelectedSlot(slot: number): ItemStack;
    /**
     * @deprecated typo. Please use setSelectedSlot instead.
     * */
    setSelecetdSlot(slot: number): ItemStack;
    getDirection(): Direction.Type;
    isFlying(): boolean;
    isHiddenFrom(source: Mob): boolean;
    isInRaid(): boolean;
    isUsingItem(): boolean;
    hasDimension(): boolean;
    getAbilities(): LayeredAbilities;
    getSelectedItem(): ItemStack;
    static readonly [Storage.classId] = "player";
    [Storage.id](): string;
    [Storage.aliasId](): string;
    /** @deprecated Use `this.getNetworkIdentifier()` instead */
    get networkIdentifier(): NetworkIdentifier;
    /**
     * Returns the player's NetworkIdentifier
     */
    getNetworkIdentifier(): NetworkIdentifier;
    /**
     * Returns the player's next ContainerId
     * @remarks Values range from 1 to 99
     */
    nextContainerCounter(): ContainerId;
    /**
     * Opens the player's inventory
     */
    openInventory(): void;
    resendAllChunks(): void;
    /**
     * Sends a packet to the player
     *
     * @param packet - Packet to send
     */
    sendNetworkPacket(packet: Packet): void;
    /**
     * Updates a player's attribute
     *
     * @param id - Attribute ID to update
     * @param value - New value of the attribute
     */
    setAttribute(id: AttributeId, value: number): AttributeInstance | null;
    /**
     * Sets the player's armor
     *
     * @param slot - Armor slot
     * @param itemStack - Armor item to set
     */
    setArmor(slot: ArmorSlot, itemStack: ItemStack): void;
    /**
     * Updates player armor slots
     */
    sendArmor(value?: number): void;
    /**
     * Sends a chat-like message to the player
     * @remarks The message will have this format : <author> message
     *
     * @param message - Message to send
     * @param author - Message author (will be put inside the <>)
     */
    sendChat(message: string, author: string): void;
    /**
     * Sends a whisper-like message to the player
     * @remarks The message will have this format : <author> message (same as ServerPlayer.sendChat())
     *
     * @param message - Message to send
     * @param author - Message author (will be put inside the <>)
     */
    sendWhisper(message: string, author: string): void;
    /**
     * Sends a JSON-Object to the player
     * For the format for that object, reference:
     * @see https://minecraft.wiki/w/Commands/tellraw
     *
     * @param object JSON-Object to encode and send
     */
    sendTextObject(object: RawTextObject): void;
    /**
     * Sends a raw message to the player
     *
     * @param message - Message to send
     */
    sendMessage(message: string): void;
    /**
     * Sends a jukebox-like popup to the player
     * @remarks Does not have a background like other popups.
     *
     * @param message - Popup text
     * @param params - Translation keys to use
     */
    sendJukeboxPopup(message: string, params?: string[]): void;
    /**
     * Sends a popup to the player
     *
     * @param message - Popup text
     * @param params - Translation keys to use
     */
    sendPopup(message: string, params?: string[]): void;
    /**
     * Sends a tip-like popup to the player
     * @remarks Smaller than a Popup, positioned lower than an Actionbar
     *
     * @param message - Tip text
     * @param params - Translation keys to use
     */
    sendTip(message: string, params?: string[]): void;
    /**
     * Sends a translated message to the player
     *
     * @param message - Message to send
     * @param params - Translation keys
     */
    sendTranslatedMessage(message: string, params?: string[]): void;
    sendToastRequest(title: string, body?: string): void;
    /**
     * Displays a bossbar to the player
     * @remarks Bossbar percentage doesn't seem to function.
     *
     * @param title - Text above the bossbar
     * @param percent - Bossbar filling percentage
     * @param color - Bossbar color
     */
    setBossBar(title: string, percent: number, color?: BossEventPacket.Colors): void;
    /**
     * Resets title duration
     */
    resetTitleDuration(): void;
    /**
     * Sets the title animation duration (in ticks)
     * @remarks Will not affect actionbar and other popups.
     *
     * @param fadeInTime - fade-in duration (in ticks)
     * @param stayTime - stay time duration (in ticks)
     * @param fadeOutTime - fade-out duration (in ticks)
     */
    setTitleDuration(fadeInTime: number, stayTime: number, fadeOutTime: number): void;
    /**
     * Sends a title to the player
     *
     * @param title - Title text
     * @param subtitle - Subtitle text
     */
    sendTitle(title: string, subtitle?: string): void;
    /**
     * Sends a subtitle to the player
     * @remarks Will not display if there is no title being displayed
     *
     * @param subtitle - subtitle text
     */
    sendSubtitle(subtitle: string): void;
    /**
     * Clears player's title and subtitle
     * @remarks Will not affect actionbar and other popups
     */
    clearTitle(): void;
    /**
     * Sends an actionbar-like popup to the player
     * @remarks Smaller than a Popup, positioned higher than a Tip
     *
     * @param actionbar - Actionbar text
     */
    sendActionbar(actionbar: string): void;
    /**
     * Removes the bossbar
     */
    removeBossBar(): void;
    /**
     * Displays a scoreboard with custom text & scores
     *
     * @param title - Scoreboard title
     * @param lines - Scoreboard lines
     * @param name - Scoreboard name
     *
     * @example setFakeScoreboard("test", ["my score is 0", ["my score is 3", 3], "my score is 2 as my index is 2"])
     */
    setFakeScoreboard(title: string, lines: Array<string | [string, number]>, name?: string): string;
    /**
     * Removes scoreboard
     */
    removeFakeScoreboard(): void;
    /**
     * Transfers the player to another server
     *
     * @param address - Server address
     * @param port - Server port
     */
    transferServer(address: string, port?: number): void;
    /**
     * Plays a sound to the player
     *
     * @param soundName - Sound name, like "random.burp". See {@link https://minecraft.wiki/w/Sounds.json/Bedrock_Edition_values}
     * @param pos - Position where the sound is played (defaults to player position)
     * @param volume - Volume of the sound (defaults to 1)
     * @param pitch - Pitch of the sound (defaults to 1)
     */
    playSound(soundName: string, pos?: VectorXYZ, volume?: number, pitch?: number): void;
    getInputMode(): InputMode;
    die(damageSource: ActorDamageSource): void;
    static tryGetFromEntity(entity: EntityContext, getRemoved?: boolean): ServerPlayer | null;
}
export declare const ServerPlayer: typeof Player;
export type ServerPlayer = Player;
export declare class SimulatedPlayer extends ServerPlayer {
    /**
     * Create SimulatedPlayer
     * @param name
     * @param blockPos
     * @param dimensionId
     */
    static create(name: string, blockPos: BlockPos | Vec3 | VectorXYZ, dimensionId: DimensionId): SimulatedPlayer;
    /**
     * Create SimulatedPlayer
     * @param name
     * @param blockPos
     * @param dimensionId
     * @param nonOwnerPointerServerNetworkHandler Minecraft.getNonOwnerPointerServerNetworkHandler()
     * @deprecated no need to pass serverNetworkHandler
     */
    static create(name: string, blockPos: BlockPos, dimensionId: DimensionId, nonOwnerPointerServerNetworkHandler: Bedrock.NonOwnerPointer<ServerNetworkHandler>): SimulatedPlayer;
    /**
     * Simulate disconnect
     */
    simulateDisconnect(): void;
    simulateLookAt(target: Actor): void;
    simulateLookAt(target: Vec3): void;
    simulateLookAt(target: BlockPos): void;
    simulateJump(): void;
    simulateSetBodyRotation(rotation: number): void;
    simulateSetItem(item: ItemStack, selectSlot: boolean, slot: number): boolean;
    simulateDestroyBlock(pos: BlockPos, direction?: number): boolean;
    simulateStopDestroyingBlock(): void;
    simulateLocalMove(pos: Vec3, speed: number): void;
    simulateMoveToLocation(pos: Vec3, speed: number): void;
    simulateNavigateToLocations(locations: Vec3[], speed: float32_t): void;
    simulateStopMoving(): void;
    /** It attacks regardless of reach */
    simulateAttack(target: Actor): boolean;
    simulateInteractWithActor(target: Actor): boolean;
    simulateInteractWithBlock(blockPos: BlockPos, direction?: number): boolean;
    simulateUseItem(item: ItemStack): boolean;
    simulateUseItemOnBlock(item: ItemStack, pos: BlockPos, direction?: number, clickPos?: Vec3): boolean;
    simulateUseItemInSlot(slot: number): boolean;
    simulateUseItemInSlotOnBlock(slot: number, pos: BlockPos, direction?: number, clickPos?: Vec3): boolean;
    static tryGetFromEntity(entity: EntityContext, getRemoved?: boolean): SimulatedPlayer | null;
}
/** @deprecated Import from `bdsx/bds/packets` instead */
export declare const PlayerListEntry: typeof _PlayerListEntry;
/** @deprecated Import from `bdsx/bds/packets` instead */
export type PlayerListEntry = _PlayerListEntry;
export declare enum InputMode {
    Mouse = 1,
    Touch = 2,
    GamePad = 3,
    MotionController = 4
}
/**
 * Lists possible player gamemodes
 */
export declare enum GameType {
    Survival = 0,
    Creative = 1,
    Adventure = 2,
    SurvivalSpectator = 3,
    CreativeSpectator = 4,
    Default = 5,
    Spectator = 6
}
/**
 * Lists possible player permission levels
 */
export declare enum PlayerPermission {
    VISITOR = 0,
    MEMBER = 1,
    OPERATOR = 2,
    CUSTOM = 3
}
export {};
