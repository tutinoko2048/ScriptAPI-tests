import { NativePointer } from "../core";
import { AbstractClass, NativeClass, NativeStruct } from "../nativeclass";
import { Type, uint16_t } from "../nativetype";
import { CommandSymbols } from "./cmdsymbolloader";
export declare class typeid_t<T> extends NativeStruct {
    id: uint16_t;
}
declare const counterWrapper: unique symbol;
declare const typeidmap: unique symbol;
declare class IdCounter extends NativeClass {
    getValue(): number;
    /**
     * @return incremented value
     */
    increase(): number;
}
/**
 * dummy class for typeid
 */
export declare class HasTypeId extends AbstractClass {
    static [counterWrapper]: IdCounter;
    static readonly [typeidmap]: WeakMap<Type<any>, NativePointer | typeid_t<any>>;
}
export declare function type_id<T, BASE extends HasTypeId>(base: typeof HasTypeId & {
    new (): BASE;
}, type: Type<T>): typeid_t<BASE>;
export declare namespace type_id {
    /**
     * @deprecated dummy
     */
    function pdbimport(base: Type<any>, types: Type<any>[]): void;
    function load(symbols: CommandSymbols): void;
    function clone(base: typeof HasTypeId, oriType: Type<any>, newType: Type<any>): void;
    function register(base: typeof HasTypeId, type: Type<any>, id: number): void;
}
export {};
