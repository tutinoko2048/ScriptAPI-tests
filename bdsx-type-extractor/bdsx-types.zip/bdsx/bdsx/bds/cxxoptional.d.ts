import { VoidPointer } from "../core";
import { NativeClass, NativeClassType } from "../nativeclass";
import { NativeType, Type } from "../nativetype";
type NullPtrable<T> = (T extends VoidPointer ? null : never) | T;
export interface CxxOptionalType<T> extends NativeClassType<CxxOptional<T>> {
    new (address?: VoidPointer | boolean): CxxOptional<T>;
    componentType: Type<T>;
}
export declare abstract class CxxOptional<T> extends NativeClass {
    abstract value(): T | undefined;
    abstract setValue(value: NullPtrable<T> | undefined): void;
    abstract initValue(): void;
    abstract hasValue(): boolean;
    abstract reset(): void;
    static make<T>(type: Type<T>): CxxOptionalType<T>;
}
export declare class CxxOptionalToUndefUnion<T> extends NativeType<T | undefined> {
    readonly compType: Type<T>;
    readonly type: CxxOptionalType<T>;
    private constructor();
    static make<T>(compType: Type<T>): CxxOptionalToUndefUnion<T>;
}
export {};
