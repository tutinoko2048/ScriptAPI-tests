import { AbstractClass } from "../nativeclass";
export declare class BinaryStream extends AbstractClass {
}
