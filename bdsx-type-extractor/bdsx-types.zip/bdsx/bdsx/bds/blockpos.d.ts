import { CommandParameterType } from "../commandparam";
import { VectorXY, VectorXYZ, VectorXZ } from "../common";
import { NativeStruct } from "../nativeclass";
import { bin64_t, bool_t, float32_t, int32_t, NativeType, uint16_t, uint8_t } from "../nativetype";
export declare enum Facing {
    Down = 0,
    Up = 1,
    North = 2,
    South = 3,
    West = 4,
    East = 5,
    Max = 6
}
export declare namespace Facing {
    const convertYRotationToFacingDirection: (yRotation: number) => number;
}
export declare class BlockPos extends NativeStruct {
    static readonly MIN: BlockPos;
    static readonly MAX: BlockPos;
    static readonly ZERO: BlockPos;
    static readonly ONE: BlockPos;
    x: int32_t;
    y: int32_t;
    z: int32_t;
    set(pos: VectorXYZ): void;
    equal(pos: BlockPos | Vec3): boolean;
    abs(): BlockPos;
    inc(pos: BlockPos): BlockPos;
    inc(pos: Vec3): BlockPos;
    inc(x: number, y: number, z: number): BlockPos;
    dec(pos: BlockPos): BlockPos;
    dec(pos: Vec3): BlockPos;
    dec(x: number, y: number, z: number): BlockPos;
    multiply(times: number): BlockPos;
    divide(times: number): BlockPos;
    lengthSquared(): number;
    normalize(): BlockPos;
    getSide(side: Facing, step?: number): BlockPos;
    relative(facing: Facing, steps: number): BlockPos;
    static create(pos: Vec3): BlockPos;
    static create(pos: BlockPos): BlockPos;
    static create(pos: VectorXYZ): BlockPos;
    static create(x: number, y: number, z: number): BlockPos;
    toJSON(): VectorXYZ;
}
export declare class ChunkPos extends NativeStruct {
    x: int32_t;
    z: int32_t;
    set(pos: ChunkPos | VectorXZ): void;
    static create(x: number, z: number): ChunkPos;
    static create(pos: BlockPos): ChunkPos;
    static create(pos: VectorXZ): ChunkPos;
    toJSON(): VectorXZ;
}
export declare class ChunkBlockPos extends NativeStruct {
    x: uint8_t;
    y: uint16_t;
    z: uint8_t;
    set(pos: ChunkBlockPos | VectorXYZ): void;
    static create(x: number, y: number, z: number): ChunkBlockPos;
    static create(pos: BlockPos): ChunkBlockPos;
    static create(pos: VectorXYZ): ChunkBlockPos;
    toJSON(): VectorXYZ;
}
export declare class Vec2 extends NativeStruct {
    x: float32_t;
    y: float32_t;
    set(pos: Vec2 | VectorXY): void;
    static create(x: number, y: number): Vec2;
    static create(pos: VectorXY): Vec2;
    toJSON(): VectorXY;
}
export declare class Vec3 extends NativeStruct {
    static readonly MIN: Vec3;
    static readonly MAX: Vec3;
    static readonly ZERO: Vec3;
    static readonly HALF: Vec3;
    static readonly ONE: Vec3;
    static readonly TWO: Vec3;
    static readonly UNIT_X: Vec3;
    static readonly NEG_UNIT_X: Vec3;
    static readonly UNIT_Y: Vec3;
    static readonly NEG_UNIT_Y: Vec3;
    static readonly UNIT_Z: Vec3;
    static readonly NEG_UNIT_Z: Vec3;
    x: float32_t;
    y: float32_t;
    z: float32_t;
    set(pos: Vec3 | BlockPos | VectorXYZ): void;
    distance(pos: Vec3 | BlockPos | VectorXYZ): number;
    distanceSq(pos: Vec3 | BlockPos | VectorXYZ): number;
    equal(pos: Vec3 | BlockPos): boolean;
    floor(): Vec3;
    ceil(): Vec3;
    round(): Vec3;
    abs(): Vec3;
    inc(pos: BlockPos): Vec3;
    inc(pos: Vec3): Vec3;
    inc(x: number, y: number, z: number): Vec3;
    dec(pos: BlockPos): Vec3;
    dec(pos: Vec3): Vec3;
    dec(x: number, y: number, z: number): Vec3;
    multiply(times: number): Vec3;
    divide(times: number): Vec3;
    lengthSquared(): number;
    normalize(): Vec3;
    getSide(side: Facing, step?: number): Vec3;
    static create(pos: Vec3): Vec3;
    static create(pos: BlockPos): Vec3;
    static create(pos: VectorXYZ): Vec3;
    static create(x: number, y: number, z: number): Vec3;
    toJSON(): VectorXYZ;
    static directionFromRotation(rotation: Vec2): Vec3;
    static rotationFromDirection(direction: Vec3): Vec2;
}
export declare class RelativeFloat extends NativeStruct {
    static readonly [CommandParameterType.symbol]: true;
    static readonly [NativeType.registerDirect] = true;
    value: float32_t;
    is_relative: bool_t;
    bin_value: bin64_t;
    set(pos: RelativeFloat | {
        value: number;
        is_relative: boolean;
    }): void;
    static create(value: number, is_relative: boolean): RelativeFloat;
}
