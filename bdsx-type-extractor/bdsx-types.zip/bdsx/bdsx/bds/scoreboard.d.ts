import { StaticPointer } from "../core";
import { CxxVector } from "../cxxvector";
import { AbstractClass, NativeClass } from "../nativeclass";
import { CxxString, bin64_t, bool_t, int32_t, int64_as_float_t, uint32_t, uint8_t } from "../nativetype";
import { Actor, ActorUniqueID } from "./actor";
import type { Player } from "./player";
export declare class Scoreboard extends AbstractClass {
    /**
     * Resends the scoreboard to all clients
     */
    sync(id: ScoreboardId, objective: Objective): void;
    addObjective(name: string, displayName: string, criteria: ObjectiveCriteria): Objective;
    createScoreboardId(name: string): ScoreboardId;
    /**
     *  @param name Currently accepts only 'dummy'
     */
    getCriteria(name: "dummy"): ObjectiveCriteria;
    getCriteria(name: string): ObjectiveCriteria | null;
    getDisplayObjective(displaySlot: DisplaySlot): DisplayObjective | null;
    getObjectiveNames(): string[];
    getObjective(name: string): Objective | null;
    getObjectives(): Objective[];
    getActorScoreboardId(actor: Actor): ScoreboardId;
    getFakePlayerScoreboardId(name: string): ScoreboardId;
    getPlayerScoreboardId(player: Player): ScoreboardId;
    getScoreboardIdentityRef(id: ScoreboardId): ScoreboardIdentityRef;
    protected _getScoreboardIdentityRefs(retstr: CxxVector<ScoreboardIdentityRef>): CxxVector<ScoreboardIdentityRef>;
    getScoreboardIdentityRefs(): ScoreboardIdentityRef[];
    protected _getTrackedIds(retstr: CxxVector<ScoreboardId>): CxxVector<ScoreboardId>;
    getTrackedIds(): ScoreboardId[];
    removeObjective(objective: Objective): boolean;
    clearDisplayObjective(displaySlotName: "sidebar" | "belowName" | "list"): Objective | null;
    setDisplayObjective(displaySlot: DisplaySlot, objective: Objective, order: ObjectiveSortOrder): DisplayObjective | null;
    getPlayerScore(id: ScoreboardId, objective: Objective): number | null;
    resetPlayerScore(id: ScoreboardId, objective: Objective): boolean;
    setPlayerScore(id: ScoreboardId, objective: Objective, value: number): number;
    addPlayerScore(id: ScoreboardId, objective: Objective, value: number): number;
    removePlayerScore(id: ScoreboardId, objective: Objective, value: number): number;
}
export declare class ObjectiveCriteria extends AbstractClass {
    name: CxxString;
    readOnly: bool_t;
    renderType: uint8_t;
}
export declare class Objective extends AbstractClass {
    name: CxxString;
    displayName: CxxString;
    criteria: ObjectiveCriteria;
    getPlayers(): ScoreboardId[];
    getPlayerScore(id: ScoreboardId): ScoreInfo;
    getName(): string;
    getDisplayName(): string;
}
export declare class DisplayObjective extends AbstractClass {
    objective: Objective | null;
    order: ObjectiveSortOrder;
}
export declare class IdentityDefinition extends AbstractClass {
    getEntityId(): ActorUniqueID;
    getPlayerId(): ActorUniqueID;
    getFakePlayerName(): string;
    getIdentityType(): IdentityDefinition.Type;
    isPlayerType(): boolean;
    getName(): string | null;
}
export declare namespace IdentityDefinition {
    enum Type {
        Invalid = 0,
        Player = 1,
        Entity = 2,
        FakePlayer = 3
    }
    const Invalid: IdentityDefinition;
}
export declare class ScoreboardId extends NativeClass {
    static readonly INVALID: ScoreboardId;
    id: bin64_t;
    idAsNumber: int64_as_float_t;
    identityDef: IdentityDefinition;
    isValid(): boolean;
}
export declare class ScoreInfo extends NativeClass {
    objective: Objective | null;
    valid: bool_t;
    value: int32_t;
}
export declare class ScoreboardIdentityRef extends NativeClass {
    objectiveReferences: uint32_t;
    scoreboardId: ScoreboardId;
    protected _modifyScoreInObjective(result: StaticPointer, objective: Objective, score: number, action: PlayerScoreSetFunction): boolean;
    modifyScoreInObjective(objective: Objective, score: number, action: PlayerScoreSetFunction): number;
    getIdentityType(): IdentityDefinition.Type;
    /**
     * Returns INVALID id for players
     */
    getEntityId(): ActorUniqueID;
    getPlayerId(): ActorUniqueID;
    getFakePlayerName(): string;
    getScoreboardId(): ScoreboardId;
    isPlayerType(): bool_t;
}
export declare enum DisplaySlot {
    BelowName = "belowname",
    List = "list",
    Sidebar = "sidebar"
}
export declare enum ObjectiveSortOrder {
    Ascending = 0,
    Descending = 1
}
export declare enum PlayerScoreSetFunction {
    Set = 0,
    Add = 1,
    Subtract = 2
}
export declare enum ScoreCommandOperator {
    Equals = 1,
    PlusEquals = 2,
    MinusEquals = 3,
    TimesEquals = 4,
    DivideEquals = 5,
    ModEquals = 6,
    MinEquals = 7,
    MaxEquals = 8,
    Swap = 9
}
