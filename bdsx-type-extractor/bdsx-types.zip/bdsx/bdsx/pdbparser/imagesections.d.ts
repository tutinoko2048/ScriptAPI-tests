export declare class ImageSectionHeader {
    readonly name: string;
    readonly rva: number;
    readonly size: number;
    constructor(name: string, rva: number, size: number);
}
export declare class ImageSections {
    private readonly sections;
    readonly module: import("../dll").NativeModule;
    constructor();
    getSectionOfRva(rva: number): ImageSectionHeader | null;
}
export declare const imageSections: ImageSections;
