export interface SymbolInfo {
    address: number;
    tag: number;
    flags: number;
    name: string;
}
export declare class PdbCache implements Iterable<SymbolInfo> {
    private readonly fd;
    private readonly buffer;
    private offset;
    private bufsize;
    readonly total: number;
    constructor();
    static clearCache(): void;
    close(): void;
    private _readMore;
    private _readInt;
    private _readString;
    [Symbol.iterator](): IterableIterator<SymbolInfo>;
}
