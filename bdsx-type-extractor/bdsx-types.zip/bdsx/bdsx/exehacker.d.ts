export namespace exehacker {
    export { nopping };
    export { hooking };
    export { patching };
    export { jumping };
    export { write };
}
declare function nopping(subject: any, key: any, offset: any, originalCode: any, ignoreArea: any): void;
declare function hooking(dummy: any, key: any, to: any, ignore: any, ignore2: any): void;
declare function patching(subject: any, key: any, offset: any, newCode: any, tempRegister: any, call: any, originalCode: any, ignoreArea: any): void;
declare function jumping(subject: any, key: any, offset: any, jumpTo: any, tempRegister: any, originalCode: any, ignoreArea: any): void;
declare function write(key: any, offset: any, asm: any): void;
export {};
