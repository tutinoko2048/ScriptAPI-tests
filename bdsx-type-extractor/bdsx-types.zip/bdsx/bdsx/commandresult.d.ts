import type { MCRESULT } from "./bds/command";
import { VectorXYZ } from "./common";
export interface CommandResult<DATA extends CommandResult.Any> extends MCRESULT {
    data: DATA;
}
export declare namespace CommandResult {
    interface Any {
        statusMessage: string;
        statusCode: number;
        [key: string]: any;
    }
    interface List {
        currentPlayerCount: number;
        maxPlayerCount: number;
        players: string;
        statusMessage: string;
        statusCode: number;
    }
    interface TestFor {
        victim: string[];
        statusMessage: string;
        statusCode: number;
    }
    interface TestForBlock {
        matches: boolean;
        position: VectorXYZ;
        statusMessage: string;
        statusCode: number;
    }
    interface TestForBlocks {
        compareCount: number;
        matches: boolean;
        statusMessage: string;
        statusCode: number;
    }
}
declare enum CommandResultTypeEnum {
    Mute = 0,
    Data = 1,
    Output = 2,
    OutputAndData = 3
}
export type CommandResultType = boolean | CommandResultTypeEnum | null;
export declare const CommandResultType: typeof CommandResultTypeEnum;
export {};
