declare const _exports: ChatManager;
export = _exports;
declare class ChatManager extends EventEx<any> {
    constructor();
    chatlistener: (ptr: any, networkIdentifier: any, packetId: any) => typeof CANCEL | undefined;
    on(listener: any): void;
}
import { EventEx } from "./eventtarget";
import { CANCEL } from "./common";
