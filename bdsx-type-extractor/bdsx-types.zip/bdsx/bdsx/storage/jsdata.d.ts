import { BufferReader, BufferWriter } from "../writer/bufferstream";
export declare namespace jsdata {
    function serialize(data: unknown, writer?: BufferWriter): Uint8Array;
    function deserialize(buffer: Uint8Array | BufferReader, errors?: Error[]): any;
    class EmptySpace {
        readonly length: number;
        constructor(length: number);
    }
    const Invalid: {
        toString(): string;
    };
}
