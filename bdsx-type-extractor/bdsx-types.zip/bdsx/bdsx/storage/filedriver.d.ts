import { StorageData, StorageDriver } from ".";
/**
 * rough driver for bdsx storage
 */
export declare class FileStorageDriver extends StorageDriver {
    private readonly loading;
    readonly basePath: string;
    constructor(basePath: string);
    private _load;
    private _getClassPath;
    write(classId: string | null, mainId: string, aliasId: string | null, data: StorageData): Promise<void>;
    private _parse;
    read(classId: string | null, id: string): Promise<StorageData | null>;
    readSync(classId: string | null, id: string): StorageData | null;
    createIndex(classId: string, indexKey: string): Promise<void>;
    deleteIndex(classId: string, indexKey: string): Promise<void>;
    search(classId: string, indexKey: string, value: unknown): AsyncIterableIterator<string>;
    list(classId: string | null): AsyncIterableIterator<string>;
    listClass(): AsyncIterableIterator<string>;
}
