interface StorageClassBase {
    [Storage.classId]: string;
    prototype: HasStorage;
}
declare const storageStored: unique symbol;
declare enum State {
    Loaded = 0,
    Loading = 1,
    Unloaded = 2,
    Deleted = 3
}
export declare abstract class Storage {
    static readonly classId: unique symbol;
    static readonly id: unique symbol;
    static readonly aliasId: unique symbol;
    abstract get data(): any;
    abstract get isLoaded(): boolean;
    abstract init(value: unknown): void;
    abstract close(): boolean;
    protected constructor();
    delete(): void;
}
declare class StorageImpl extends Storage {
    private container;
    private readonly classId;
    private mainId;
    private aliasId;
    private isStringId;
    private readonly driver;
    private storageData;
    private saving;
    private modified;
    state: State;
    private loading;
    constructor(container: HasStorage | null, classId: string | null, mainId: string, aliasId: string | null, isStringId: boolean, driver: StorageDriver);
    get data(): any;
    get isLoaded(): boolean;
    private _load;
    private _loadSync;
    private _loadData;
    setContainer(container: HasStorage, mainId: string, aliasId: string | null): void;
    private _changeKeys;
    load(): Promise<StorageImpl>;
    loadSync(): StorageImpl;
    init(value: unknown): void;
    close(): boolean;
    private _unload;
    saveRequest(): Promise<void>;
    convert(value: unknown): unknown;
    private _makeArrayProxy;
    private _makeObjectProxy;
}
export interface HasStorage {
    [storageStored]?: StorageImpl;
    [Storage.aliasId]?(): string;
    [Storage.id](): string;
}
export interface StorageData {
    mainId: string | null;
    aliasId: string | null;
    data: any;
}
export declare abstract class StorageDriver {
    static readonly NOT_FOUND: unique symbol;
    flushDelay: number;
    abstract write(classId: string | null, mainId: string, aliasId: string | null, data: StorageData): Promise<void>;
    abstract read(classId: string | null, id: string): Promise<StorageData | null>;
    abstract readSync(classId: string | null, id: string): StorageData | null;
    abstract createIndex(classId: string, indexKey: string): Promise<void>;
    abstract deleteIndex(classId: string, indexKey: string): Promise<void>;
    abstract search(classId: string, indexKey: string, value: unknown): AsyncIterableIterator<string>;
    abstract list(classId: string | null): AsyncIterableIterator<string>;
    abstract listClass(): AsyncIterableIterator<string>;
}
declare class NullDriver extends StorageDriver {
    write(classId: string | null, mainId: string, aliasId: string | null, data: StorageData | null): Promise<void>;
    read(classId: string | null, id: string): Promise<StorageData | null>;
    readSync(classId: string | null, id: string): StorageData | null;
    createIndex(classId: string, indexKey: string): Promise<void>;
    deleteIndex(classId: string, indexKey: string): Promise<void>;
    search(classId: string, indexKey: string, value: unknown): AsyncIterableIterator<string>;
    list(classId: string | null): AsyncIterableIterator<string>;
    listClass(): AsyncIterableIterator<string>;
}
export declare namespace StorageDriver {
    const nullDriver: NullDriver;
}
export declare class StorageManager {
    driver: StorageDriver;
    constructor(driver?: StorageDriver);
    close(objOrKey: HasStorage | string): void;
    private _getWithoutLoad;
    getSync(objOrKey: HasStorage | string): Storage;
    get(objOrKey: HasStorage | string): Promise<Storage>;
    createIndex(storageClass: StorageClassBase, indexKey: string): Promise<void>;
    search(storageClass: StorageClassBase, indexKey: string, value: unknown): AsyncIterableIterator<Storage>;
    listClass(): AsyncIterableIterator<string>;
    list(storageClass?: StorageClassBase): AsyncIterableIterator<string>;
}
declare global {
    namespace NodeJS {
        interface Module {
            [Storage.id](): string;
        }
    }
    interface NodeModule {
        [Storage.id](): string;
    }
}
export declare const storageManager: StorageManager;
export {};
