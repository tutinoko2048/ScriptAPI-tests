import { StaticPointer, VoidPointer } from "./core";
import { NativeClass, NativeClassType } from "./nativeclass";
import { NativeType, Type, uint32_t } from "./nativetype";
declare class CxxPtrBase<T> extends NativeClass {
    vftable: VoidPointer;
    useRef: uint32_t;
    weakRef: uint32_t;
    value: T;
    [NativeType.ctor](): void;
    addRef(): void;
    addRefWeak(): void;
    release(): void;
    releaseWeak(): void;
    _DeleteThis(): void;
    _Destroy(): void;
    static make<T>(type: Type<T>): NativeClassType<CxxPtrBase<T>>;
}
/** @deprecate Do you need to use it? */
export declare const SharedPtrBase: typeof CxxPtrBase;
/** @deprecate Do you need to use it? */
export type SharedPtrBase<T> = CxxPtrBase<T>;
/**
 * wrapper for std::shared_ptr
 */
export declare abstract class CxxSharedPtr<T extends NativeClass> extends NativeClass {
    static readonly type: NativeClassType<any>;
    p: T | null;
    ref: CxxPtrBase<T> | null;
    [NativeType.ctor](): void;
    [NativeType.dtor](): void;
    [NativeType.ctor_copy](value: CxxSharedPtr<T>): void;
    [NativeType.ctor_move](value: CxxSharedPtr<T>): void;
    /**
     * @deprecated use [NativeType.ctor_move]()
     */
    ctor_move(value: CxxSharedPtr<T>): void;
    assign(value: CxxSharedPtr<T>): this;
    assign_move(value: CxxSharedPtr<T>): this;
    exists(): boolean;
    addRef(): void;
    assignTo(dest: StaticPointer): void;
    dispose(): void;
    abstract create(vftable: VoidPointer): void;
    static make<T extends NativeClass>(cls: new () => T): NativeClassType<CxxSharedPtr<T>>;
}
/** @deprecated use CxxSharedPtr, avoid duplicated name */
export declare const SharedPtr: typeof CxxSharedPtr;
/** @deprecated use CxxSharedPtr, avoid duplicated name */
export type SharedPtr<T extends NativeClass> = CxxSharedPtr<T>;
/**
 * wrapper for std::weak_ptr
 */
export declare abstract class CxxWeakPtr<T extends NativeClass> extends NativeClass {
    static readonly type: NativeClassType<any>;
    p: T | null;
    ref: CxxPtrBase<T> | null;
    [NativeType.ctor](): void;
    [NativeType.dtor](): void;
    [NativeType.ctor_copy](value: CxxWeakPtr<T>): void;
    [NativeType.ctor_move](value: CxxWeakPtr<T>): void;
    assign(value: CxxWeakPtr<T>): this;
    assign_move(value: CxxWeakPtr<T>): this;
    exists(): boolean;
    addRef(): void;
    assignTo(dest: StaticPointer): void;
    dispose(): void;
    abstract create(vftable: VoidPointer): void;
    static make<T extends NativeClass>(cls: new () => T): NativeClassType<CxxWeakPtr<T>>;
}
export {};
