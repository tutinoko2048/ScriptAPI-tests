export declare namespace Config {
    /**
     * true if running BDSX normally (with BDS and bdsx-core)
     */
    const BDSX: boolean;
    /**
     * true if running on Linux+Wine
     */
    const WINE: boolean;
    /**
     * handle stdin with the hooking method.
     * or it uses the readline module of node.js
     *
     * Linux+Wine has an issue on the readline module
     */
    const USE_NATIVE_STDIN_HANDLER = true;
    /**
     * replace the unicode encoder of BDS.
     *
     * the original encoder crashes sometimes on Linux+Wine.
     */
    const REPLACE_UNICODE_ENCODER: boolean;
    const BDS_PATH: string;
}
