export namespace legacy {
    function setOnRuntimeErrorListener(cb: any): void;
    function catchAndSendToRuntimeErrorListener(err: any): void;
}
export class SharedPointer extends core.StaticPointer {
    constructor(sharedptr: any);
    sharedptr: any;
    assignTo(dest: any): void;
    dispose(): void;
}
export function readLoginPacket(packet: any): string[];
import core = require("./core");
