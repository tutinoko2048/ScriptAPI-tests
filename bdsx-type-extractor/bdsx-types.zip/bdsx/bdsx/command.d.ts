import { Command, CommandCheatFlag, CommandOutput, CommandParameterOption, CommandPermissionLevel, CommandRegistry, CommandUsageFlag, CommandVisibilityFlag } from "./bds/command";
import { CommandOrigin } from "./bds/commandorigin";
import { CommandEnum, CommandRawEnum, CommandSoftEnum } from "./commandenum";
import { CommandParameterType } from "./commandparam";
import { CommandMappedValue } from "./commandparser";
import { NativeType } from "./nativetype";
export declare class CustomCommand extends Command {
    self_vftable: Command.VFTable;
    [NativeType.ctor](): void;
    execute(origin: CommandOrigin, output: CommandOutput): void;
}
export interface CommandFieldOptions {
    optional?: boolean;
    /** @deprecated Use {@link postfix} instead */
    description?: string;
    postfix?: string;
    name?: string;
    options?: CommandParameterOption;
}
type GetTypeFromParam<T> = T extends CommandMappedValue<any, infer V> ? V : T extends CommandParameterType<infer V> ? V : never;
type IfOptional<OPTS extends boolean | CommandFieldOptions, TRUE, FALSE> = OPTS extends true ? TRUE : OPTS extends {
    optional: true;
} ? TRUE : FALSE;
type OptionalCheck<T, OPTS extends boolean | CommandFieldOptions> = IfOptional<OPTS, GetTypeFromParam<T> | undefined, GetTypeFromParam<T>>;
export declare class CustomCommandFactory {
    readonly registry: CommandRegistry;
    readonly name: string;
    constructor(registry: CommandRegistry, name: string);
    overload<PARAMS extends Record<string, CommandParameterType<any> | [CommandParameterType<any>, CommandFieldOptions | boolean]>>(callback: (params: {
        [key in keyof PARAMS]: PARAMS[key] extends [infer T, infer OPTS] ? OPTS extends CommandFieldOptions | boolean ? OptionalCheck<T, OPTS> : never : PARAMS[key] extends CommandParameterType<any> ? GetTypeFromParam<PARAMS[key]> : never;
    }, origin: CommandOrigin, output: CommandOutput) => void, parameters: PARAMS): this;
    alias(alias: string): this;
}
export declare class CustomCommandFactoryWithSignature extends CustomCommandFactory {
    signature: CommandRegistry.Signature;
    constructor(registry: CommandRegistry, name: string, signature: CommandRegistry.Signature);
}
declare function _enum<VALUES extends Record<string, string | number>>(name: string, values: VALUES): CommandEnum<VALUES[keyof VALUES]>;
declare function _enum<STR extends string, VALUES extends STR[]>(name: string, values: VALUES): CommandEnum<VALUES[number]>;
declare function _enum<VALUES extends string[]>(name: string, ...values: VALUES): CommandEnum<VALUES[number]>;
declare function softEnum(name: string, ...values: string[]): CommandSoftEnum;
declare function softEnum(name: string, values: string[]): CommandSoftEnum;
export declare const command: {
    find(name: string): CustomCommandFactoryWithSignature;
    register(name: string, description: string, perm?: CommandPermissionLevel, flags1?: CommandCheatFlag | CommandVisibilityFlag, flags2?: CommandUsageFlag | CommandVisibilityFlag): CustomCommandFactory;
    softEnum: typeof softEnum;
    enum: typeof _enum;
    /**
     * built-in enum system
     */
    rawEnum(name: string): CommandRawEnum;
};
export {};
