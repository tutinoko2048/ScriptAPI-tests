export declare const shellPrepareData: {
    path: string;
    load(): Record<string, string>;
    save(data: Record<string, string>): void;
    clear(): void;
};
