export declare enum BdsxExitCode {
    Quit = 0,
    InstallNpm = 65536
}
