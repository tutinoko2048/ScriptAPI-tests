import type { makefunc } from "./makefunc";
export declare const mangle: {
    char: string;
    unsignedChar: string;
    short: string;
    unsignedShort: string;
    int: string;
    unsignedInt: string;
    long: string;
    unsignedLong: string;
    double: string;
    float: string;
    longlong: string;
    unsignedLongLong: string;
    bool: string;
    unsignedInt128: string;
    void: string;
    constChar: string;
    constCharPointer: string;
    update(target: makefunc.Paramable, opts?: mangle.UpdateOptions): void;
    pointer(name: makefunc.Paramable | string): string;
    constPointer(name: makefunc.Paramable | string): string;
    ref(name: makefunc.Paramable | string): string;
    constRef(name: makefunc.Paramable | string): string;
    ns(names: string[] | string): string;
    clazz(...name: string[]): string;
    struct(...name: string[]): string;
    number(n: number): string;
    parameters(params: (makefunc.Paramable | string)[]): string;
    funcptr(returnType: makefunc.Paramable | string, params: (makefunc.Paramable | string)[]): string;
    func(code: string, name: string[] | string, returnType: makefunc.Paramable | string, params: (makefunc.Paramable | string)[]): string;
    globalFunc(name: string[] | string, returnType: makefunc.Paramable | string, params: (makefunc.Paramable | string)[]): string;
    privateConstFunc(name: string[] | string, returnType: makefunc.Paramable | string, params: (makefunc.Paramable | string)[]): string;
    template(name: string, params: (makefunc.Paramable | string | number)[]): string;
    templateClass(name: string[] | string, ...params: (makefunc.Paramable | string | number)[]): string;
};
export declare namespace mangle {
    interface UpdateOptions {
        /**
         * the symbol is defined as a struct
         */
        structSymbol?: boolean;
        /**
         * set symbol name manually
         */
        symbol?: string;
    }
}
