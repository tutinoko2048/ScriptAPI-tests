import { readLoginPacket } from "./legacy";
export function raw(id: any): import("./eventtarget").Event<nethook.RawListener>;
export function before(id: any): import("./eventtarget").Event<nethook.PacketListener<any>>;
export function after(id: any): import("./eventtarget").Event<nethook.PacketListener<any>>;
export function send(id: any): import("./eventtarget").Event<nethook.PacketListener<any>>;
export function sendRaw(id: any): import("./eventtarget").Event<nethook.SendRawListener>;
export function watchAll(exceptions: any): void;
import { nethook } from "./nethook";
export { readLoginPacket, networkDisconnected as close };
