export declare function templateName(name: string, ...templateParams: string[]): string;
