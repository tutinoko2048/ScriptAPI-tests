import ProgressBar = require("progress");
export declare namespace progressBar {
    function start(name: string, total: number | ProgressBar.ProgressBarOptions): void;
    function setTotal(total: number): void;
    function finish(): void;
    function terminate(): void;
    function tick(count?: number): void;
    function printOnProgress(message: string): void;
}
