/// <reference types="node" />
/// <reference types="node" />
import * as fs from "fs";
export declare namespace fsutil {
    const projectPath: string;
    /** @deprecated use fsutil.projectPath */
    function getProjectPath(): string;
    function isDirectory(filepath: string): Promise<boolean>;
    function isFile(filepath: string): Promise<boolean>;
    function isDirectorySync(filepath: string): boolean;
    function isFileSync(filepath: string): boolean;
    function checkModified(ori: string, out: string): Promise<boolean>;
    function checkModifiedSync(ori: string, out: string): boolean;
    function readFile(path: string): Promise<string>;
    function readFile(path: string, encoding: null): Promise<Buffer>;
    function readFile(path: string, encoding: string): Promise<string>;
    function writeFile(path: string, content: string | Uint8Array): Promise<void>;
    function writeStream(path: string, stream: NodeJS.ReadableStream): Promise<void>;
    function appendFile(path: string, content: string | Uint8Array): Promise<void>;
    /**
     * uses system EOL and add a last line
     */
    function writeJson(path: string, content: unknown): Promise<void>;
    /**
     * uses system EOL and add a last line
     */
    function writeJsonSync(path: string, content: unknown): void;
    function readdir(path: string): Promise<string[]>;
    function readdirWithFileTypes(path: string): Promise<fs.Dirent[]>;
    function readdirWithFileTypesSync(path: string): fs.Dirent[];
    function opendir(path: string): Promise<fs.Dir>;
    function mkdir(path: string): Promise<void>;
    function mkdirRecursive(dirpath: string, dirhas?: Set<string>): Promise<void>;
    function mkdirRecursiveFromBack(dir: string): Promise<boolean>;
    function rmdir(path: string): Promise<void>;
    function stat(path: string): Promise<fs.Stats>;
    function lstat(path: string): Promise<fs.Stats>;
    function utimes(path: string, atime: string | number | Date, mtime: string | number | Date): Promise<void>;
    function unlink(path: string): Promise<void>;
    function unlinkRecursive(filepath: string): Promise<void>;
    function unlinkRecursiveSync(filepath: string): void;
    function copyFile(from: string, to: string): Promise<void>;
    function exists(path: string): Promise<boolean>;
    function del(filepath: string): Promise<void>;
    function unlinkQuiet(path: string): Promise<boolean>;
    function symlink(target: string, path: string, type?: fs.symlink.Type): Promise<void>;
    function readFirstLineSync(path: string): string;
    function rename(oldPath: string, newPath: string): Promise<void>;
    class DirectoryMaker {
        readonly dirhas: Set<string>;
        make(pathname: string): Promise<void>;
        del(pathname: string): void;
    }
}
