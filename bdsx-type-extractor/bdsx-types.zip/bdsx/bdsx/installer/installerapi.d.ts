import { BDSInstaller } from "./installercls";
export declare function installBDS(bdsPath: string, opts: BDSInstaller.Options): Promise<boolean>;
