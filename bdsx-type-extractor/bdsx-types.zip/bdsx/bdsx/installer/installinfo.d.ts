export declare class InstallInfo {
    path: string;
    bdsVersion?: string | null;
    bdsxCoreVersion?: string | null;
    pdbcacheVersion?: string | null;
    files?: string[];
    constructor(bdsPath: string);
    toJSON(): unknown;
    private _fromJSON;
    load(): Promise<void>;
    save(): Promise<void>;
    loadSync(): void;
    saveSync(): void;
}
