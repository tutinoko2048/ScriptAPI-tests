export declare function gitCheck(): Promise<void>;
