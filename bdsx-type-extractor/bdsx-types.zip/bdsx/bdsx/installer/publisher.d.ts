import type { RestEndpointMethods } from "@octokit/plugin-rest-endpoint-methods/dist-types/generated/method-types";
import type { RestEndpointMethodTypes } from "@octokit/plugin-rest-endpoint-methods/dist-types/generated/parameters-and-response-types";
export declare class GitHubClient {
    private readonly api;
    constructor(githubToken: string);
    createRelease(name: string, owner: string, repo: string, tag_name: string): Promise<GitHubRelease>;
}
export declare class GitHubRelease {
    private readonly api;
    private readonly release;
    readonly owner: string;
    readonly repo: string;
    constructor(api: RestEndpointMethods, release: RestEndpointMethodTypes["repos"]["createRelease"]["response"], owner: string, repo: string);
    upload(file: string): Promise<void>;
    delete(): Promise<void>;
}
