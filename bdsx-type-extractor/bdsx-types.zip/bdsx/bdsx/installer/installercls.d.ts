import { InstallInfo } from "./installinfo";
export declare class BDSInstaller {
    readonly bdsPath: string;
    readonly opts: BDSInstaller.Options;
    readonly info: InstallInfo;
    target: string;
    constructor(bdsPath: string, opts: BDSInstaller.Options);
    yesno(question: string, defaultValue?: boolean): Promise<boolean>;
    removeInstalled(dest: string, files: string[]): Promise<void>;
    gitPublish(item: InstallItem.Options, files: string | string[], basePath?: string, zipPath?: string): Promise<void>;
}
export declare namespace BDSInstaller {
    interface Options {
        agree?: string | boolean;
        disagree?: string | boolean;
        skip?: string | boolean;
    }
}
export declare class InstallItem {
    readonly opts: InstallItem.Options;
    constructor(opts: InstallItem.Options);
    private _downloadAndUnzip;
    private _install;
    private _confirmAndInstall;
    install(installer: BDSInstaller): Promise<void>;
}
export declare namespace InstallItem {
    interface Options {
        name: string;
        key?: keyof InstallInfo;
        version?: string;
        targetPath: string;
        url: string;
        keyFile?: string;
        confirm?: (installer: BDSInstaller) => Promise<void> | void;
        preinstall?: (installer: BDSInstaller) => Promise<void> | void;
        postinstall?: (installer: BDSInstaller, writtenFiles: string[]) => Promise<void> | void;
        fallback?: (installer: BDSInstaller, statusCode: number) => Promise<boolean | void> | boolean | void;
        skipExists?: boolean;
        oldFiles?: string[];
        merge?: [string, (a: string, b: string) => string][];
    }
    class Report extends Error {
    }
}
