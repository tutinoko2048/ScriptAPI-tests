export declare const PACKET_ID_COUNT = 320;
